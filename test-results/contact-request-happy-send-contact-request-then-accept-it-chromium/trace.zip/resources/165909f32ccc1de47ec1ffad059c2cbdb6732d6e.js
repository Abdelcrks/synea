(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/62645_next_24cbe78f._.js",
  "static/chunks/_d213afe6._.js"
],
    source: "dynamic"
});
