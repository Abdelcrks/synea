(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _global_process, _global_process1;
module.exports = ((_global_process = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process.env) && typeof ((_global_process1 = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process1.env) === 'object' ? /*TURBOPACK member replacement*/ __turbopack_context__.g.process : __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/process/browser.js [app-client] (ecmascript)"); //# sourceMappingURL=process.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/polyfill-module.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

try {
    (0, eval)("globalThis._triedToInstallGlobalErrorHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0x3d84fa=_0x3d13;(function(_0x111933,_0x3d30f3){const _0x439376=_0x3d13,_0x28cbbe=_0x111933();while(!![]){try{const _0x190706=-parseInt(_0x439376(0x1bb))/0x1*(parseInt(_0x439376(0x19f))/0x2)+-parseInt(_0x439376(0x186))/0x3+parseInt(_0x439376(0x1ca))/0x4*(parseInt(_0x439376(0x1c1))/0x5)+-parseInt(_0x439376(0x173))/0x6+-parseInt(_0x439376(0x179))/0x7*(-parseInt(_0x439376(0x193))/0x8)+-parseInt(_0x439376(0x1be))/0x9+parseInt(_0x439376(0x1a0))/0xa;if(_0x190706===_0x3d30f3)break;else _0x28cbbe['push'](_0x28cbbe['shift']());}catch(_0x21ab91){_0x28cbbe['push'](_0x28cbbe['shift']());}}}(_0x345d,0x3f80c));function _0x3d13(_0x3b008e,_0x226c7d){const _0x345ded=_0x345d();return _0x3d13=function(_0x3d1342,_0x48f9ee){_0x3d1342=_0x3d1342-0x157;let _0x259ba7=_0x345ded[_0x3d1342];return _0x259ba7;},_0x3d13(_0x3b008e,_0x226c7d);}function k(_0x3e3c82,_0x50e238,_0x5362c2,_0x2d4a46,_0x3816b3,_0x385efb){const _0x47fe47=_0x3d13;var _0x2537c8,_0x13e865,_0x288288,_0x132f75;this['global']=_0x3e3c82,this[_0x47fe47(0x15a)]=_0x50e238,this['port']=_0x5362c2,this[_0x47fe47(0x1cc)]=_0x2d4a46,this[_0x47fe47(0x1af)]=_0x3816b3,this[_0x47fe47(0x1a4)]=_0x385efb,this[_0x47fe47(0x158)]=!0x0,this[_0x47fe47(0x1d4)]=!0x0,this[_0x47fe47(0x19d)]=!0x1,this[_0x47fe47(0x178)]=!0x1,this[_0x47fe47(0x1c4)]=((_0x13e865=(_0x2537c8=_0x3e3c82[_0x47fe47(0x1b1)])==null?void 0x0:_0x2537c8[_0x47fe47(0x166)])==null?void 0x0:_0x13e865[_0x47fe47(0x1cf)])===_0x47fe47(0x1b8),this[_0x47fe47(0x168)]=!((_0x132f75=(_0x288288=this[_0x47fe47(0x194)]['process'])==null?void 0x0:_0x288288[_0x47fe47(0x1d6)])!=null&&_0x132f75[_0x47fe47(0x16b)])&&!this[_0x47fe47(0x1c4)],this[_0x47fe47(0x1a5)]=null,this[_0x47fe47(0x190)]=0x0,this[_0x47fe47(0x1d0)]=0x14,this['_webSocketErrorDocsLink']=_0x47fe47(0x1ac),this[_0x47fe47(0x181)]=(this[_0x47fe47(0x168)]?_0x47fe47(0x1c7):_0x47fe47(0x195))+this[_0x47fe47(0x1b7)];}k['prototype'][_0x3d84fa(0x1c9)]=async function(){const _0x35f6c7=_0x3d84fa;var _0x5a328a,_0x7992e0;if(this['_WebSocketClass'])return this[_0x35f6c7(0x1a5)];let _0x11a5c3;if(this['_inBrowser']||this[_0x35f6c7(0x1c4)])_0x11a5c3=this['global']['WebSocket'];else{if((_0x5a328a=this[_0x35f6c7(0x194)][_0x35f6c7(0x1b1)])!=null&&_0x5a328a[_0x35f6c7(0x18d)])_0x11a5c3=(_0x7992e0=this[_0x35f6c7(0x194)][_0x35f6c7(0x1b1)])==null?void 0x0:_0x7992e0['_WebSocket'];else try{_0x11a5c3=(await new Function('path',_0x35f6c7(0x184),_0x35f6c7(0x1cc),'return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());')(await(0x0,eval)('import(\\x27path\\x27)'),await(0x0,eval)(_0x35f6c7(0x17a)),this['nodeModules']))[_0x35f6c7(0x1a7)];}catch{try{_0x11a5c3=require(require(_0x35f6c7(0x1a8))['join'](this[_0x35f6c7(0x1cc)],'ws'));}catch{throw new Error('failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket');}}}return this[_0x35f6c7(0x1a5)]=_0x11a5c3,_0x11a5c3;},k[_0x3d84fa(0x1cb)]['_connectToHostNow']=function(){const _0x3acaae=_0x3d84fa;this[_0x3acaae(0x178)]||this['_connected']||this[_0x3acaae(0x190)]>=this['_maxConnectAttemptCount']||(this[_0x3acaae(0x1d4)]=!0x1,this['_connecting']=!0x0,this[_0x3acaae(0x190)]++,this['_ws']=new Promise((_0xe91df5,_0x2af251)=>{const _0x59c8cb=_0x3acaae;this[_0x59c8cb(0x1c9)]()['then'](_0x2733eb=>{const _0x5833c7=_0x59c8cb;let _0x453861=new _0x2733eb('ws://'+(!this[_0x5833c7(0x168)]&&this['dockerizedApp']?_0x5833c7(0x192):this[_0x5833c7(0x15a)])+':'+this['port']);_0x453861[_0x5833c7(0x176)]=()=>{const _0x46ca94=_0x5833c7;this[_0x46ca94(0x158)]=!0x1,this[_0x46ca94(0x1bd)](_0x453861),this[_0x46ca94(0x19c)](),_0x2af251(new Error(_0x46ca94(0x1bf)));},_0x453861[_0x5833c7(0x17d)]=()=>{const _0x2c4d7b=_0x5833c7;this[_0x2c4d7b(0x168)]||_0x453861[_0x2c4d7b(0x167)]&&_0x453861[_0x2c4d7b(0x167)][_0x2c4d7b(0x1b6)]&&_0x453861['_socket']['unref'](),_0xe91df5(_0x453861);},_0x453861[_0x5833c7(0x157)]=()=>{const _0x408d79=_0x5833c7;this[_0x408d79(0x1d4)]=!0x0,this[_0x408d79(0x1bd)](_0x453861),this[_0x408d79(0x19c)]();},_0x453861[_0x5833c7(0x1b0)]=_0x4c123b=>{const _0x356c32=_0x5833c7;try{if(!(_0x4c123b!=null&&_0x4c123b[_0x356c32(0x172)])||!this[_0x356c32(0x1a4)])return;let _0x356bea=JSON[_0x356c32(0x163)](_0x4c123b[_0x356c32(0x172)]);this['eventReceivedCallback'](_0x356bea[_0x356c32(0x18a)],_0x356bea[_0x356c32(0x1c3)],this['global'],this['_inBrowser']);}catch{}};})[_0x59c8cb(0x174)](_0x2c6751=>(this['_connected']=!0x0,this[_0x59c8cb(0x178)]=!0x1,this[_0x59c8cb(0x1d4)]=!0x1,this[_0x59c8cb(0x158)]=!0x0,this[_0x59c8cb(0x190)]=0x0,_0x2c6751))[_0x59c8cb(0x1d7)](_0x2d5691=>(this[_0x59c8cb(0x19d)]=!0x1,this[_0x59c8cb(0x178)]=!0x1,console[_0x59c8cb(0x1b9)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x59c8cb(0x1b7)]),_0x2af251(new Error(_0x59c8cb(0x17f)+(_0x2d5691&&_0x2d5691[_0x59c8cb(0x1aa)])))));}));},k['prototype'][_0x3d84fa(0x1bd)]=function(_0xf778f9){const _0x23b35c=_0x3d84fa;this[_0x23b35c(0x19d)]=!0x1,this[_0x23b35c(0x178)]=!0x1;try{_0xf778f9['onclose']=null,_0xf778f9[_0x23b35c(0x176)]=null,_0xf778f9[_0x23b35c(0x17d)]=null;}catch{}try{_0xf778f9['readyState']<0x2&&_0xf778f9[_0x23b35c(0x1d8)]();}catch{}},k[_0x3d84fa(0x1cb)][_0x3d84fa(0x19c)]=function(){const _0xad4a56=_0x3d84fa;clearTimeout(this['_reconnectTimeout']),!(this[_0xad4a56(0x190)]>=this[_0xad4a56(0x1d0)])&&(this[_0xad4a56(0x1c0)]=setTimeout(()=>{const _0x116ba2=_0xad4a56;var _0x4557ed;this['_connected']||this[_0x116ba2(0x178)]||(this[_0x116ba2(0x18e)](),(_0x4557ed=this[_0x116ba2(0x197)])==null||_0x4557ed[_0x116ba2(0x1d7)](()=>this[_0x116ba2(0x19c)]()));},0x1f4),this[_0xad4a56(0x1c0)]['unref']&&this[_0xad4a56(0x1c0)]['unref']());},k[_0x3d84fa(0x1cb)][_0x3d84fa(0x1ce)]=async function(_0x85abc2){const _0x29c609=_0x3d84fa;try{if(!this[_0x29c609(0x158)])return;this[_0x29c609(0x1d4)]&&this['_connectToHostNow'](),(await this['_ws'])['send'](JSON['stringify'](_0x85abc2));}catch(_0x131095){this[_0x29c609(0x196)]?console['warn'](this[_0x29c609(0x181)]+':\\x20'+(_0x131095&&_0x131095['message'])):(this[_0x29c609(0x196)]=!0x0,console[_0x29c609(0x1b9)](this[_0x29c609(0x181)]+':\\x20'+(_0x131095&&_0x131095[_0x29c609(0x1aa)]),_0x85abc2)),this[_0x29c609(0x158)]=!0x1,this['_attemptToReconnectShortly']();}};function C(_0x1ed26c,_0x10f918,_0x389121,_0x17ec4a,_0x4aaadd,_0x3d423d,_0x50e2e1,_0x32abb5=x){const _0x4e4b2a=_0x3d84fa;let _0x2e8118=_0x389121[_0x4e4b2a(0x1d5)](',')[_0x4e4b2a(0x188)](_0x116edd=>{const _0xbb7be9=_0x4e4b2a;var _0x311d0a,_0x41eb32,_0x5399d3,_0x2f0bae,_0x54ffa4,_0x4c07b0,_0x24a722,_0x26f178;try{if(!_0x1ed26c[_0xbb7be9(0x15f)]){let _0x18846c=((_0x41eb32=(_0x311d0a=_0x1ed26c[_0xbb7be9(0x1b1)])==null?void 0x0:_0x311d0a[_0xbb7be9(0x1d6)])==null?void 0x0:_0x41eb32[_0xbb7be9(0x16b)])||((_0x2f0bae=(_0x5399d3=_0x1ed26c[_0xbb7be9(0x1b1)])==null?void 0x0:_0x5399d3['env'])==null?void 0x0:_0x2f0bae['NEXT_RUNTIME'])===_0xbb7be9(0x1b8);(_0x4aaadd===_0xbb7be9(0x1a2)||_0x4aaadd===_0xbb7be9(0x161)||_0x4aaadd===_0xbb7be9(0x1a3)||_0x4aaadd===_0xbb7be9(0x1a1))&&(_0x4aaadd+=_0x18846c?_0xbb7be9(0x185):_0xbb7be9(0x18f));let _0x427231='';_0x4aaadd===_0xbb7be9(0x169)&&(_0x427231=(((_0x24a722=(_0x4c07b0=(_0x54ffa4=_0x1ed26c[_0xbb7be9(0x164)])==null?void 0x0:_0x54ffa4[_0xbb7be9(0x199)])==null?void 0x0:_0x4c07b0[_0xbb7be9(0x1c8)])==null?void 0x0:_0x24a722['osName'])||'emulator')[_0xbb7be9(0x16f)](),_0x427231&&(_0x4aaadd+='\\x20'+_0x427231,(_0x427231===_0xbb7be9(0x160)||_0x427231===_0xbb7be9(0x19a)&&((_0x26f178=_0x1ed26c[_0xbb7be9(0x1c2)])==null?void 0x0:_0x26f178[_0xbb7be9(0x1d2)])===_0xbb7be9(0x15c))&&(_0x10f918=_0xbb7be9(0x15c)))),_0x1ed26c[_0xbb7be9(0x15f)]={'id':+new Date(),'tool':_0x4aaadd},_0x50e2e1&&_0x4aaadd&&!_0x18846c&&(_0x427231?console[_0xbb7be9(0x1b4)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x427231+',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'):console['log'](_0xbb7be9(0x16e)+(_0x4aaadd[_0xbb7be9(0x16c)](0x0)[_0xbb7be9(0x170)]()+_0x4aaadd[_0xbb7be9(0x191)](0x1))+',',_0xbb7be9(0x159),_0xbb7be9(0x1b3)));}let _0x14a5b9=new k(_0x1ed26c,_0x10f918,_0x116edd,_0x17ec4a,_0x3d423d,_0x32abb5);return _0x14a5b9[_0xbb7be9(0x1ce)][_0xbb7be9(0x18b)](_0x14a5b9);}catch(_0x1c61fb){return console[_0xbb7be9(0x1b9)](_0xbb7be9(0x1d1),_0x1c61fb&&_0x1c61fb[_0xbb7be9(0x1aa)]),()=>{};}});return _0x196627=>_0x2e8118[_0x4e4b2a(0x18c)](_0x2d970b=>_0x2d970b(_0x196627));}function x(_0x2d079c,_0x1a2381,_0x1eadb3,_0x101c21){const _0x10278a=_0x3d84fa;_0x101c21&&_0x2d079c===_0x10278a(0x1a6)&&_0x1eadb3[_0x10278a(0x1c2)][_0x10278a(0x1a6)]();}function g(_0x31516e,_0x201cd4,_0x1e9b47){const _0x3fa331=_0x3d84fa;var _0x1d973e,_0x59c9d9,_0x11ee20,_0x1a3a55,_0x44316b,_0x19fb42,_0x13fc85;if(_0x31516e[_0x3fa331(0x183)]!==void 0x0)return _0x31516e[_0x3fa331(0x183)];let _0x412f11=((_0x59c9d9=(_0x1d973e=_0x31516e[_0x3fa331(0x1b1)])==null?void 0x0:_0x1d973e[_0x3fa331(0x1d6)])==null?void 0x0:_0x59c9d9['node'])||((_0x1a3a55=(_0x11ee20=_0x31516e[_0x3fa331(0x1b1)])==null?void 0x0:_0x11ee20[_0x3fa331(0x166)])==null?void 0x0:_0x1a3a55[_0x3fa331(0x1cf)])===_0x3fa331(0x1b8),_0x53319c=!!(_0x1e9b47===_0x3fa331(0x169)&&((_0x44316b=_0x31516e[_0x3fa331(0x164)])==null?void 0x0:_0x44316b[_0x3fa331(0x199)]));function _0x1a203f(_0x23e95e){const _0x315cb8=_0x3fa331;if(_0x23e95e[_0x315cb8(0x17c)]('/')&&_0x23e95e[_0x315cb8(0x189)]('/')){let _0x29db20=new RegExp(_0x23e95e['slice'](0x1,-0x1));return _0x55e575=>_0x29db20[_0x315cb8(0x1cd)](_0x55e575);}else{if(_0x23e95e[_0x315cb8(0x180)]('*')||_0x23e95e['includes']('?')){let _0x252cbf=new RegExp('^'+_0x23e95e[_0x315cb8(0x175)](/\\./g,String[_0x315cb8(0x1ae)](0x5c)+'.')[_0x315cb8(0x175)](/\\*/g,'.*')[_0x315cb8(0x175)](/\\?/g,'.')+String[_0x315cb8(0x1ae)](0x24));return _0x272199=>_0x252cbf[_0x315cb8(0x1cd)](_0x272199);}else return _0x281ce5=>_0x281ce5===_0x23e95e;}}let _0x8adbc2=_0x201cd4[_0x3fa331(0x188)](_0x1a203f);return _0x31516e['_consoleNinjaAllowedToStart']=_0x412f11||!_0x201cd4,!_0x31516e[_0x3fa331(0x183)]&&((_0x19fb42=_0x31516e[_0x3fa331(0x1c2)])==null?void 0x0:_0x19fb42['hostname'])&&(_0x31516e[_0x3fa331(0x183)]=_0x8adbc2['some'](_0x3eea1b=>_0x3eea1b(_0x31516e[_0x3fa331(0x1c2)][_0x3fa331(0x1d2)]))),_0x53319c&&!_0x31516e[_0x3fa331(0x183)]&&!((_0x13fc85=_0x31516e['location'])!=null&&_0x13fc85['hostname'])&&(_0x31516e[_0x3fa331(0x183)]=!0x0),_0x31516e[_0x3fa331(0x183)];}((_0x37b252,_0x4b17cf,_0x5baecc,_0x4507a9,_0x45b219,_0x4dec6e,_0x3a75d4,_0x12f93b,_0x35e55d,_0x45cf02,_0x12a68e,_0x33f857)=>{const _0x4c5eaf=_0x3d84fa;if(!g(_0x37b252,_0x12f93b,_0x4dec6e)){_0x37b252[_0x4c5eaf(0x15d)]=!0x0;return;}if(_0x37b252[_0x4c5eaf(0x15d)])return;_0x37b252[_0x4c5eaf(0x15d)]=!0x0;let _0x4d5f02=C(_0x37b252,_0x4b17cf,_0x5baecc,_0x4507a9,_0x4dec6e,_0x35e55d,_0x45cf02),_0x49d31d=_0x37b252[_0x4c5eaf(0x15f)],_0x49c1b6=_0x13deac=>{const _0x12187a=_0x4c5eaf;if(_0x37b252[_0x12187a(0x187)]){delete _0x37b252[_0x12187a(0x187)];return;}if(_0x13deac){if(_0x13deac===_0x37b252[_0x12187a(0x1ab)]){delete _0x37b252[_0x12187a(0x1ab)];return;}else delete _0x37b252[_0x12187a(0x1ab)];let _0x1dd23d=_0x13deac[_0x12187a(0x1aa)]||'',_0x1ca98b=_0x13deac[_0x12187a(0x1c5)]||'',_0x1d2030;!_0x1dd23d&&!_0x1ca98b&&(_0x1dd23d=typeof _0x13deac==_0x12187a(0x165)?_0x13deac:_0x12187a(0x198),_0x1ca98b=new Error()[_0x12187a(0x1c5)],_0x1d2030=!0x0);let _0x2d3b58=_0x4dec6e===_0x12187a(0x1a2)&&_0x37b252[_0x12187a(0x15b)]?{'origin':_0x37b252[_0x12187a(0x15b)]}:{};_0x4d5f02({'method':_0x12187a(0x1bc),'version':_0x45b219,'args':[{'ts':Date['now'](),'session':_0x49d31d,'message':_0x1dd23d,'stack':_0x1ca98b,'generatedStack':_0x1d2030,'stackTraceLimit':Error[_0x12187a(0x171)],..._0x2d3b58}]});}};if(_0x37b252[_0x4c5eaf(0x1ba)][_0x4c5eaf(0x1bc)]=(_0x11b66b=>(..._0x47ba6b)=>{const _0x292e71=_0x4c5eaf;let _0x42eb2b=_0x47ba6b[0x0];return _0x47ba6b&&_0x47ba6b[_0x292e71(0x162)]>0x1&&(_0x42eb2b=_0x47ba6b['find'](_0x31376a=>_0x31376a['stack'])||_0x42eb2b),_0x49c1b6(_0x42eb2b),_0x11b66b(..._0x47ba6b);})(_0x37b252['console'][_0x4c5eaf(0x1bc)]),_0x37b252[_0x4c5eaf(0x1b1)]&&_0x37b252[_0x4c5eaf(0x1b1)]['on'])_0x37b252[_0x4c5eaf(0x1b1)]['on']('uncaughtException',_0x49c1b6),_0x37b252[_0x4c5eaf(0x1b1)]['on'](_0x4c5eaf(0x177),_0x49c1b6);else{if(_0x37b252[_0x4c5eaf(0x16d)]){let _0x1fcca3=_0x58beb3=>{const _0x10bc32=_0x4c5eaf;let _0x43f1dd=_0x58beb3&&(_0x58beb3[_0x10bc32(0x1bc)]||_0x58beb3[_0x10bc32(0x19b)]);_0x49c1b6(_0x43f1dd);};_0x37b252[_0x4c5eaf(0x16d)](_0x4c5eaf(0x1bc),_0x1fcca3),_0x37b252[_0x4c5eaf(0x16d)](_0x4c5eaf(0x182),_0x1fcca3);}}try{Error['stackTraceLimit']=Math['max'](Error['stackTraceLimit'],0x14),_0x37b252[_0x4c5eaf(0x1d3)]=!0x0;}catch{}let _0x5ae495;_0x4dec6e===_0x4c5eaf(0x1a2)&&_0x37b252[_0x4c5eaf(0x1c6)]&&_0x33f857&&_0x33f857[_0x4c5eaf(0x17b)]&&(_0x5ae495={'nextJsDistDir':_0x33f857[_0x4c5eaf(0x17b)]}),_0x4d5f02({'method':'errorHandlerInstalled','version':_0x45b219,'args':[_0x49d31d,_0x5ae495]});})(globalThis,_0x3d84fa(0x1b2),_0x3d84fa(0x1ad),_0x3d84fa(0x17e),_0x3d84fa(0x19e),'next.js',_0x3d84fa(0x15e),_0x3d84fa(0x1b5),_0x3d84fa(0x1a9),'1',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},_0x3d84fa(0x16a));function _0x345d(){const _0xe655b7=['toLowerCase','toUpperCase','stackTraceLimit','data','1506702YDHHRM','then','replace','onerror','unhandledRejection','_connecting','14qjCQZY','import(\\x27url\\x27)','nextJsDistDir','startsWith','onopen',\"/Users/abdelberkat/.vscode/extensions/wallabyjs.console-ninja-1.0.517/node_modules\",'failed\\x20to\\x20connect\\x20to\\x20host:\\x20','includes','_sendErrorMessage','unhandledrejection','_consoleNinjaAllowedToStart','url','\\x20server','630039dcSEwD','_ninjaIgnoreNextError','map','endsWith','method','bind','forEach','_WebSocket','_connectToHostNow','\\x20browser','_connectAttemptCount','substr','gateway.docker.internal','1390736FSnDcB','global','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','_extendedWarning','_ws','Unknown\\x20error','modules','emulator','reason','_attemptToReconnectShortly','_connected','1.0.0','9208BxNrEq','7779620ekwRGr','angular','next.js','astro','eventReceivedCallback','_WebSocketClass','reload','default','path','','message','_ninjaIgnoreError','https://tinyurl.com/37x8b79t','60766','fromCharCode','dockerizedApp','onmessage','process','127.0.0.1','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','log',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"mac-4.home\",\"192.168.1.28\"],'unref','_webSocketErrorDocsLink','edge','warn','console','88cvmukw','error','_disposeWebsocket','391635XhoAZV','logger\\x20websocket\\x20error','_reconnectTimeout','5BuqgQp','location','args','_inNextEdge','stack','TURBOPACK','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','ExpoDevice','getWebSocketClass','177036LxDauv','prototype','nodeModules','test','send','NEXT_RUNTIME','_maxConnectAttemptCount','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','hostname','_ninjaInstallGlobalErrorHandler','_allowedToConnectOnSend','split','versions','catch','close','onclose','_allowedToSend','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','host','origin','10.0.2.2','_triedToInstallGlobalErrorHandler','1772625039934','_console_ninja_session','android','remix','length','parse','expo','string','env','_socket','_inBrowser','react-native',{\"nextJsDistDir\":\"/Users/abdelberkat/projets/synea/.next/dev\"},'node','charAt','addEventListener','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'];_0x345d=function(){return _0xe655b7;};return _0x345d();}");
} catch (e) {
    console.error(e);
}
try {
    (0, eval)("globalThis._triedToInstallNetworkLoggingHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0x314333=_0x437c;(function(_0x368d45,_0x101087){const _0x206e58=_0x437c,_0xd32058=_0x368d45();while(!![]){try{const _0x3bb81c=-parseInt(_0x206e58(0x165))/0x1*(parseInt(_0x206e58(0x13d))/0x2)+parseInt(_0x206e58(0x17f))/0x3*(-parseInt(_0x206e58(0x13a))/0x4)+-parseInt(_0x206e58(0x94))/0x5+parseInt(_0x206e58(0x118))/0x6*(parseInt(_0x206e58(0x143))/0x7)+parseInt(_0x206e58(0x97))/0x8*(parseInt(_0x206e58(0x12b))/0x9)+parseInt(_0x206e58(0x11c))/0xa*(-parseInt(_0x206e58(0x8d))/0xb)+parseInt(_0x206e58(0xe3))/0xc*(parseInt(_0x206e58(0x16a))/0xd);if(_0x3bb81c===_0x101087)break;else _0xd32058['push'](_0xd32058['shift']());}catch(_0x1d903b){_0xd32058['push'](_0xd32058['shift']());}}}(_0x2701,0xa2780));function X(_0x104dc8,_0x255da7,_0x46dff6,_0x30756c,_0x1a369b,_0x522279){const _0xd7fba2=_0x437c;var _0x4898a3,_0x424dd4,_0xbad999,_0x3b3170;this[_0xd7fba2(0x174)]=_0x104dc8,this[_0xd7fba2(0x1a7)]=_0x255da7,this[_0xd7fba2(0x19e)]=_0x46dff6,this[_0xd7fba2(0x142)]=_0x30756c,this['dockerizedApp']=_0x1a369b,this['eventReceivedCallback']=_0x522279,this['_allowedToSend']=!0x0,this[_0xd7fba2(0xe6)]=!0x0,this[_0xd7fba2(0x17b)]=!0x1,this['_connecting']=!0x1,this[_0xd7fba2(0xbc)]=((_0x424dd4=(_0x4898a3=_0x104dc8[_0xd7fba2(0xc6)])==null?void 0x0:_0x4898a3[_0xd7fba2(0x13b)])==null?void 0x0:_0x424dd4[_0xd7fba2(0x194)])===_0xd7fba2(0x199),this[_0xd7fba2(0x162)]=!((_0x3b3170=(_0xbad999=this[_0xd7fba2(0x174)][_0xd7fba2(0xc6)])==null?void 0x0:_0xbad999[_0xd7fba2(0x103)])!=null&&_0x3b3170[_0xd7fba2(0x14f)])&&!this[_0xd7fba2(0xbc)],this['_WebSocketClass']=null,this[_0xd7fba2(0xd8)]=0x0,this[_0xd7fba2(0xe7)]=0x14,this[_0xd7fba2(0x7e)]=_0xd7fba2(0x173),this[_0xd7fba2(0x12c)]=(this[_0xd7fba2(0x162)]?_0xd7fba2(0x186):_0xd7fba2(0x131))+this[_0xd7fba2(0x7e)];}X['prototype'][_0x314333(0x85)]=async function(){const _0x301d23=_0x314333;var _0x490c45,_0xc7e5ba;if(this[_0x301d23(0x192)])return this['_WebSocketClass'];let _0x65f155;if(this[_0x301d23(0x162)]||this[_0x301d23(0xbc)])_0x65f155=this[_0x301d23(0x174)][_0x301d23(0x12f)];else{if((_0x490c45=this[_0x301d23(0x174)][_0x301d23(0xc6)])!=null&&_0x490c45[_0x301d23(0x193)])_0x65f155=(_0xc7e5ba=this[_0x301d23(0x174)][_0x301d23(0xc6)])==null?void 0x0:_0xc7e5ba['_WebSocket'];else try{_0x65f155=(await new Function(_0x301d23(0x1a4),_0x301d23(0x18e),_0x301d23(0x142),_0x301d23(0x7a))(await(0x0,eval)(_0x301d23(0x79)),await(0x0,eval)(_0x301d23(0x1a8)),this[_0x301d23(0x142)]))['default'];}catch{try{_0x65f155=require(require(_0x301d23(0x1a4))[_0x301d23(0xc8)](this[_0x301d23(0x142)],'ws'));}catch{throw new Error(_0x301d23(0x168));}}}return this['_WebSocketClass']=_0x65f155,_0x65f155;},X[_0x314333(0x1a9)][_0x314333(0x19c)]=function(){const _0x3310e5=_0x314333;this[_0x3310e5(0xc4)]||this[_0x3310e5(0x17b)]||this[_0x3310e5(0xd8)]>=this[_0x3310e5(0xe7)]||(this[_0x3310e5(0xe6)]=!0x1,this[_0x3310e5(0xc4)]=!0x0,this[_0x3310e5(0xd8)]++,this[_0x3310e5(0x11f)]=new Promise((_0x4332cc,_0x39e927)=>{const _0x4049ed=_0x3310e5;this[_0x4049ed(0x85)]()['then'](_0x536794=>{const _0x1d9663=_0x4049ed;let _0x5c2571=new _0x536794(_0x1d9663(0xbe)+(!this['_inBrowser']&&this[_0x1d9663(0xd2)]?_0x1d9663(0xa5):this[_0x1d9663(0x1a7)])+':'+this[_0x1d9663(0x19e)]);_0x5c2571[_0x1d9663(0xfc)]=()=>{const _0x3a70c7=_0x1d9663;this[_0x3a70c7(0x155)]=!0x1,this[_0x3a70c7(0x7b)](_0x5c2571),this['_attemptToReconnectShortly'](),_0x39e927(new Error(_0x3a70c7(0xc2)));},_0x5c2571[_0x1d9663(0xfa)]=()=>{const _0xdd9c4d=_0x1d9663;this['_inBrowser']||_0x5c2571[_0xdd9c4d(0x153)]&&_0x5c2571[_0xdd9c4d(0x153)][_0xdd9c4d(0xcf)]&&_0x5c2571[_0xdd9c4d(0x153)][_0xdd9c4d(0xcf)](),_0x4332cc(_0x5c2571);},_0x5c2571['onclose']=()=>{const _0x3aede3=_0x1d9663;this[_0x3aede3(0xe6)]=!0x0,this[_0x3aede3(0x7b)](_0x5c2571),this[_0x3aede3(0x137)]();},_0x5c2571[_0x1d9663(0x121)]=_0x5d23e5=>{const _0x1bd827=_0x1d9663;try{if(!(_0x5d23e5!=null&&_0x5d23e5[_0x1bd827(0x87)])||!this[_0x1bd827(0x8b)])return;let _0xef0232=JSON[_0x1bd827(0xcd)](_0x5d23e5[_0x1bd827(0x87)]);this[_0x1bd827(0x8b)](_0xef0232[_0x1bd827(0x19d)],_0xef0232[_0x1bd827(0xa9)],this[_0x1bd827(0x174)],this[_0x1bd827(0x162)]);}catch{}};})[_0x4049ed(0x90)](_0x22f082=>(this[_0x4049ed(0x17b)]=!0x0,this[_0x4049ed(0xc4)]=!0x1,this[_0x4049ed(0xe6)]=!0x1,this[_0x4049ed(0x155)]=!0x0,this[_0x4049ed(0xd8)]=0x0,_0x22f082))[_0x4049ed(0xf1)](_0x128eec=>(this[_0x4049ed(0x17b)]=!0x1,this[_0x4049ed(0xc4)]=!0x1,console[_0x4049ed(0x11b)](_0x4049ed(0x96)+this[_0x4049ed(0x7e)]),_0x39e927(new Error('failed\\x20to\\x20connect\\x20to\\x20host:\\x20'+(_0x128eec&&_0x128eec['message'])))));}));},X['prototype'][_0x314333(0x7b)]=function(_0x1e6f1e){const _0x594fe8=_0x314333;this[_0x594fe8(0x17b)]=!0x1,this[_0x594fe8(0xc4)]=!0x1;try{_0x1e6f1e[_0x594fe8(0x74)]=null,_0x1e6f1e[_0x594fe8(0xfc)]=null,_0x1e6f1e['onopen']=null;}catch{}try{_0x1e6f1e['readyState']<0x2&&_0x1e6f1e['close']();}catch{}},X[_0x314333(0x1a9)][_0x314333(0x137)]=function(){const _0x1a57b3=_0x314333;clearTimeout(this[_0x1a57b3(0x13f)]),!(this[_0x1a57b3(0xd8)]>=this[_0x1a57b3(0xe7)])&&(this[_0x1a57b3(0x13f)]=setTimeout(()=>{const _0x48921d=_0x1a57b3;var _0x3fb183;this[_0x48921d(0x17b)]||this[_0x48921d(0xc4)]||(this[_0x48921d(0x19c)](),(_0x3fb183=this[_0x48921d(0x11f)])==null||_0x3fb183[_0x48921d(0xf1)](()=>this['_attemptToReconnectShortly']()));},0x1f4),this[_0x1a57b3(0x13f)][_0x1a57b3(0xcf)]&&this[_0x1a57b3(0x13f)][_0x1a57b3(0xcf)]());},X['prototype'][_0x314333(0x17d)]=async function(_0x4ea559){const _0x2b7dcb=_0x314333;try{if(!this[_0x2b7dcb(0x155)])return;this[_0x2b7dcb(0xe6)]&&this[_0x2b7dcb(0x19c)](),(await this[_0x2b7dcb(0x11f)])[_0x2b7dcb(0x17d)](JSON[_0x2b7dcb(0xa8)](_0x4ea559));}catch(_0xf894f6){this[_0x2b7dcb(0xf3)]?console[_0x2b7dcb(0x11b)](this[_0x2b7dcb(0x12c)]+':\\x20'+(_0xf894f6&&_0xf894f6[_0x2b7dcb(0x15c)])):(this[_0x2b7dcb(0xf3)]=!0x0,console['warn'](this[_0x2b7dcb(0x12c)]+':\\x20'+(_0xf894f6&&_0xf894f6[_0x2b7dcb(0x15c)]),_0x4ea559)),this[_0x2b7dcb(0x155)]=!0x1,this[_0x2b7dcb(0x137)]();}};function Z(_0x10ce7a,_0x24ce2d,_0x565193,_0x27e3c8,_0x1717b8,_0x500a04,_0x186ba1,_0x580940=V){const _0x3e4e53=_0x314333;let _0x3a9948=_0x565193[_0x3e4e53(0x102)](',')['map'](_0x2c44c1=>{const _0x10fee9=_0x3e4e53;var _0x28abc5,_0x1d06a0,_0x3c3341,_0x6acfd0,_0x51c758,_0x2d0c15,_0x2fb061,_0x4812c1;try{if(!_0x10ce7a[_0x10fee9(0x113)]){let _0x33803c=((_0x1d06a0=(_0x28abc5=_0x10ce7a[_0x10fee9(0xc6)])==null?void 0x0:_0x28abc5[_0x10fee9(0x103)])==null?void 0x0:_0x1d06a0[_0x10fee9(0x14f)])||((_0x6acfd0=(_0x3c3341=_0x10ce7a[_0x10fee9(0xc6)])==null?void 0x0:_0x3c3341[_0x10fee9(0x13b)])==null?void 0x0:_0x6acfd0[_0x10fee9(0x194)])===_0x10fee9(0x199);(_0x1717b8===_0x10fee9(0xc7)||_0x1717b8===_0x10fee9(0x14c)||_0x1717b8==='astro'||_0x1717b8===_0x10fee9(0xf6))&&(_0x1717b8+=_0x33803c?'\\x20server':_0x10fee9(0xc9));let _0xbb8032='';_0x1717b8==='react-native'&&(_0xbb8032=(((_0x2fb061=(_0x2d0c15=(_0x51c758=_0x10ce7a[_0x10fee9(0xa1)])==null?void 0x0:_0x51c758[_0x10fee9(0xce)])==null?void 0x0:_0x2d0c15['ExpoDevice'])==null?void 0x0:_0x2fb061[_0x10fee9(0x76)])||_0x10fee9(0xeb))[_0x10fee9(0x167)](),_0xbb8032&&(_0x1717b8+='\\x20'+_0xbb8032,(_0xbb8032===_0x10fee9(0x8c)||_0xbb8032===_0x10fee9(0xeb)&&((_0x4812c1=_0x10ce7a[_0x10fee9(0x14d)])==null?void 0x0:_0x4812c1[_0x10fee9(0x1ac)])===_0x10fee9(0x198))&&(_0x24ce2d=_0x10fee9(0x198)))),_0x10ce7a[_0x10fee9(0x113)]={'id':+new Date(),'tool':_0x1717b8},_0x186ba1&&_0x1717b8&&!_0x33803c&&(_0xbb8032?console[_0x10fee9(0xbb)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0xbb8032+_0x10fee9(0x17a)):console[_0x10fee9(0xbb)](_0x10fee9(0xe9)+(_0x1717b8[_0x10fee9(0x154)](0x0)[_0x10fee9(0x7c)]()+_0x1717b8[_0x10fee9(0x13e)](0x1))+',',_0x10fee9(0x180),_0x10fee9(0x11a)));}let _0xbb1e95=new X(_0x10ce7a,_0x24ce2d,_0x2c44c1,_0x27e3c8,_0x500a04,_0x580940);return _0xbb1e95[_0x10fee9(0x17d)][_0x10fee9(0x10d)](_0xbb1e95);}catch(_0xb7f27a){return console[_0x10fee9(0x11b)](_0x10fee9(0xed),_0xb7f27a&&_0xb7f27a[_0x10fee9(0x15c)]),()=>{};}});return _0x2f5082=>_0x3a9948[_0x3e4e53(0xb2)](_0x91485e=>_0x91485e(_0x2f5082));}function V(_0x58a8b5,_0x3a11f9,_0x453887,_0x5bddd8){const _0x482fe5=_0x314333;_0x5bddd8&&_0x58a8b5===_0x482fe5(0x77)&&_0x453887[_0x482fe5(0x14d)]['reload']();}function Y(_0xca5a24,_0x337e3d,_0x2bbd1f){const _0xfdcba7=_0x314333;var _0x348cd0,_0x62d7fd,_0x1e2748,_0x1a4981,_0x5bbc9d,_0x525574,_0x29faf2;if(_0xca5a24[_0xfdcba7(0xd1)]!==void 0x0)return _0xca5a24[_0xfdcba7(0xd1)];let _0x53b780=((_0x62d7fd=(_0x348cd0=_0xca5a24[_0xfdcba7(0xc6)])==null?void 0x0:_0x348cd0[_0xfdcba7(0x103)])==null?void 0x0:_0x62d7fd[_0xfdcba7(0x14f)])||((_0x1a4981=(_0x1e2748=_0xca5a24[_0xfdcba7(0xc6)])==null?void 0x0:_0x1e2748[_0xfdcba7(0x13b)])==null?void 0x0:_0x1a4981[_0xfdcba7(0x194)])==='edge',_0x11db5b=!!(_0x2bbd1f===_0xfdcba7(0x10a)&&((_0x5bbc9d=_0xca5a24[_0xfdcba7(0xa1)])==null?void 0x0:_0x5bbc9d[_0xfdcba7(0xce)]));function _0x3e6be2(_0x477676){const _0x26fe8d=_0xfdcba7;if(_0x477676[_0x26fe8d(0xab)]('/')&&_0x477676['endsWith']('/')){let _0x49fd59=new RegExp(_0x477676[_0x26fe8d(0x114)](0x1,-0x1));return _0x4c0640=>_0x49fd59[_0x26fe8d(0x112)](_0x4c0640);}else{if(_0x477676['includes']('*')||_0x477676[_0x26fe8d(0x136)]('?')){let _0x16f6c3=new RegExp('^'+_0x477676['replace'](/\\./g,String[_0x26fe8d(0x1ab)](0x5c)+'.')['replace'](/\\*/g,'.*')[_0x26fe8d(0x116)](/\\?/g,'.')+String[_0x26fe8d(0x1ab)](0x24));return _0x516e6c=>_0x16f6c3[_0x26fe8d(0x112)](_0x516e6c);}else return _0x4a06e4=>_0x4a06e4===_0x477676;}}let _0x493213=_0x337e3d[_0xfdcba7(0x110)](_0x3e6be2);return _0xca5a24[_0xfdcba7(0xd1)]=_0x53b780||!_0x337e3d,!_0xca5a24[_0xfdcba7(0xd1)]&&((_0x525574=_0xca5a24['location'])==null?void 0x0:_0x525574['hostname'])&&(_0xca5a24[_0xfdcba7(0xd1)]=_0x493213['some'](_0xf58e6d=>_0xf58e6d(_0xca5a24['location'][_0xfdcba7(0x1ac)]))),_0x11db5b&&!_0xca5a24['_consoleNinjaAllowedToStart']&&!((_0x29faf2=_0xca5a24[_0xfdcba7(0x14d)])!=null&&_0x29faf2[_0xfdcba7(0x1ac)])&&(_0xca5a24[_0xfdcba7(0xd1)]=!0x0),_0xca5a24[_0xfdcba7(0xd1)];}function G(_0x44b682){const _0x4af337=_0x314333;var _0x24dafc,_0x2e3de7;let _0x4820ff=function(_0x44e6de,_0x49a499){return _0x49a499-_0x44e6de;},_0x568d17;if(_0x44b682[_0x4af337(0xb5)])_0x568d17=function(){const _0x849a2c=_0x4af337;return _0x44b682[_0x849a2c(0xb5)][_0x849a2c(0x14b)]();};else{if(_0x44b682['process']&&_0x44b682[_0x4af337(0xc6)][_0x4af337(0x1a1)]&&((_0x2e3de7=(_0x24dafc=_0x44b682['process'])==null?void 0x0:_0x24dafc[_0x4af337(0x13b)])==null?void 0x0:_0x2e3de7[_0x4af337(0x194)])!==_0x4af337(0x199))_0x568d17=function(){const _0x40b021=_0x4af337;return _0x44b682[_0x40b021(0xc6)][_0x40b021(0x1a1)]();},_0x4820ff=function(_0x12aced,_0x52d392){return 0x3e8*(_0x52d392[0x0]-_0x12aced[0x0])+(_0x52d392[0x1]-_0x12aced[0x1])/0xf4240;};else try{let {performance:_0x2b512a}=require(_0x4af337(0x7d));_0x568d17=function(){const _0x45a756=_0x4af337;return _0x2b512a[_0x45a756(0x14b)]();};}catch{_0x568d17=function(){return+new Date();};}}return{'elapsed':_0x4820ff,'timeStamp':_0x568d17,'now':()=>Date[_0x4af337(0x14b)]()};}function _0x2701(){const _0x4958a6=['test','_console_ninja_session','slice','allStrLength','replace','unknown','6hVUhFG','Symbol','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','warn','730OEdRCc','json','60766','_ws','1772625039934','onmessage','readystatechange','timeStamp','[object\\x20Map]','sortProps','find','date','ArrayBuffer','_objectToString','autoExpandPreviousObjects','4109202xbeFjN','_sendErrorMessage','_setNodeExpandableState','totalStrLength','WebSocket','get','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','networkLoggingHandlerInstalled','props','type','_setNodeLabel','includes','_attemptToReconnectShortly','hits','_type','87964bDkxqx','env','DataView','748582KrPswq','substr','_reconnectTimeout','_capIfString','_addLoadNode','nodeModules','7256599OcjBzh','splice','GET','setRequestHeader','count','files','_Symbol','_ninjaIgnoreError','now','remix','location','_propertyName','node','elements','[object\\x20Date]','value','_socket','charAt','_allowedToSend','headers','string','resetWhenQuietMs','setter','_blacklistedProperty','current','message','resetOnProcessingTimeAverageMs','HTMLAllCollection','native\\x20code','_property','_isUndefined','_inBrowser','autoExpand','reduceOnAccumulatedProcessingTimeMs','1aYILEQ','perLogpoint','toLowerCase','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','nan','13qtLHPg','getter','TypedArray','blacklistEntries','object','nextJsDistDir','_setNodeQueryPath','ReadableStream','body','https://tinyurl.com/37x8b79t','global','ninjaSuppressConsole','indexOf','expId','valueOf','openFiles',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_connected','elapsed','send','_cleanNode','93flsRSk','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'Map','positiveInfinity','number','getOwnPropertySymbols','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','[object\\x20BigInt]','length','Boolean','next.js\\x20browser','resolveGetters','reduceOnCount','origin','url','readyState','depth',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"mac-4.home\",\"192.168.1.28\"],'_WebSocketClass','_WebSocket','NEXT_RUNTIME','apply','call','[object\\x20Array]','10.0.2.2','edge','_hasSetOnItsPath','_treeNodePropertiesAfterFullValue','_connectToHostNow','method','port','Response','text','hrtime','time','response','path','.hot-update.json','_processTreeNodeResult','host','import(\\x27url\\x27)','prototype','funcName','fromCharCode','hostname','_triedToInstallNetworkLoggingHandler','_undefined','_hasSymbolPropertyOnItsPath','sort','onclose','autoExpandLimit','osName','reload','_isNegativeZero','import(\\x27path\\x27)','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','_disposeWebsocket','toUpperCase','perf_hooks','_webSocketErrorDocsLink','Set','_treeNodePropertiesBeforeFullValue','strLength','_keyStrRegExp','isExpressionToEvaluate','Error','getWebSocketClass','_hasMapOnItsPath','data','fetch','_addFunctionsNode','_isMap','eventReceivedCallback','android','73469PaBWBK','_ninjaInstallGlobalErrorHandler','_setNodeExpressionPath','then','_p_','blob','1.0.0','1130365gZxOyf','isArray','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','16QAnxNK','_isArray','_setNodePermissions','bigint','POSITIVE_INFINITY','root_exp','index','stackTraceLimit','parent','_getOwnPropertyNames','expo','autoExpandPropertyCount','unshift','1','gateway.docker.internal','array','network','stringify','args','updateNetworkLoggingConfig','startsWith','constructor','Number','XMLHttpRequest','[object\\x20Set]','console','arrayBuffer','forEach','_devMiddlewareManifest.json','defaultLimits','performance','undefined','hasOwnProperty','_isSet','_sortProps','content-type','log','_inNextEdge','_addProperty','ws://','entries','capped','getResponseHeader','logger\\x20websocket\\x20error','_p_length','_connecting','request','process','next.js','join','\\x20browser','_HTMLAllCollection','application/json','URLSearchParams','parse','modules','unref','some','_consoleNinjaAllowedToStart','dockerizedApp','name','negativeInfinity','angular\\x20browser','_regExpToString',\"/Users/abdelberkat/.vscode/extensions/wallabyjs.console-ninja-1.0.517/node_modules\",'_connectAttemptCount','_addObjectProperty','trace','_getOwnPropertySymbols','getOwnPropertyNames','Content-Type','reducePolicy','reduceLimits','captureRequests','fetchStack','_setNodeId','5823732uMYYhe','symbol','noFunctions','_allowedToConnectOnSend','_maxConnectAttemptCount','root_exp_id','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','status','emulator','_dateToString','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','level','autoExpandMaxDepth','rootExpression','catch','concat','_extendedWarning','_numberRegExp','stack','angular','next.js','match','open','onopen','_isPrimitiveType','onerror','_additionalMetadata','toString','','reducedLimits','error','split','versions','push','null','serialize','getOwnPropertyDescriptor','String','_getOwnPropertyDescriptor','react-native','function','tool','bind','_isPrimitiveWrapperType','pop','map','NEGATIVE_INFINITY'];_0x2701=function(){return _0x4958a6;};return _0x2701();}function K(_0xa02ceb,_0x4fbc07,_0x1cd00b,_0x3c945d,_0x36c600,_0x56cc80){const _0x1b9f59=_0x314333;_0xa02ceb=_0xa02ceb,_0x4fbc07=_0x4fbc07,_0x1cd00b=_0x1cd00b,_0x3c945d=_0x3c945d,_0x36c600=_0x36c600,_0x36c600=_0x36c600||{},_0x36c600['defaultLimits']=_0x36c600[_0x1b9f59(0xb4)]||{},_0x36c600['reducedLimits']=_0x36c600['reducedLimits']||{},_0x36c600[_0x1b9f59(0xde)]=_0x36c600[_0x1b9f59(0xde)]||{},_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x166)]=_0x36c600['reducePolicy']['perLogpoint']||{},_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x174)]=_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x174)]||{};let _0xaa8f90={'perLogpoint':{'reduceOnCount':_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x166)][_0x1b9f59(0x18c)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x166)]['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x36c600['reducePolicy']['perLogpoint'][_0x1b9f59(0x158)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x36c600[_0x1b9f59(0xde)]['perLogpoint'][_0x1b9f59(0x15d)]||0x64},'global':{'reduceOnCount':_0x36c600['reducePolicy'][_0x1b9f59(0x174)][_0x1b9f59(0x18c)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x174)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x174)][_0x1b9f59(0x158)]||0x32,'resetOnProcessingTimeAverageMs':_0x36c600[_0x1b9f59(0xde)][_0x1b9f59(0x174)][_0x1b9f59(0x15d)]||0x64}},_0x3a6b93=G(_0xa02ceb),_0x581ffa=_0x3a6b93[_0x1b9f59(0x17c)],_0x2b6073=_0x3a6b93[_0x1b9f59(0x123)];function _0x20ca8a(){const _0x55ee70=_0x1b9f59;this[_0x55ee70(0x82)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x55ee70(0xf4)]=/^(0|[1-9][0-9]*)$/,this['_quotedRegExp']=/'([^\\\\']|\\\\')*'/,this[_0x55ee70(0x71)]=_0xa02ceb[_0x55ee70(0xb6)],this[_0x55ee70(0xca)]=_0xa02ceb[_0x55ee70(0x15e)],this['_getOwnPropertyDescriptor']=Object[_0x55ee70(0x107)],this[_0x55ee70(0xa0)]=Object[_0x55ee70(0xdc)],this[_0x55ee70(0x149)]=_0xa02ceb[_0x55ee70(0x119)],this[_0x55ee70(0xd6)]=RegExp[_0x55ee70(0x1a9)][_0x55ee70(0xfe)],this['_dateToString']=Date['prototype'][_0x55ee70(0xfe)];}_0x20ca8a['prototype'][_0x1b9f59(0x106)]=function(_0xe1be21,_0x55eeb8,_0x2fdca7,_0x2e2297){const _0xc5b9f8=_0x1b9f59;var _0x4ea609=this,_0x18e690=_0x2fdca7[_0xc5b9f8(0x163)];function _0x26bc49(_0x318be2,_0x2dd4c6,_0x24c22e){const _0x19c17e=_0xc5b9f8;_0x2dd4c6[_0x19c17e(0x134)]='unknown',_0x2dd4c6[_0x19c17e(0x101)]=_0x318be2[_0x19c17e(0x15c)],_0x344520=_0x24c22e[_0x19c17e(0x14f)][_0x19c17e(0x15b)],_0x24c22e[_0x19c17e(0x14f)]['current']=_0x2dd4c6,_0x4ea609['_treeNodePropertiesBeforeFullValue'](_0x2dd4c6,_0x24c22e);}let _0x5bfa05,_0x8e61a2,_0x179f14=_0xa02ceb[_0xc5b9f8(0x175)];_0xa02ceb['ninjaSuppressConsole']=!0x0,_0xa02ceb[_0xc5b9f8(0xb0)]&&(_0x5bfa05=_0xa02ceb[_0xc5b9f8(0xb0)]['error'],_0x8e61a2=_0xa02ceb['console'][_0xc5b9f8(0x11b)],_0x5bfa05&&(_0xa02ceb['console'][_0xc5b9f8(0x101)]=function(){}),_0x8e61a2&&(_0xa02ceb[_0xc5b9f8(0xb0)][_0xc5b9f8(0x11b)]=function(){}));try{try{_0x2fdca7['level']++,_0x2fdca7[_0xc5b9f8(0x163)]&&_0x2fdca7[_0xc5b9f8(0x12a)][_0xc5b9f8(0x104)](_0x55eeb8);var _0x21b78d,_0xaebb,_0x3046b2,_0x594d73,_0xcf17ef=[],_0x45854c=[],_0x1d04eb,_0x47f681=this[_0xc5b9f8(0x139)](_0x55eeb8),_0x3217e1=_0x47f681===_0xc5b9f8(0xa6),_0x293ac4=!0x1,_0x2bbbc2=_0x47f681==='function',_0x360f3e=this[_0xc5b9f8(0xfb)](_0x47f681),_0x397d74=this[_0xc5b9f8(0x10e)](_0x47f681),_0x491a8f=_0x360f3e||_0x397d74,_0x11decc={},_0x1d7006=0x0,_0x39d92c=!0x1,_0x344520,_0x45ec5e=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x2fdca7['depth']){if(_0x3217e1){if(_0xaebb=_0x55eeb8[_0xc5b9f8(0x188)],_0xaebb>_0x2fdca7[_0xc5b9f8(0x150)]){for(_0x3046b2=0x0,_0x594d73=_0x2fdca7[_0xc5b9f8(0x150)],_0x21b78d=_0x3046b2;_0x21b78d<_0x594d73;_0x21b78d++)_0x45854c[_0xc5b9f8(0x104)](_0x4ea609[_0xc5b9f8(0xbd)](_0xcf17ef,_0x55eeb8,_0x47f681,_0x21b78d,_0x2fdca7));_0xe1be21['cappedElements']=!0x0;}else{for(_0x3046b2=0x0,_0x594d73=_0xaebb,_0x21b78d=_0x3046b2;_0x21b78d<_0x594d73;_0x21b78d++)_0x45854c[_0xc5b9f8(0x104)](_0x4ea609[_0xc5b9f8(0xbd)](_0xcf17ef,_0x55eeb8,_0x47f681,_0x21b78d,_0x2fdca7));}_0x2fdca7['autoExpandPropertyCount']+=_0x45854c[_0xc5b9f8(0x188)];}if(!(_0x47f681===_0xc5b9f8(0x105)||_0x47f681===_0xc5b9f8(0xb6))&&!_0x360f3e&&_0x47f681!==_0xc5b9f8(0x108)&&_0x47f681!=='Buffer'&&_0x47f681!==_0xc5b9f8(0x9a)){var _0x3bbb11=_0x2e2297['props']||_0x2fdca7[_0xc5b9f8(0x133)];if(this['_isSet'](_0x55eeb8)?(_0x21b78d=0x0,_0x55eeb8['forEach'](function(_0x2c119d){const _0x372347=_0xc5b9f8;if(_0x1d7006++,_0x2fdca7['autoExpandPropertyCount']++,_0x1d7006>_0x3bbb11){_0x39d92c=!0x0;return;}if(!_0x2fdca7[_0x372347(0x83)]&&_0x2fdca7[_0x372347(0x163)]&&_0x2fdca7[_0x372347(0xa2)]>_0x2fdca7['autoExpandLimit']){_0x39d92c=!0x0;return;}_0x45854c[_0x372347(0x104)](_0x4ea609[_0x372347(0xbd)](_0xcf17ef,_0x55eeb8,_0x372347(0x7f),_0x21b78d++,_0x2fdca7,function(_0x5c600b){return function(){return _0x5c600b;};}(_0x2c119d)));})):this['_isMap'](_0x55eeb8)&&_0x55eeb8[_0xc5b9f8(0xb2)](function(_0x418454,_0xcc0b58){const _0x559de1=_0xc5b9f8;if(_0x1d7006++,_0x2fdca7['autoExpandPropertyCount']++,_0x1d7006>_0x3bbb11){_0x39d92c=!0x0;return;}if(!_0x2fdca7[_0x559de1(0x83)]&&_0x2fdca7[_0x559de1(0x163)]&&_0x2fdca7['autoExpandPropertyCount']>_0x2fdca7[_0x559de1(0x75)]){_0x39d92c=!0x0;return;}var _0xaf8501=_0xcc0b58[_0x559de1(0xfe)]();_0xaf8501[_0x559de1(0x188)]>0x64&&(_0xaf8501=_0xaf8501[_0x559de1(0x114)](0x0,0x64)+'...'),_0x45854c[_0x559de1(0x104)](_0x4ea609[_0x559de1(0xbd)](_0xcf17ef,_0x55eeb8,_0x559de1(0x182),_0xaf8501,_0x2fdca7,function(_0x57a18e){return function(){return _0x57a18e;};}(_0x418454)));}),!_0x293ac4){try{for(_0x1d04eb in _0x55eeb8)if(!(_0x3217e1&&_0x45ec5e[_0xc5b9f8(0x112)](_0x1d04eb))&&!this[_0xc5b9f8(0x15a)](_0x55eeb8,_0x1d04eb,_0x2fdca7)){if(_0x1d7006++,_0x2fdca7['autoExpandPropertyCount']++,_0x1d7006>_0x3bbb11){_0x39d92c=!0x0;break;}if(!_0x2fdca7[_0xc5b9f8(0x83)]&&_0x2fdca7[_0xc5b9f8(0x163)]&&_0x2fdca7[_0xc5b9f8(0xa2)]>_0x2fdca7[_0xc5b9f8(0x75)]){_0x39d92c=!0x0;break;}_0x45854c[_0xc5b9f8(0x104)](_0x4ea609['_addObjectProperty'](_0xcf17ef,_0x11decc,_0x55eeb8,_0x47f681,_0x1d04eb,_0x2fdca7));}}catch{}if(_0x11decc[_0xc5b9f8(0xc3)]=!0x0,_0x2bbbc2&&(_0x11decc['_p_name']=!0x0),!_0x39d92c){var _0x3cbff3=[][_0xc5b9f8(0xf2)](this[_0xc5b9f8(0xa0)](_0x55eeb8))[_0xc5b9f8(0xf2)](this[_0xc5b9f8(0xdb)](_0x55eeb8));for(_0x21b78d=0x0,_0xaebb=_0x3cbff3[_0xc5b9f8(0x188)];_0x21b78d<_0xaebb;_0x21b78d++)if(_0x1d04eb=_0x3cbff3[_0x21b78d],!(_0x3217e1&&_0x45ec5e['test'](_0x1d04eb['toString']()))&&!this['_blacklistedProperty'](_0x55eeb8,_0x1d04eb,_0x2fdca7)&&!_0x11decc[typeof _0x1d04eb!=_0xc5b9f8(0xe4)?_0xc5b9f8(0x91)+_0x1d04eb['toString']():_0x1d04eb]){if(_0x1d7006++,_0x2fdca7[_0xc5b9f8(0xa2)]++,_0x1d7006>_0x3bbb11){_0x39d92c=!0x0;break;}if(!_0x2fdca7[_0xc5b9f8(0x83)]&&_0x2fdca7[_0xc5b9f8(0x163)]&&_0x2fdca7[_0xc5b9f8(0xa2)]>_0x2fdca7[_0xc5b9f8(0x75)]){_0x39d92c=!0x0;break;}_0x45854c[_0xc5b9f8(0x104)](_0x4ea609['_addObjectProperty'](_0xcf17ef,_0x11decc,_0x55eeb8,_0x47f681,_0x1d04eb,_0x2fdca7));}}}}}if(_0xe1be21[_0xc5b9f8(0x134)]=_0x47f681,_0x491a8f?(_0xe1be21[_0xc5b9f8(0x152)]=_0x55eeb8[_0xc5b9f8(0x178)](),this[_0xc5b9f8(0x140)](_0x47f681,_0xe1be21,_0x2fdca7,_0x2e2297)):_0x47f681===_0xc5b9f8(0x127)?_0xe1be21[_0xc5b9f8(0x152)]=this[_0xc5b9f8(0xec)][_0xc5b9f8(0x196)](_0x55eeb8):_0x47f681===_0xc5b9f8(0x9a)?_0xe1be21[_0xc5b9f8(0x152)]=_0x55eeb8[_0xc5b9f8(0xfe)]():_0x47f681==='RegExp'?_0xe1be21[_0xc5b9f8(0x152)]=this['_regExpToString'][_0xc5b9f8(0x196)](_0x55eeb8):_0x47f681==='symbol'&&this['_Symbol']?_0xe1be21[_0xc5b9f8(0x152)]=this['_Symbol']['prototype']['toString'][_0xc5b9f8(0x196)](_0x55eeb8):!_0x2fdca7[_0xc5b9f8(0x190)]&&!(_0x47f681===_0xc5b9f8(0x105)||_0x47f681==='undefined')&&(delete _0xe1be21[_0xc5b9f8(0x152)],_0xe1be21[_0xc5b9f8(0xc0)]=!0x0),_0x39d92c&&(_0xe1be21['cappedProps']=!0x0),_0x344520=_0x2fdca7[_0xc5b9f8(0x14f)][_0xc5b9f8(0x15b)],_0x2fdca7[_0xc5b9f8(0x14f)]['current']=_0xe1be21,this['_treeNodePropertiesBeforeFullValue'](_0xe1be21,_0x2fdca7),_0x45854c[_0xc5b9f8(0x188)]){for(_0x21b78d=0x0,_0xaebb=_0x45854c[_0xc5b9f8(0x188)];_0x21b78d<_0xaebb;_0x21b78d++)_0x45854c[_0x21b78d](_0x21b78d);}_0xcf17ef[_0xc5b9f8(0x188)]&&(_0xe1be21['props']=_0xcf17ef);}catch(_0x218333){_0x26bc49(_0x218333,_0xe1be21,_0x2fdca7);}this['_additionalMetadata'](_0x55eeb8,_0xe1be21),this['_treeNodePropertiesAfterFullValue'](_0xe1be21,_0x2fdca7),_0x2fdca7[_0xc5b9f8(0x14f)]['current']=_0x344520,_0x2fdca7[_0xc5b9f8(0xee)]--,_0x2fdca7[_0xc5b9f8(0x163)]=_0x18e690,_0x2fdca7[_0xc5b9f8(0x163)]&&_0x2fdca7[_0xc5b9f8(0x12a)][_0xc5b9f8(0x10f)]();}finally{_0x5bfa05&&(_0xa02ceb['console'][_0xc5b9f8(0x101)]=_0x5bfa05),_0x8e61a2&&(_0xa02ceb[_0xc5b9f8(0xb0)][_0xc5b9f8(0x11b)]=_0x8e61a2),_0xa02ceb[_0xc5b9f8(0x175)]=_0x179f14;}return _0xe1be21;},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0xdb)]=function(_0x4acd73){const _0x3c8c02=_0x1b9f59;return Object[_0x3c8c02(0x185)]?Object[_0x3c8c02(0x185)](_0x4acd73):[];},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0xb8)]=function(_0x23fcaa){const _0x5a9b4f=_0x1b9f59;return!!(_0x23fcaa&&_0xa02ceb[_0x5a9b4f(0x7f)]&&this['_objectToString'](_0x23fcaa)===_0x5a9b4f(0xaf)&&_0x23fcaa[_0x5a9b4f(0xb2)]);},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x15a)]=function(_0x1b9c0e,_0x5939f7,_0x3a4b2b){const _0x259d0e=_0x1b9f59;if(!_0x3a4b2b[_0x259d0e(0x18b)]){let _0x45b87d=this[_0x259d0e(0x109)](_0x1b9c0e,_0x5939f7);if(_0x45b87d&&_0x45b87d['get'])return!0x0;}return _0x3a4b2b['noFunctions']?typeof _0x1b9c0e[_0x5939f7]=='function':!0x1;},_0x20ca8a['prototype'][_0x1b9f59(0x139)]=function(_0x4f65d6){const _0x81c847=_0x1b9f59;var _0x43a27f='';return _0x43a27f=typeof _0x4f65d6,_0x43a27f===_0x81c847(0x16e)?this[_0x81c847(0x129)](_0x4f65d6)===_0x81c847(0x197)?_0x43a27f='array':this[_0x81c847(0x129)](_0x4f65d6)===_0x81c847(0x151)?_0x43a27f=_0x81c847(0x127):this['_objectToString'](_0x4f65d6)===_0x81c847(0x187)?_0x43a27f='bigint':_0x4f65d6===null?_0x43a27f=_0x81c847(0x105):_0x4f65d6[_0x81c847(0xac)]&&(_0x43a27f=_0x4f65d6[_0x81c847(0xac)][_0x81c847(0xd3)]||_0x43a27f):_0x43a27f===_0x81c847(0xb6)&&this[_0x81c847(0xca)]&&_0x4f65d6 instanceof this[_0x81c847(0xca)]&&(_0x43a27f=_0x81c847(0x15e)),_0x43a27f;},_0x20ca8a[_0x1b9f59(0x1a9)]['_objectToString']=function(_0x5b7e39){const _0x35eda3=_0x1b9f59;return Object['prototype'][_0x35eda3(0xfe)][_0x35eda3(0x196)](_0x5b7e39);},_0x20ca8a[_0x1b9f59(0x1a9)]['_isPrimitiveType']=function(_0x39f2e2){const _0x40b06b=_0x1b9f59;return _0x39f2e2==='boolean'||_0x39f2e2===_0x40b06b(0x157)||_0x39f2e2===_0x40b06b(0x184);},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x10e)]=function(_0x649e85){const _0x49db27=_0x1b9f59;return _0x649e85===_0x49db27(0x189)||_0x649e85===_0x49db27(0x108)||_0x649e85==='Number';},_0x20ca8a['prototype'][_0x1b9f59(0xbd)]=function(_0x118c78,_0x4f7daf,_0x2fb21c,_0x243575,_0x352637,_0x4732ec){var _0x46d4ac=this;return function(_0x164226){const _0x330153=_0x437c;var _0x526bf0=_0x352637['node'][_0x330153(0x15b)],_0x13b6b6=_0x352637[_0x330153(0x14f)]['index'],_0x2675cd=_0x352637['node'][_0x330153(0x9f)];_0x352637['node'][_0x330153(0x9f)]=_0x526bf0,_0x352637[_0x330153(0x14f)][_0x330153(0x9d)]=typeof _0x243575==_0x330153(0x184)?_0x243575:_0x164226,_0x118c78['push'](_0x46d4ac['_property'](_0x4f7daf,_0x2fb21c,_0x243575,_0x352637,_0x4732ec)),_0x352637[_0x330153(0x14f)][_0x330153(0x9f)]=_0x2675cd,_0x352637[_0x330153(0x14f)][_0x330153(0x9d)]=_0x13b6b6;};},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0xd9)]=function(_0x4e986c,_0x1a25fa,_0x40cc90,_0x597227,_0x1f7355,_0x52fdb7,_0x508798){const _0xcced6a=_0x1b9f59;var _0x1369a5=this;return _0x1a25fa[typeof _0x1f7355!='symbol'?_0xcced6a(0x91)+_0x1f7355[_0xcced6a(0xfe)]():_0x1f7355]=!0x0,function(_0x4672aa){const _0x1ad26a=_0xcced6a;var _0x554e0c=_0x52fdb7[_0x1ad26a(0x14f)]['current'],_0x52015f=_0x52fdb7['node'][_0x1ad26a(0x9d)],_0x1aa75d=_0x52fdb7['node'][_0x1ad26a(0x9f)];_0x52fdb7[_0x1ad26a(0x14f)][_0x1ad26a(0x9f)]=_0x554e0c,_0x52fdb7['node'][_0x1ad26a(0x9d)]=_0x4672aa,_0x4e986c[_0x1ad26a(0x104)](_0x1369a5['_property'](_0x40cc90,_0x597227,_0x1f7355,_0x52fdb7,_0x508798)),_0x52fdb7[_0x1ad26a(0x14f)][_0x1ad26a(0x9f)]=_0x1aa75d,_0x52fdb7['node'][_0x1ad26a(0x9d)]=_0x52015f;};},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x160)]=function(_0x4d5827,_0x2a59b0,_0x3099ad,_0x2fe836,_0x4f7d44){const _0x583a7f=_0x1b9f59;var _0x5e75ec=this;_0x4f7d44||(_0x4f7d44=function(_0x203297,_0x2dbda7){return _0x203297[_0x2dbda7];});var _0x25423e=_0x3099ad[_0x583a7f(0xfe)](),_0x2016eb=_0x2fe836['expressionsToEvaluate']||{},_0x196d80=_0x2fe836['depth'],_0x8e7a29=_0x2fe836['isExpressionToEvaluate'];try{var _0x49316e=this[_0x583a7f(0x8a)](_0x4d5827),_0x1d71ff=_0x25423e;_0x49316e&&_0x1d71ff[0x0]==='\\x27'&&(_0x1d71ff=_0x1d71ff[_0x583a7f(0x13e)](0x1,_0x1d71ff[_0x583a7f(0x188)]-0x2));var _0x29e1cb=_0x2fe836['expressionsToEvaluate']=_0x2016eb[_0x583a7f(0x91)+_0x1d71ff];_0x29e1cb&&(_0x2fe836[_0x583a7f(0x190)]=_0x2fe836[_0x583a7f(0x190)]+0x1),_0x2fe836[_0x583a7f(0x83)]=!!_0x29e1cb;var _0x480d60=typeof _0x3099ad==_0x583a7f(0xe4),_0x1e3b6b={'name':_0x480d60||_0x49316e?_0x25423e:this[_0x583a7f(0x14e)](_0x25423e)};if(_0x480d60&&(_0x1e3b6b[_0x583a7f(0xe4)]=!0x0),!(_0x2a59b0===_0x583a7f(0xa6)||_0x2a59b0===_0x583a7f(0x84))){var _0x2530af=this[_0x583a7f(0x109)](_0x4d5827,_0x3099ad);if(_0x2530af&&(_0x2530af['set']&&(_0x1e3b6b[_0x583a7f(0x159)]=!0x0),_0x2530af[_0x583a7f(0x130)]&&!_0x29e1cb&&!_0x2fe836[_0x583a7f(0x18b)]))return _0x1e3b6b[_0x583a7f(0x16b)]=!0x0,this['_processTreeNodeResult'](_0x1e3b6b,_0x2fe836),_0x1e3b6b;}var _0x369d3b;try{_0x369d3b=_0x4f7d44(_0x4d5827,_0x3099ad);}catch(_0xd9a6af){return _0x1e3b6b={'name':_0x25423e,'type':_0x583a7f(0x117),'error':_0xd9a6af[_0x583a7f(0x15c)]},this['_processTreeNodeResult'](_0x1e3b6b,_0x2fe836),_0x1e3b6b;}var _0x7951cb=this[_0x583a7f(0x139)](_0x369d3b),_0x58873f=this[_0x583a7f(0xfb)](_0x7951cb);if(_0x1e3b6b[_0x583a7f(0x134)]=_0x7951cb,_0x58873f)this[_0x583a7f(0x1a6)](_0x1e3b6b,_0x2fe836,_0x369d3b,function(){const _0x1b502f=_0x583a7f;_0x1e3b6b['value']=_0x369d3b[_0x1b502f(0x178)](),!_0x29e1cb&&_0x5e75ec[_0x1b502f(0x140)](_0x7951cb,_0x1e3b6b,_0x2fe836,{});});else{var _0x533d55=_0x2fe836['autoExpand']&&_0x2fe836[_0x583a7f(0xee)]<_0x2fe836[_0x583a7f(0xef)]&&_0x2fe836[_0x583a7f(0x12a)]['indexOf'](_0x369d3b)<0x0&&_0x7951cb!==_0x583a7f(0x10b)&&_0x2fe836[_0x583a7f(0xa2)]<_0x2fe836[_0x583a7f(0x75)];_0x533d55||_0x2fe836[_0x583a7f(0xee)]<_0x196d80||_0x29e1cb?this[_0x583a7f(0x106)](_0x1e3b6b,_0x369d3b,_0x2fe836,_0x29e1cb||{}):this[_0x583a7f(0x1a6)](_0x1e3b6b,_0x2fe836,_0x369d3b,function(){const _0xb446c9=_0x583a7f;_0x7951cb===_0xb446c9(0x105)||_0x7951cb===_0xb446c9(0xb6)||(delete _0x1e3b6b[_0xb446c9(0x152)],_0x1e3b6b[_0xb446c9(0xc0)]=!0x0);});}return _0x1e3b6b;}finally{_0x2fe836['expressionsToEvaluate']=_0x2016eb,_0x2fe836[_0x583a7f(0x190)]=_0x196d80,_0x2fe836['isExpressionToEvaluate']=_0x8e7a29;}},_0x20ca8a['prototype'][_0x1b9f59(0x140)]=function(_0x315e8e,_0x3efc86,_0x36f048,_0x4e8030){const _0x15baba=_0x1b9f59;var _0x5f22f3=_0x4e8030[_0x15baba(0x81)]||_0x36f048[_0x15baba(0x81)];if((_0x315e8e==='string'||_0x315e8e===_0x15baba(0x108))&&_0x3efc86[_0x15baba(0x152)]){let _0x33a94e=_0x3efc86[_0x15baba(0x152)][_0x15baba(0x188)];_0x36f048[_0x15baba(0x115)]+=_0x33a94e,_0x36f048[_0x15baba(0x115)]>_0x36f048[_0x15baba(0x12e)]?(_0x3efc86[_0x15baba(0xc0)]='',delete _0x3efc86[_0x15baba(0x152)]):_0x33a94e>_0x5f22f3&&(_0x3efc86['capped']=_0x3efc86[_0x15baba(0x152)][_0x15baba(0x13e)](0x0,_0x5f22f3),delete _0x3efc86[_0x15baba(0x152)]);}},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x8a)]=function(_0x3ad260){const _0x55e945=_0x1b9f59;return!!(_0x3ad260&&_0xa02ceb[_0x55e945(0x182)]&&this['_objectToString'](_0x3ad260)===_0x55e945(0x124)&&_0x3ad260['forEach']);},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x14e)]=function(_0x87c6d6){const _0x509e9f=_0x1b9f59;if(_0x87c6d6['match'](/^\\d+$/))return _0x87c6d6;var _0x4deb32;try{_0x4deb32=JSON[_0x509e9f(0xa8)](''+_0x87c6d6);}catch{_0x4deb32='\\x22'+this['_objectToString'](_0x87c6d6)+'\\x22';}return _0x4deb32[_0x509e9f(0xf8)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x4deb32=_0x4deb32['substr'](0x1,_0x4deb32[_0x509e9f(0x188)]-0x2):_0x4deb32=_0x4deb32[_0x509e9f(0x116)](/'/g,'\\x5c\\x27')[_0x509e9f(0x116)](/\\\\\"/g,'\\x22')[_0x509e9f(0x116)](/(^\"|\"$)/g,'\\x27'),_0x4deb32;},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x1a6)]=function(_0x215171,_0x598762,_0x1da2f6,_0x127be9){const _0x44a3e4=_0x1b9f59;this[_0x44a3e4(0x80)](_0x215171,_0x598762),_0x127be9&&_0x127be9(),this[_0x44a3e4(0xfd)](_0x1da2f6,_0x215171),this[_0x44a3e4(0x19b)](_0x215171,_0x598762);},_0x20ca8a[_0x1b9f59(0x1a9)]['_treeNodePropertiesBeforeFullValue']=function(_0x41f206,_0x4bdb26){const _0x4e4a7c=_0x1b9f59;this[_0x4e4a7c(0xe2)](_0x41f206,_0x4bdb26),this['_setNodeQueryPath'](_0x41f206,_0x4bdb26),this[_0x4e4a7c(0x8f)](_0x41f206,_0x4bdb26),this[_0x4e4a7c(0x99)](_0x41f206,_0x4bdb26);},_0x20ca8a[_0x1b9f59(0x1a9)]['_setNodeId']=function(_0x2f1101,_0x5a823c){},_0x20ca8a['prototype'][_0x1b9f59(0x170)]=function(_0x2f659b,_0x9989eb){},_0x20ca8a[_0x1b9f59(0x1a9)]['_setNodeLabel']=function(_0x35bbfd,_0xc03fc9){},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x161)]=function(_0x18779b){const _0x16839d=_0x1b9f59;return _0x18779b===this[_0x16839d(0x71)];},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x19b)]=function(_0x48d040,_0x5cc093){const _0x28486d=_0x1b9f59;this[_0x28486d(0x135)](_0x48d040,_0x5cc093),this[_0x28486d(0x12d)](_0x48d040),_0x5cc093[_0x28486d(0x125)]&&this[_0x28486d(0xb9)](_0x48d040),this[_0x28486d(0x89)](_0x48d040,_0x5cc093),this['_addLoadNode'](_0x48d040,_0x5cc093),this[_0x28486d(0x17e)](_0x48d040);},_0x20ca8a[_0x1b9f59(0x1a9)]['_additionalMetadata']=function(_0x1fe2f0,_0x283cbc){const _0x313933=_0x1b9f59;try{_0x1fe2f0&&typeof _0x1fe2f0['length']==_0x313933(0x184)&&(_0x283cbc[_0x313933(0x188)]=_0x1fe2f0['length']);}catch{}if(_0x283cbc[_0x313933(0x134)]===_0x313933(0x184)||_0x283cbc[_0x313933(0x134)]===_0x313933(0xad)){if(isNaN(_0x283cbc[_0x313933(0x152)]))_0x283cbc[_0x313933(0x169)]=!0x0,delete _0x283cbc[_0x313933(0x152)];else switch(_0x283cbc[_0x313933(0x152)]){case Number[_0x313933(0x9b)]:_0x283cbc[_0x313933(0x183)]=!0x0,delete _0x283cbc[_0x313933(0x152)];break;case Number['NEGATIVE_INFINITY']:_0x283cbc[_0x313933(0xd4)]=!0x0,delete _0x283cbc[_0x313933(0x152)];break;case 0x0:this['_isNegativeZero'](_0x283cbc[_0x313933(0x152)])&&(_0x283cbc['negativeZero']=!0x0);break;}}else _0x283cbc[_0x313933(0x134)]==='function'&&typeof _0x1fe2f0[_0x313933(0xd3)]==_0x313933(0x157)&&_0x1fe2f0[_0x313933(0xd3)]&&_0x283cbc['name']&&_0x1fe2f0[_0x313933(0xd3)]!==_0x283cbc['name']&&(_0x283cbc[_0x313933(0x1aa)]=_0x1fe2f0[_0x313933(0xd3)]);},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x78)]=function(_0x61a607){const _0x4fa806=_0x1b9f59;return 0x1/_0x61a607===Number[_0x4fa806(0x111)];},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0xb9)]=function(_0x108103){const _0x55fc8a=_0x1b9f59;!_0x108103['props']||!_0x108103[_0x55fc8a(0x133)][_0x55fc8a(0x188)]||_0x108103[_0x55fc8a(0x134)]==='array'||_0x108103[_0x55fc8a(0x134)]===_0x55fc8a(0x182)||_0x108103[_0x55fc8a(0x134)]===_0x55fc8a(0x7f)||_0x108103[_0x55fc8a(0x133)][_0x55fc8a(0x73)](function(_0x5032ac,_0x538e15){const _0x34682a=_0x55fc8a;var _0x535fcc=_0x5032ac[_0x34682a(0xd3)][_0x34682a(0x167)](),_0x11d375=_0x538e15[_0x34682a(0xd3)][_0x34682a(0x167)]();return _0x535fcc<_0x11d375?-0x1:_0x535fcc>_0x11d375?0x1:0x0;});},_0x20ca8a[_0x1b9f59(0x1a9)]['_addFunctionsNode']=function(_0x426cb9,_0x2f1852){const _0x3e1f0a=_0x1b9f59;if(!(_0x2f1852[_0x3e1f0a(0xe5)]||!_0x426cb9['props']||!_0x426cb9[_0x3e1f0a(0x133)]['length'])){for(var _0x2e4e16=[],_0x400f26=[],_0x2d966e=0x0,_0x4f0b6b=_0x426cb9[_0x3e1f0a(0x133)][_0x3e1f0a(0x188)];_0x2d966e<_0x4f0b6b;_0x2d966e++){var _0x36630e=_0x426cb9[_0x3e1f0a(0x133)][_0x2d966e];_0x36630e[_0x3e1f0a(0x134)]==='function'?_0x2e4e16[_0x3e1f0a(0x104)](_0x36630e):_0x400f26['push'](_0x36630e);}if(!(!_0x400f26['length']||_0x2e4e16[_0x3e1f0a(0x188)]<=0x1)){_0x426cb9[_0x3e1f0a(0x133)]=_0x400f26;var _0x1b0a0d={'functionsNode':!0x0,'props':_0x2e4e16};this['_setNodeId'](_0x1b0a0d,_0x2f1852),this['_setNodeLabel'](_0x1b0a0d,_0x2f1852),this[_0x3e1f0a(0x12d)](_0x1b0a0d),this[_0x3e1f0a(0x99)](_0x1b0a0d,_0x2f1852),_0x1b0a0d['id']+='\\x20f',_0x426cb9[_0x3e1f0a(0x133)][_0x3e1f0a(0xa3)](_0x1b0a0d);}}},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x141)]=function(_0x194961,_0x318cc7){},_0x20ca8a['prototype'][_0x1b9f59(0x12d)]=function(_0x15747f){},_0x20ca8a['prototype'][_0x1b9f59(0x98)]=function(_0x128b7e){const _0x7b1b61=_0x1b9f59;return Array[_0x7b1b61(0x95)](_0x128b7e)||typeof _0x128b7e==_0x7b1b61(0x16e)&&this[_0x7b1b61(0x129)](_0x128b7e)===_0x7b1b61(0x197);},_0x20ca8a[_0x1b9f59(0x1a9)][_0x1b9f59(0x99)]=function(_0xfa7802,_0x446c05){},_0x20ca8a['prototype'][_0x1b9f59(0x17e)]=function(_0x189ba8){const _0xa89cc9=_0x1b9f59;delete _0x189ba8[_0xa89cc9(0x72)],delete _0x189ba8[_0xa89cc9(0x19a)],delete _0x189ba8[_0xa89cc9(0x86)];},_0x20ca8a[_0x1b9f59(0x1a9)]['_setNodeExpressionPath']=function(_0x5e1b1f,_0x8eeffc){};let _0x3aaadd=new _0x20ca8a(),_0xbdafb2={'props':_0x36c600[_0x1b9f59(0xb4)][_0x1b9f59(0x133)]||0x64,'elements':_0x36c600[_0x1b9f59(0xb4)][_0x1b9f59(0x150)]||0x64,'strLength':_0x36c600[_0x1b9f59(0xb4)]['strLength']||0x400*0x32,'totalStrLength':_0x36c600['defaultLimits']['totalStrLength']||0x400*0x32,'autoExpandLimit':_0x36c600[_0x1b9f59(0xb4)][_0x1b9f59(0x75)]||0x1388,'autoExpandMaxDepth':_0x36c600[_0x1b9f59(0xb4)][_0x1b9f59(0xef)]||0xa},_0x3b01da={'props':_0x36c600['reducedLimits'][_0x1b9f59(0x133)]||0x5,'elements':_0x36c600[_0x1b9f59(0x100)][_0x1b9f59(0x150)]||0x5,'strLength':_0x36c600[_0x1b9f59(0x100)][_0x1b9f59(0x81)]||0x100,'totalStrLength':_0x36c600[_0x1b9f59(0x100)][_0x1b9f59(0x12e)]||0x100*0x3,'autoExpandLimit':_0x36c600[_0x1b9f59(0x100)][_0x1b9f59(0x75)]||0x1e,'autoExpandMaxDepth':_0x36c600[_0x1b9f59(0x100)]['autoExpandMaxDepth']||0x2};if(_0x56cc80){let _0x3ce207=_0x3aaadd[_0x1b9f59(0x106)][_0x1b9f59(0x10d)](_0x3aaadd);_0x3aaadd[_0x1b9f59(0x106)]=function(_0x332ff4,_0x1dafc8,_0x11f690,_0x22e700){return _0x3ce207(_0x332ff4,_0x56cc80(_0x1dafc8),_0x11f690,_0x22e700);};}function _0x52b991(_0x4a2328,_0x53d2f1,_0x3097b4,_0x11339d,_0x89b1b9,_0x1728be){const _0x5bb97e=_0x1b9f59;let _0x1b0964,_0x4e4795;try{_0x4e4795=_0x2b6073(),_0x1b0964=_0x1cd00b[_0x53d2f1],!_0x1b0964||_0x4e4795-_0x1b0964['ts']>_0xaa8f90['perLogpoint'][_0x5bb97e(0x158)]&&_0x1b0964[_0x5bb97e(0x147)]&&_0x1b0964[_0x5bb97e(0x1a2)]/_0x1b0964['count']<_0xaa8f90[_0x5bb97e(0x166)][_0x5bb97e(0x15d)]?(_0x1cd00b[_0x53d2f1]=_0x1b0964={'count':0x0,'time':0x0,'ts':_0x4e4795},_0x1cd00b[_0x5bb97e(0x138)]={}):_0x4e4795-_0x1cd00b[_0x5bb97e(0x138)]['ts']>_0xaa8f90[_0x5bb97e(0x174)][_0x5bb97e(0x158)]&&_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0x147)]&&_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0x1a2)]/_0x1cd00b[_0x5bb97e(0x138)]['count']<_0xaa8f90[_0x5bb97e(0x174)]['resetOnProcessingTimeAverageMs']&&(_0x1cd00b[_0x5bb97e(0x138)]={});let _0x375e69=[],_0x153049=_0x1b0964[_0x5bb97e(0xdf)]||_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0xdf)]?_0x3b01da:_0xbdafb2,_0x237a67=_0x3137d0=>{const _0x20d9ec=_0x5bb97e;let _0x12e0a8={};return _0x12e0a8[_0x20d9ec(0x133)]=_0x3137d0[_0x20d9ec(0x133)],_0x12e0a8['elements']=_0x3137d0[_0x20d9ec(0x150)],_0x12e0a8[_0x20d9ec(0x81)]=_0x3137d0[_0x20d9ec(0x81)],_0x12e0a8[_0x20d9ec(0x12e)]=_0x3137d0[_0x20d9ec(0x12e)],_0x12e0a8[_0x20d9ec(0x75)]=_0x3137d0[_0x20d9ec(0x75)],_0x12e0a8[_0x20d9ec(0xef)]=_0x3137d0['autoExpandMaxDepth'],_0x12e0a8[_0x20d9ec(0x125)]=!0x1,_0x12e0a8[_0x20d9ec(0xe5)]=!_0x4fbc07,_0x12e0a8[_0x20d9ec(0x190)]=0x1,_0x12e0a8[_0x20d9ec(0xee)]=0x0,_0x12e0a8[_0x20d9ec(0x177)]=_0x20d9ec(0xe8),_0x12e0a8[_0x20d9ec(0xf0)]=_0x20d9ec(0x9c),_0x12e0a8[_0x20d9ec(0x163)]=!0x0,_0x12e0a8[_0x20d9ec(0x12a)]=[],_0x12e0a8[_0x20d9ec(0xa2)]=0x0,_0x12e0a8['resolveGetters']=_0x36c600[_0x20d9ec(0x18b)],_0x12e0a8[_0x20d9ec(0x115)]=0x0,_0x12e0a8[_0x20d9ec(0x14f)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x12e0a8;};for(var _0xe76973=0x0;_0xe76973<_0x89b1b9[_0x5bb97e(0x188)];_0xe76973++)_0x375e69[_0x5bb97e(0x104)](_0x3aaadd[_0x5bb97e(0x106)]({'timeNode':_0x4a2328===_0x5bb97e(0x1a2)||void 0x0},_0x89b1b9[_0xe76973],_0x237a67(_0x153049),{}));if(_0x4a2328===_0x5bb97e(0xda)||_0x4a2328===_0x5bb97e(0x101)){let _0x9b2867=Error[_0x5bb97e(0x9e)];try{Error[_0x5bb97e(0x9e)]=0x1/0x0,_0x375e69[_0x5bb97e(0x104)](_0x3aaadd['serialize']({'stackNode':!0x0},new Error()['stack'],_0x237a67(_0x153049),{'strLength':0x1/0x0}));}finally{Error['stackTraceLimit']=_0x9b2867;}}return{'method':'log','version':_0x3c945d,'args':[{'ts':_0x3097b4,'session':_0x11339d,'args':_0x375e69,'id':_0x53d2f1,'context':_0x1728be}]};}catch(_0x1042b5){return{'method':'log','version':_0x3c945d,'args':[{'ts':_0x3097b4,'session':_0x11339d,'args':[{'type':_0x5bb97e(0x117),'error':_0x1042b5&&_0x1042b5['message']}],'id':_0x53d2f1,'context':_0x1728be}]};}finally{try{if(_0x1b0964&&_0x4e4795){let _0x6577f1=_0x2b6073();_0x1b0964[_0x5bb97e(0x147)]++,_0x1b0964[_0x5bb97e(0x1a2)]+=_0x581ffa(_0x4e4795,_0x6577f1),_0x1b0964['ts']=_0x6577f1,_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0x147)]++,_0x1cd00b['hits'][_0x5bb97e(0x1a2)]+=_0x581ffa(_0x4e4795,_0x6577f1),_0x1cd00b[_0x5bb97e(0x138)]['ts']=_0x6577f1,(_0x1b0964[_0x5bb97e(0x147)]>_0xaa8f90['perLogpoint'][_0x5bb97e(0x18c)]||_0x1b0964[_0x5bb97e(0x1a2)]>_0xaa8f90[_0x5bb97e(0x166)][_0x5bb97e(0x164)])&&(_0x1b0964[_0x5bb97e(0xdf)]=!0x0),(_0x1cd00b['hits'][_0x5bb97e(0x147)]>_0xaa8f90[_0x5bb97e(0x174)][_0x5bb97e(0x18c)]||_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0x1a2)]>_0xaa8f90[_0x5bb97e(0x174)][_0x5bb97e(0x164)])&&(_0x1cd00b[_0x5bb97e(0x138)][_0x5bb97e(0xdf)]=!0x0);}}catch{}}}return _0x52b991;}var q=Symbol('ninja'),ce=0xc8,ee=_0x314333(0xcb);((_0x157237,_0x4288a3,_0x2cbc42,_0x5009de,_0x2ab9b9,_0x2e4a97,_0x5f4c91,_0x5bd040,_0x2b9f70,_0x13d723,_0x36d069,_0xc36025)=>{const _0x2fa468=_0x314333;if(!Y(_0x157237,_0x5bd040,_0x2e4a97)){_0x157237[_0x2fa468(0x70)]=!0x0;return;}if(_0x157237[_0x2fa468(0x70)])return;_0x157237[_0x2fa468(0x70)]=!0x0;let _0x22758a=_0x2e4a97===_0x2fa468(0xc7)&&_0x157237[_0x2fa468(0x18d)]?_0x157237[_0x2fa468(0x18d)]:void 0x0,_0x3b865f=!0x1,_0x455288={},_0x594d56={},_0x538083=()=>{const _0x5db2b1=_0x2fa468;for(let _0x12c99c of Object[_0x5db2b1(0xdc)](_0x455288))delete _0x455288[_0x12c99c];for(let _0x387146 of Object[_0x5db2b1(0xdc)](_0x594d56))delete _0x594d56[_0x387146];},_0xc82002=Z(_0x157237,_0x4288a3,_0x2cbc42,_0x5009de,_0x2e4a97,_0x2b9f70,_0x13d723,(_0x2e7ece,_0x271216,_0x4c10cb,_0x4870b4)=>{const _0x5a2d70=_0x2fa468;if(V(_0x2e7ece,_0x271216,_0x4c10cb,_0x4870b4),_0x2e7ece===_0x5a2d70(0xaa)){let _0x10862e=_0x271216[0x0];if(_0x10862e[_0x5a2d70(0xb7)]('captureRequests')&&_0x27bdf3(_0x10862e[_0x5a2d70(0xe0)]),_0x10862e['hasOwnProperty'](_0x5a2d70(0x16d))){for(let _0x54fa98 of _0x10862e[_0x5a2d70(0x16d)]){let _0x13d6b1=se(_0x1558e6[_0x5a2d70(0x10c)],_0x54fa98[_0x5a2d70(0xf5)]);_0x455288[_0x13d6b1]=_0x54fa98[_0x5a2d70(0x148)];for(let _0x400e96 of _0x54fa98[_0x5a2d70(0x148)]){let _0x39328b=_0x594d56[_0x400e96];if(_0x39328b)_0x39328b[_0x13d6b1]=void 0x0;else{let _0x571dd2={};_0x571dd2[_0x13d6b1]=void 0x0,_0x594d56[_0x400e96]=_0x571dd2;}}}Object['keys'](_0x455288)['length']>ce&&(_0x27bdf3(!0x1),_0x538083(),_0xc82002({'method':'pauseNetworkLogging','version':_0x2ab9b9,'args':[_0x1558e6]}));}if(_0x10862e[_0x5a2d70(0xb7)](_0x5a2d70(0x179)))for(let _0x7d7a2a of _0x10862e[_0x5a2d70(0x179)]){let _0xa716ef=_0x594d56[_0x7d7a2a];if(!!_0xa716ef)for(var _0x11c836 of Object['keys'](_0xa716ef)){let _0x35616b=_0x455288[_0x11c836];for(let _0x5683bf of _0x35616b){let _0x564542=_0x594d56[_0x5683bf];_0x564542&&delete _0x564542[_0x11c836],Object['keys'](_0x564542)[_0x5a2d70(0x188)]||delete _0x594d56[_0x5683bf];}delete _0x455288[_0x11c836];}}}}),_0x1558e6=_0x157237['_console_ninja_session'],_0x51c87b,_0x5b0527,_0x157a7b,_0x18bced,_0x2ecf38=me(_0x1558e6[_0x2fa468(0x10c)]);function _0x27bdf3(_0x1414ec){_0x3b865f!==_0x1414ec&&(_0x1414ec===!0x0?(_0x157a7b=_0x157a7b||pe(_0x157237,_0x1558e6,_0x2ab9b9,_0xc82002,_0x455288,_0x22758a,_0x2ecf38,_0x36d069),_0x18bced=_0x18bced||le(_0x157237,_0xc82002,_0x2ab9b9,_0x1558e6,_0x22758a),_0x51c87b=de(_0x157237,_0x157a7b,_0x18bced,_0x2ecf38),_0x5b0527=ue(_0x157237,_0x157a7b,_0x2ecf38),_0x3b865f=!0x0):_0x1414ec===!0x1&&(_0x51c87b(),_0x5b0527(),_0x3b865f=!0x1));}_0x27bdf3(!0x0);let _0x376e1b;_0x2e4a97===_0x2fa468(0xc7)&&_0x157237['TURBOPACK']&&_0xc36025&&_0xc36025[_0x2fa468(0x16f)]&&(_0x376e1b={'nextJsDistDir':_0xc36025[_0x2fa468(0x16f)]}),_0xc82002({'method':_0x2fa468(0x132),'version':_0x2ab9b9,'args':[_0x1558e6,_0x376e1b]});})(globalThis,'127.0.0.1',_0x314333(0x11e),_0x314333(0xd7),_0x314333(0x93),_0x314333(0xf7),_0x314333(0x120),_0x314333(0x191),_0x314333(0xff),_0x314333(0xa4),_0x314333(0x181),{\"nextJsDistDir\":\"/Users/abdelberkat/projets/synea/.next/dev\"});function ue(_0xd78019,_0x24814c,_0x2815b9){const _0x31119c=_0x314333;if(_0xd78019[_0x31119c(0xae)]&&_0xd78019[_0x31119c(0xae)][_0x31119c(0x1a9)]){let _0x406383=_0xd78019[_0x31119c(0xae)]['prototype'][_0x31119c(0xf9)],_0x402805=_0xd78019[_0x31119c(0xae)][_0x31119c(0x1a9)]['send'],_0x2d3d9b=_0xd78019[_0x31119c(0xae)][_0x31119c(0x1a9)]['setRequestHeader'];return _0x406383&&_0x402805&&_0x406383[_0x31119c(0xfe)]()['indexOf'](_0x31119c(0x15f))!==-0x1?(_0xd78019[_0x31119c(0xae)]['prototype'][_0x31119c(0xf9)]=function(_0x5d1bda,_0x8ae679){const _0x5dcfff=_0x31119c;let _0x2770cf=this[q]=this[q]||{};return _0x2770cf[_0x5dcfff(0x19d)]=_0x5d1bda,_0x2770cf['url']=_0x8ae679,_0x406383[_0x5dcfff(0x195)](this,arguments);},_0xd78019['XMLHttpRequest'][_0x31119c(0x1a9)][_0x31119c(0x17d)]=function(){const _0x11fe54=_0x31119c;let _0x25b4ca=te(_0x2815b9);return this['addEventListener'](_0x11fe54(0x122),()=>{const _0x30729f=_0x11fe54;var _0x112464,_0x35f0ac;if(this[_0x30729f(0x18f)]===0x4){let _0x5f1f5e=this[_0x30729f(0xc1)](_0x30729f(0xdd)),_0x2a9406=_0x5f1f5e&&_0x5f1f5e[_0x30729f(0x176)](ee)!==-0x1?ne(this[_0x30729f(0x1a3)],ee):this[_0x30729f(0x1a3)],_0x26a3f4=oe((_0x112464=this[q])==null?void 0x0:_0x112464[_0x30729f(0x156)]),_0x5b0230=_0x26a3f4?ne(arguments[0x0],_0x26a3f4):arguments[0x0],_0x352b14=(_0x35f0ac=this[_0x30729f(0xea)])==null?void 0x0:_0x35f0ac[_0x30729f(0xfe)]();_0x24814c({'stack':_0x25b4ca,'status':_0x352b14,'url':this[q][_0x30729f(0x18e)],'method':this[q][_0x30729f(0x19d)],'request':_0x5b0230,'response':_0x2a9406});}}),_0x402805['apply'](this,arguments);},_0x2d3d9b&&(_0xd78019[_0x31119c(0xae)][_0x31119c(0x1a9)][_0x31119c(0x146)]=function(_0x4f823e,_0x3adbbb){const _0x20bf25=_0x31119c;let _0x251c05=this[q]=this[q]||{},_0x2ea12d=_0x251c05[_0x20bf25(0x156)]=_0x251c05['headers']||{};_0x2ea12d[_0x4f823e]=_0x3adbbb,_0x2d3d9b[_0x20bf25(0x195)](this,arguments);}),()=>{const _0x4ef9df=_0x31119c;_0xd78019['XMLHttpRequest'][_0x4ef9df(0x1a9)]['open']=_0x406383,_0xd78019['XMLHttpRequest']['prototype'][_0x4ef9df(0x17d)]=_0x402805,_0xd78019[_0x4ef9df(0xae)][_0x4ef9df(0x1a9)]['setRequestHeader']=_0x2d3d9b;}):()=>{};}}function de(_0x21d2db,_0x164bbf,_0x3782a0,_0x39e1e8){const _0x469610=_0x314333;let _0x1e9692=_0x21d2db[_0x469610(0x88)];if(_0x21d2db[_0x469610(0x19f)]&&_0x21d2db[_0x469610(0x19f)]['prototype']&&_0x1e9692['toString']()['indexOf']('native\\x20code')!==-0x1){let _0xd2eda5=function(){const _0x59916b=_0x469610;return _0x21d2db[_0x59916b(0x88)]=function(..._0x5d51b0){const _0x1067e6=_0x59916b;var _0x289b6b;let [_0x2ea056,_0x2036d5]=_0x5d51b0,_0x4842fc=_0x2036d5&&_0x2036d5[_0x1067e6(0x19d)]?_0x2036d5[_0x1067e6(0x19d)]:_0x1067e6(0x145),_0x3633df=te(_0x39e1e8),_0x56279c=_0x5d51b0&&_0x5d51b0[_0x1067e6(0x188)]>0x0&&((_0x289b6b=_0x5d51b0[0x1])==null?void 0x0:_0x289b6b[_0x1067e6(0x156)]),_0x5c678d=oe(_0x56279c),_0x31796f=_0x2036d5!=null&&_0x2036d5[_0x1067e6(0x172)]?ne(_0x2036d5[_0x1067e6(0x172)],_0x5c678d):_0x2036d5==null?void 0x0:_0x2036d5[_0x1067e6(0x172)];return _0x1e9692[_0x1067e6(0x195)](this,_0x5d51b0)['then'](_0x29f134=>(_0x29f134[q]={'method':_0x4842fc,'fetchStack':_0x3633df,'request':_0x31796f},_0x29f134));},()=>_0x21d2db[_0x59916b(0x88)]=_0x1e9692;},_0x28e6c0=function(_0x7e933a,_0x33cef4=_0x2fcf4b=>_0x2fcf4b){const _0x1c1fec=_0x469610;let _0x17af12=_0x21d2db[_0x1c1fec(0x19f)][_0x1c1fec(0x1a9)][_0x7e933a];return _0x17af12?(_0x21d2db[_0x1c1fec(0x19f)]['prototype'][_0x7e933a]=async function(){const _0x1e1e21=_0x1c1fec;var _0x358175;let _0x4dd847=te(_0x39e1e8),_0x4ded4d;try{_0x4ded4d=await _0x17af12[_0x1e1e21(0x195)](this,arguments);}catch(_0x4aec7a){throw _0x3782a0(_0x4aec7a,_0x4dd847),_0x4aec7a;}let _0x46e879=this[q];return _0x46e879&&_0x164bbf({'stack':_0x4dd847,'fetchStack':_0x46e879['fetchStack'],'url':this[_0x1e1e21(0x18e)],'status':(_0x358175=this[_0x1e1e21(0xea)])==null?void 0x0:_0x358175[_0x1e1e21(0xfe)](),'request':_0x46e879[_0x1e1e21(0xc5)],'response':_0x33cef4(_0x4ded4d),'method':_0x46e879[_0x1e1e21(0x19d)]}),_0x4ded4d;},()=>_0x21d2db[_0x1c1fec(0x19f)][_0x1c1fec(0x1a9)][_0x7e933a]=_0x17af12):()=>{};};var _0x1e8c08=_0xd2eda5,_0x513393=_0x28e6c0;let _0x1003f9=[_0xd2eda5(),_0x28e6c0(_0x469610(0x11d)),_0x28e6c0(_0x469610(0x1a0)),_0x28e6c0(_0x469610(0x92),_0x2fb959=>({'blob':{'size':_0x2fb959['size'],'type':_0x2fb959['type']}})),_0x28e6c0(_0x469610(0xb1),_0x251906=>({'arrayBuffer':{'byteLength':_0x251906['byteLength']}}))];return()=>_0x1003f9['forEach'](_0x34ef6a=>_0x34ef6a());}return()=>{};}function te(_0x289e01){const _0x28b1f1=_0x314333;try{let _0x11912d=Error['stackTraceLimit'];Error['stackTraceLimit']=_0x289e01;let _0x2e202d=new Error()[_0x28b1f1(0xf5)];return Error[_0x28b1f1(0x9e)]=_0x11912d,_0x2e202d;}catch{return'';}}function se(_0x1e34ca,_0x135dfa){const _0x3ffa17=_0x314333;return _0x135dfa[_0x3ffa17(0x116)](/\\?t=\\d+/g,'');}var fe=[_0x314333(0xb3),_0x314333(0x1a5),'__nextjs_original-stack-frame'];function he(_0x529600){const _0x1d02c2=_0x314333;return!!(typeof _0x529600==_0x1d02c2(0x157)&&fe[_0x1d02c2(0xd0)](_0x2c568a=>_0x529600[_0x1d02c2(0x176)](_0x2c568a)!==-0x1));}function le(_0x32e92d,_0x5704e2,_0x5150e2,_0x424a31,_0x3a7e28){return(_0x46bc71,_0x461bf0)=>{const _0x25fd25=_0x437c;_0x32e92d[_0x25fd25(0x8e)]&&(_0x32e92d[_0x25fd25(0x14a)]=_0x46bc71);let _0x15eb99=String[_0x25fd25(0x1ab)](0xa),_0x167623=_0x461bf0[_0x25fd25(0x102)](_0x15eb99);_0x167623[_0x25fd25(0x188)]>0x2&&_0x167623[_0x25fd25(0x144)](0x0,0x3),_0x461bf0=_0x46bc71['stack'][_0x25fd25(0x102)](_0x15eb99)[0x0]+_0x15eb99+_0x167623['join'](_0x15eb99),_0x5704e2({'method':'error','version':_0x5150e2,'args':[{'ts':Date['now'](),'session':_0x424a31,'message':_0x46bc71[_0x25fd25(0x15c)]||'','stack':_0x461bf0,'generatedStack':void 0x0,'stackTraceLimit':Error['stackTraceLimit'],'origin':_0x3a7e28}]});};}function pe(_0x159510,_0x27435f,_0x55e9f5,_0xbab482,_0x570d9f,_0x258a71,_0x48e53d,_0x469693){let _0x388ce5;return({stack:_0x3d9e20,url:_0x5f0644,status:_0x49ac71,response:_0x53a153,method:_0x210f64,fetchStack:_0x4630f5,request:_0x57f2dc})=>{const _0x2bf367=_0x437c;if(he(_0x5f0644))return;let _0x120324=_0x4630f5?_0x3d9e20+'\\x0a'+_0x4630f5:_0x3d9e20;if(_0x570d9f[se(_0x27435f['tool'],_0x120324)])return;let _0x49673f={'url':_0x5f0644,'status':_0x49ac71,'method':_0x210f64,'request':_0x57f2dc,'response':_0x53a153};_0x388ce5=_0x388ce5||K(_0x159510,!0x1,{'hits':{},'ts':{}},_0x55e9f5,_0x469693);let _0x2f011a=_0x388ce5(_0x2bf367(0xbb),_0x2bf367(0xa7),Date[_0x2bf367(0x14b)](),_0x27435f,[_0x49673f]);_0x2f011a[_0x2bf367(0xa9)][0x0][_0x2bf367(0xa9)][0x0][_0x2bf367(0x133)]['push']({'name':_0x2bf367(0xf5),'type':_0x2bf367(0x157),'value':_0x3d9e20}),_0x2f011a[_0x2bf367(0xa9)][0x0][_0x2bf367(0xa9)][0x0][_0x2bf367(0x133)]['push']({'name':_0x2bf367(0xe1),'type':_0x2bf367(0x157),'value':_0x4630f5}),_0x258a71&&(_0x2f011a[_0x2bf367(0xa9)][0x0]['origin']=_0x258a71),_0x2f011a[_0x2bf367(0xa9)][0x0][_0x2bf367(0x9e)]=_0x48e53d,_0xbab482(_0x2f011a);};}function _0x437c(_0x19bb24,_0x3ba8f1){const _0x27010b=_0x2701();return _0x437c=function(_0x437c5d,_0x50099e){_0x437c5d=_0x437c5d-0x70;let _0x11de36=_0x27010b[_0x437c5d];return _0x11de36;},_0x437c(_0x19bb24,_0x3ba8f1);}var _e=['Blob',_0x314333(0x128),_0x314333(0x16c),_0x314333(0x13c),'FormData',_0x314333(0xcc),_0x314333(0x171)];function ne(_0x5023d6,_0x2a0fbf){const _0x50c990=_0x314333;if(typeof _0x5023d6==_0x50c990(0x157)){try{if(_0x2a0fbf&&_0x2a0fbf['toLowerCase']()===ee)return JSON[_0x50c990(0xcd)](_0x5023d6);}catch{}return _0x5023d6;}if(typeof _0x5023d6==_0x50c990(0x16e)&&(_0x5023d6==null?void 0x0:_0x5023d6['constructor'][_0x50c990(0xd3)])){let _0x25cd30=_0x5023d6==null?void 0x0:_0x5023d6['constructor']['name'];return _0x25cd30&&_e['some'](_0x549d52=>_0x549d52===_0x25cd30)?'<'+_0x25cd30+'>':_0x5023d6;}return _0x5023d6;}function me(_0x3416f6){const _0x3ddbb5=_0x314333;return _0x3416f6?_0x3416f6===_0x3ddbb5(0x18a)?0x32:_0x3416f6===_0x3ddbb5(0xd5)?0x64:0x1e:0x1e;}function oe(_0x2a0c23){const _0x4d8bd9=_0x314333;var _0x1c2ca2;return _0x2a0c23?(_0x1c2ca2=Object[_0x4d8bd9(0xbf)](_0x2a0c23)[_0x4d8bd9(0x126)](([_0x29b5bd,_0x8550a8])=>(_0x29b5bd==null?void 0x0:_0x29b5bd['toLowerCase']())===_0x4d8bd9(0xba)))==null?void 0x0:_0x1c2ca2[0x1]:void 0x0;}");
} catch (e) {
    console.error(e);
}
"trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
    configurable: !0,
    get: function() {
        var t = /\((.*)\)/.exec(this.toString());
        return t ? t[1] : void 0;
    }
}), Array.prototype.flat || (Array.prototype.flat = function(t, r) {
    return r = this.concat.apply([], this), t > 1 && r.some(Array.isArray) ? r.flat(t - 1) : r;
}, Array.prototype.flatMap = function(t, r) {
    return this.map(t, r).flat();
}), Promise.prototype.finally || (Promise.prototype.finally = function(t) {
    if ("function" != typeof t) return this.then(t, t);
    var r = this.constructor || Promise;
    return this.then(function(n) {
        return r.resolve(t()).then(function() {
            return n;
        });
    }, function(n) {
        return r.resolve(t()).then(function() {
            throw n;
        });
    });
}), Object.fromEntries || (Object.fromEntries = function(t) {
    return Array.from(t).reduce(function(t, r) {
        return t[r[0]] = r[1], t;
    }, {});
}), Array.prototype.at || (Array.prototype.at = function(t) {
    var r = Math.trunc(t) || 0;
    if (r < 0 && (r += this.length), !(r < 0 || r >= this.length)) return this[r];
}), Object.hasOwn || (Object.hasOwn = function(t, r) {
    if (null == t) throw new TypeError("Cannot convert undefined or null to object");
    return Object.prototype.hasOwnProperty.call(Object(t), r);
}), "canParse" in URL || (URL.canParse = function(t, r) {
    try {
        return !!new URL(t, r);
    } catch (t) {
        return !1;
    }
});
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InvariantError", {
    enumerable: true,
    get: function() {
        return InvariantError;
    }
});
class InvariantError extends Error {
    constructor(message, options){
        super(`Invariant: ${message.endsWith('.') ? message : message + '.'} This is a bug in Next.js.`, options);
        this.name = 'InvariantError';
    }
} //# sourceMappingURL=invariant-error.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getObjectClassLabel: null,
    isPlainObject: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getObjectClassLabel: function() {
        return getObjectClassLabel;
    },
    isPlainObject: function() {
        return isPlainObject;
    }
});
function getObjectClassLabel(value) {
    return Object.prototype.toString.call(value);
}
function isPlainObject(value) {
    if (getObjectClassLabel(value) !== '[object Object]') {
        return false;
    }
    const prototype = Object.getPrototypeOf(value);
    /**
   * this used to be previously:
   *
   * `return prototype === null || prototype === Object.prototype`
   *
   * but Edge Runtime expose Object from vm, being that kind of type-checking wrongly fail.
   *
   * It was changed to the current implementation since it's resilient to serialization.
   */ return prototype === null || prototype.hasOwnProperty('isPrototypeOf');
} //# sourceMappingURL=is-plain-object.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This has to be a shared module which is shared between client component error boundary and dynamic component
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    BailoutToCSRError: null,
    isBailoutToCSRError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    BailoutToCSRError: function() {
        return BailoutToCSRError;
    },
    isBailoutToCSRError: function() {
        return isBailoutToCSRError;
    }
});
const BAILOUT_TO_CSR = 'BAILOUT_TO_CLIENT_SIDE_RENDERING';
class BailoutToCSRError extends Error {
    constructor(reason){
        super(`Bail out to client-side rendering: ${reason}`), this.reason = reason, this.digest = BAILOUT_TO_CSR;
    }
}
function isBailoutToCSRError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === BAILOUT_TO_CSR;
} //# sourceMappingURL=bailout-to-csr.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateServerError: null,
    getErrorSource: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateServerError: function() {
        return decorateServerError;
    },
    getErrorSource: function() {
        return getErrorSource;
    }
});
const symbolError = Symbol.for('NextjsError');
function getErrorSource(error) {
    return error[symbolError] || null;
}
function decorateServerError(error, type) {
    Object.defineProperty(error, symbolError, {
        writable: false,
        enumerable: false,
        configurable: false,
        value: type
    });
} //# sourceMappingURL=error-source.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/head-manager-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HeadManagerContext", {
    enumerable: true,
    get: function() {
        return HeadManagerContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const HeadManagerContext = _react.default.createContext({});
if ("TURBOPACK compile-time truthy", 1) {
    HeadManagerContext.displayName = 'HeadManagerContext';
} //# sourceMappingURL=head-manager-context.shared-runtime.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/hooks-client-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    NavigationPromisesContext: null,
    PathParamsContext: null,
    PathnameContext: null,
    ReadonlyURLSearchParams: null,
    SearchParamsContext: null,
    createDevToolsInstrumentedPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    NavigationPromisesContext: function() {
        return NavigationPromisesContext;
    },
    PathParamsContext: function() {
        return PathParamsContext;
    },
    PathnameContext: function() {
        return PathnameContext;
    },
    ReadonlyURLSearchParams: function() {
        return _readonlyurlsearchparams.ReadonlyURLSearchParams;
    },
    SearchParamsContext: function() {
        return SearchParamsContext;
    },
    createDevToolsInstrumentedPromise: function() {
        return createDevToolsInstrumentedPromise;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _readonlyurlsearchparams = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/readonly-url-search-params.js [app-client] (ecmascript)");
const SearchParamsContext = (0, _react.createContext)(null);
const PathnameContext = (0, _react.createContext)(null);
const PathParamsContext = (0, _react.createContext)(null);
const NavigationPromisesContext = (0, _react.createContext)(null);
function createDevToolsInstrumentedPromise(displayName, value) {
    const promise = Promise.resolve(value);
    promise.status = 'fulfilled';
    promise.value = value;
    promise.displayName = `${displayName} (SSR)`;
    return promise;
}
if ("TURBOPACK compile-time truthy", 1) {
    SearchParamsContext.displayName = 'SearchParamsContext';
    PathnameContext.displayName = 'PathnameContext';
    PathParamsContext.displayName = 'PathParamsContext';
    NavigationPromisesContext.displayName = 'NavigationPromisesContext';
} //# sourceMappingURL=hooks-client-context.shared-runtime.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This regex contains the bots that we need to do a blocking render for and can't safely stream the response
// due to how they parse the DOM. For example, they might explicitly check for metadata in the `head` tag, so we can't stream metadata tags after the `head` was sent.
// Note: The pattern [\w-]+-Google captures all Google crawlers with "-Google" suffix (e.g., Mediapartners-Google, AdsBot-Google, Storebot-Google)
// as well as crawlers starting with "Google-" (e.g., Google-PageRenderer, Google-InspectionTool)
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HTML_LIMITED_BOT_UA_RE", {
    enumerable: true,
    get: function() {
        return HTML_LIMITED_BOT_UA_RE;
    }
});
const HTML_LIMITED_BOT_UA_RE = /[\w-]+-Google|Google-[\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight/i; //# sourceMappingURL=html-bots.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/is-bot.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HTML_LIMITED_BOT_UA_RE: null,
    HTML_LIMITED_BOT_UA_RE_STRING: null,
    getBotType: null,
    isBot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HTML_LIMITED_BOT_UA_RE: function() {
        return _htmlbots.HTML_LIMITED_BOT_UA_RE;
    },
    HTML_LIMITED_BOT_UA_RE_STRING: function() {
        return HTML_LIMITED_BOT_UA_RE_STRING;
    },
    getBotType: function() {
        return getBotType;
    },
    isBot: function() {
        return isBot;
    }
});
const _htmlbots = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)");
// Bot crawler that will spin up a headless browser and execute JS.
// Only the main Googlebot search crawler executes JavaScript, not other Google crawlers.
// x-ref: https://developers.google.com/search/docs/crawling-indexing/google-common-crawlers
// This regex specifically matches "Googlebot" but NOT "Mediapartners-Google", "AdsBot-Google", etc.
const HEADLESS_BROWSER_BOT_UA_RE = /Googlebot(?!-)|Googlebot$/i;
const HTML_LIMITED_BOT_UA_RE_STRING = _htmlbots.HTML_LIMITED_BOT_UA_RE.source;
function isDomBotUA(userAgent) {
    return HEADLESS_BROWSER_BOT_UA_RE.test(userAgent);
}
function isHtmlLimitedBotUA(userAgent) {
    return _htmlbots.HTML_LIMITED_BOT_UA_RE.test(userAgent);
}
function isBot(userAgent) {
    return isDomBotUA(userAgent) || isHtmlLimitedBotUA(userAgent);
}
function getBotType(userAgent) {
    if (isDomBotUA(userAgent)) {
        return 'dom';
    }
    if (isHtmlLimitedBotUA(userAgent)) {
        return 'html';
    }
    return undefined;
} //# sourceMappingURL=is-bot.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/is-thenable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Check to see if a value is Thenable.
 *
 * @param promise the maybe-thenable value
 * @returns true if the value is thenable
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isThenable", {
    enumerable: true,
    get: function() {
        return isThenable;
    }
});
function isThenable(promise) {
    return promise !== null && typeof promise === 'object' && 'then' in promise && typeof promise.then === 'function';
} //# sourceMappingURL=is-thenable.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * For a given page path, this function ensures that there is a leading slash.
 * If there is not a leading slash, one is added, otherwise it is noop.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ensureLeadingSlash", {
    enumerable: true,
    get: function() {
        return ensureLeadingSlash;
    }
});
function ensureLeadingSlash(path) {
    return path.startsWith('/') ? path : `/${path}`;
} //# sourceMappingURL=ensure-leading-slash.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DEFAULT_SEGMENT_KEY: null,
    NOT_FOUND_SEGMENT_KEY: null,
    PAGE_SEGMENT_KEY: null,
    addSearchParamsIfPageSegment: null,
    computeSelectedLayoutSegment: null,
    getSegmentValue: null,
    getSelectedLayoutSegmentPath: null,
    isGroupSegment: null,
    isParallelRouteSegment: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DEFAULT_SEGMENT_KEY: function() {
        return DEFAULT_SEGMENT_KEY;
    },
    NOT_FOUND_SEGMENT_KEY: function() {
        return NOT_FOUND_SEGMENT_KEY;
    },
    PAGE_SEGMENT_KEY: function() {
        return PAGE_SEGMENT_KEY;
    },
    addSearchParamsIfPageSegment: function() {
        return addSearchParamsIfPageSegment;
    },
    computeSelectedLayoutSegment: function() {
        return computeSelectedLayoutSegment;
    },
    getSegmentValue: function() {
        return getSegmentValue;
    },
    getSelectedLayoutSegmentPath: function() {
        return getSelectedLayoutSegmentPath;
    },
    isGroupSegment: function() {
        return isGroupSegment;
    },
    isParallelRouteSegment: function() {
        return isParallelRouteSegment;
    }
});
function getSegmentValue(segment) {
    return Array.isArray(segment) ? segment[1] : segment;
}
function isGroupSegment(segment) {
    // Use array[0] for performant purpose
    return segment[0] === '(' && segment.endsWith(')');
}
function isParallelRouteSegment(segment) {
    return segment.startsWith('@') && segment !== '@children';
}
function addSearchParamsIfPageSegment(segment, searchParams) {
    const isPageSegment = segment.includes(PAGE_SEGMENT_KEY);
    if (isPageSegment) {
        const stringifiedQuery = JSON.stringify(searchParams);
        return stringifiedQuery !== '{}' ? PAGE_SEGMENT_KEY + '?' + stringifiedQuery : PAGE_SEGMENT_KEY;
    }
    return segment;
}
function computeSelectedLayoutSegment(segments, parallelRouteKey) {
    if (!segments || segments.length === 0) {
        return null;
    }
    // For 'children', use first segment; for other parallel routes, use last segment
    const rawSegment = parallelRouteKey === 'children' ? segments[0] : segments[segments.length - 1];
    // If the default slot is showing, return null since it's not technically "selected" (it's a fallback)
    // Returning an internal value like `__DEFAULT__` would be confusing
    return rawSegment === DEFAULT_SEGMENT_KEY ? null : rawSegment;
}
function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first = true, segmentPath = []) {
    let node;
    if (first) {
        // Use the provided parallel route key on the first parallel route
        node = tree[1][parallelRouteKey];
    } else {
        // After first parallel route prefer children, if there's no children pick the first parallel route.
        const parallelRoutes = tree[1];
        node = parallelRoutes.children ?? Object.values(parallelRoutes)[0];
    }
    if (!node) return segmentPath;
    const segment = node[0];
    let segmentValue = getSegmentValue(segment);
    if (!segmentValue || segmentValue.startsWith(PAGE_SEGMENT_KEY)) {
        return segmentPath;
    }
    segmentPath.push(segmentValue);
    return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
}
const PAGE_SEGMENT_KEY = '__PAGE__';
const DEFAULT_SEGMENT_KEY = '__DEFAULT__';
const NOT_FOUND_SEGMENT_KEY = '/_not-found'; //# sourceMappingURL=segment.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    normalizeAppPath: null,
    normalizeRscURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    normalizeAppPath: function() {
        return normalizeAppPath;
    },
    normalizeRscURL: function() {
        return normalizeRscURL;
    }
});
const _ensureleadingslash = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)");
const _segment = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
function normalizeAppPath(route) {
    return (0, _ensureleadingslash.ensureLeadingSlash)(route.split('/').reduce((pathname, segment, index, segments)=>{
        // Empty segments are ignored.
        if (!segment) {
            return pathname;
        }
        // Groups are ignored.
        if ((0, _segment.isGroupSegment)(segment)) {
            return pathname;
        }
        // Parallel segments are ignored.
        if (segment[0] === '@') {
            return pathname;
        }
        // The last segment (if it's a leaf) should be ignored.
        if ((segment === 'page' || segment === 'route') && index === segments.length - 1) {
            return pathname;
        }
        return `${pathname}/${segment}`;
    }, ''));
}
function normalizeRscURL(url) {
    return url.replace(/\.rsc($|\?)/, '$1');
} //# sourceMappingURL=app-paths.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/interception-routes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    INTERCEPTION_ROUTE_MARKERS: null,
    extractInterceptionRouteInformation: null,
    isInterceptionRouteAppPath: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    INTERCEPTION_ROUTE_MARKERS: function() {
        return INTERCEPTION_ROUTE_MARKERS;
    },
    extractInterceptionRouteInformation: function() {
        return extractInterceptionRouteInformation;
    },
    isInterceptionRouteAppPath: function() {
        return isInterceptionRouteAppPath;
    }
});
const _apppaths = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)");
const INTERCEPTION_ROUTE_MARKERS = [
    '(..)(..)',
    '(.)',
    '(..)',
    '(...)'
];
function isInterceptionRouteAppPath(path) {
    // TODO-APP: add more serious validation
    return path.split('/').find((segment)=>INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m))) !== undefined;
}
function extractInterceptionRouteInformation(path) {
    let interceptingRoute;
    let marker;
    let interceptedRoute;
    for (const segment of path.split('/')){
        marker = INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m));
        if (marker) {
            ;
            [interceptingRoute, interceptedRoute] = path.split(marker, 2);
            break;
        }
    }
    if (!interceptingRoute || !marker || !interceptedRoute) {
        throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>`), "__NEXT_ERROR_CODE", {
            value: "E269",
            enumerable: false,
            configurable: true
        });
    }
    interceptingRoute = (0, _apppaths.normalizeAppPath)(interceptingRoute) // normalize the path, e.g. /(blog)/feed -> /feed
    ;
    switch(marker){
        case '(.)':
            // (.) indicates that we should match with sibling routes, so we just need to append the intercepted route to the intercepting route
            if (interceptingRoute === '/') {
                interceptedRoute = `/${interceptedRoute}`;
            } else {
                interceptedRoute = interceptingRoute + '/' + interceptedRoute;
            }
            break;
        case '(..)':
            // (..) indicates that we should match at one level up, so we need to remove the last segment of the intercepting route
            if (interceptingRoute === '/') {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..) marker at the root level, use (.) instead.`), "__NEXT_ERROR_CODE", {
                    value: "E207",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = interceptingRoute.split('/').slice(0, -1).concat(interceptedRoute).join('/');
            break;
        case '(...)':
            // (...) will match the route segment in the root directory, so we need to use the root directory to prepend the intercepted route
            interceptedRoute = '/' + interceptedRoute;
            break;
        case '(..)(..)':
            // (..)(..) indicates that we should match at two levels up, so we need to remove the last two segments of the intercepting route
            const splitInterceptingRoute = interceptingRoute.split('/');
            if (splitInterceptingRoute.length <= 2) {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..)(..) marker at the root level or one level up.`), "__NEXT_ERROR_CODE", {
                    value: "E486",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = splitInterceptingRoute.slice(0, -2).concat(interceptedRoute).join('/');
            break;
        default:
            throw Object.defineProperty(new Error('Invariant: unexpected marker'), "__NEXT_ERROR_CODE", {
                value: "E112",
                enumerable: false,
                configurable: true
            });
    }
    return {
        interceptingRoute,
        interceptedRoute
    };
} //# sourceMappingURL=interception-routes.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/segment-cache/segment-value-encoding.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HEAD_REQUEST_KEY: null,
    ROOT_SEGMENT_REQUEST_KEY: null,
    appendSegmentRequestKeyPart: null,
    convertSegmentPathToStaticExportFilename: null,
    createSegmentRequestKeyPart: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HEAD_REQUEST_KEY: function() {
        return HEAD_REQUEST_KEY;
    },
    ROOT_SEGMENT_REQUEST_KEY: function() {
        return ROOT_SEGMENT_REQUEST_KEY;
    },
    appendSegmentRequestKeyPart: function() {
        return appendSegmentRequestKeyPart;
    },
    convertSegmentPathToStaticExportFilename: function() {
        return convertSegmentPathToStaticExportFilename;
    },
    createSegmentRequestKeyPart: function() {
        return createSegmentRequestKeyPart;
    }
});
const _segment = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
const ROOT_SEGMENT_REQUEST_KEY = '';
const HEAD_REQUEST_KEY = '/_head';
function createSegmentRequestKeyPart(segment) {
    if (typeof segment === 'string') {
        if (segment.startsWith(_segment.PAGE_SEGMENT_KEY)) {
            // The Flight Router State type sometimes includes the search params in
            // the page segment. However, the Segment Cache tracks this as a separate
            // key. So, we strip the search params here, and then add them back when
            // the cache entry is turned back into a FlightRouterState. This is an
            // unfortunate consequence of the FlightRouteState being used both as a
            // transport type and as a cache key; we'll address this once more of the
            // Segment Cache implementation has settled.
            // TODO: We should hoist the search params out of the FlightRouterState
            // type entirely, This is our plan for dynamic route params, too.
            return _segment.PAGE_SEGMENT_KEY;
        }
        const safeName = // But params typically don't include the leading slash. We should use
        // a different encoding to avoid this special case.
        segment === '/_not-found' ? '_not-found' : encodeToFilesystemAndURLSafeString(segment);
        // Since this is not a dynamic segment, it's fully encoded. It does not
        // need to be "hydrated" with a param value.
        return safeName;
    }
    const name = segment[0];
    const paramType = segment[2];
    const safeName = encodeToFilesystemAndURLSafeString(name);
    const encodedName = '$' + paramType + '$' + safeName;
    return encodedName;
}
function appendSegmentRequestKeyPart(parentRequestKey, parallelRouteKey, childRequestKeyPart) {
    // Aside from being filesystem safe, segment keys are also designed so that
    // each segment and parallel route creates its own subdirectory. Roughly in
    // the same shape as the source app directory. This is mostly just for easier
    // debugging (you can open up the build folder and navigate the output); if
    // we wanted to do we could just use a flat structure.
    // Omit the parallel route key for children, since this is the most
    // common case. Saves some bytes (and it's what the app directory does).
    const slotKey = parallelRouteKey === 'children' ? childRequestKeyPart : `@${encodeToFilesystemAndURLSafeString(parallelRouteKey)}/${childRequestKeyPart}`;
    return parentRequestKey + '/' + slotKey;
}
// Define a regex pattern to match the most common characters found in a route
// param. It excludes anything that might not be cross-platform filesystem
// compatible, like |. It does not need to be precise because the fallback is to
// just base64url-encode the whole parameter, which is fine; we just don't do it
// by default for compactness, and for easier debugging.
const simpleParamValueRegex = /^[a-zA-Z0-9\-_@]+$/;
function encodeToFilesystemAndURLSafeString(value) {
    if (simpleParamValueRegex.test(value)) {
        return value;
    }
    // If there are any unsafe characters, base64url-encode the entire value.
    // We also add a ! prefix so it doesn't collide with the simple case.
    const base64url = btoa(value).replace(/\+/g, '-') // Replace '+' with '-'
    .replace(/\//g, '_') // Replace '/' with '_'
    .replace(/=+$/, '') // Remove trailing '='
    ;
    return '!' + base64url;
}
function convertSegmentPathToStaticExportFilename(segmentPath) {
    return `__next${segmentPath.replace(/\//g, '.')}.txt`;
} //# sourceMappingURL=segment-value-encoding.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// http://www.cse.yorku.ca/~oz/hash.html
// More specifically, 32-bit hash via djbxor
// (ref: https://gist.github.com/eplawless/52813b1d8ad9af510d85?permalink_comment_id=3367765#gistcomment-3367765)
// This is due to number type differences between rust for turbopack to js number types,
// where rust does not have easy way to repreesnt js's 53-bit float number type for the matching
// overflow behavior. This is more `correct` in terms of having canonical hash across different runtime / implementation
// as can gaurantee determinstic output from 32bit hash.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    djb2Hash: null,
    hexHash: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    djb2Hash: function() {
        return djb2Hash;
    },
    hexHash: function() {
        return hexHash;
    }
});
function djb2Hash(str) {
    let hash = 5381;
    for(let i = 0; i < str.length; i++){
        const char = str.charCodeAt(i);
        hash = (hash << 5) + hash + char & 0xffffffff;
    }
    return hash >>> 0;
}
function hexHash(str) {
    return djb2Hash(str).toString(36).slice(0, 5);
} //# sourceMappingURL=hash.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/cache-busting-search-param.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "computeCacheBustingSearchParam", {
    enumerable: true,
    get: function() {
        return computeCacheBustingSearchParam;
    }
});
const _hash = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)");
function computeCacheBustingSearchParam(prefetchHeader, segmentPrefetchHeader, stateTreeHeader, nextUrlHeader) {
    if ((prefetchHeader === undefined || prefetchHeader === '0') && segmentPrefetchHeader === undefined && stateTreeHeader === undefined && nextUrlHeader === undefined) {
        return '';
    }
    return (0, _hash.hexHash)([
        prefetchHeader || '0',
        segmentPrefetchHeader || '0',
        stateTreeHeader || '0',
        nextUrlHeader || '0'
    ].join(','));
} //# sourceMappingURL=cache-busting-search-param.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/deployment-id.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// This could also be a variable instead of a function, but some unit tests want to change the ID at
// runtime. Even though that would never happen in a real deployment.
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getDeploymentId: null,
    getDeploymentIdQueryOrEmptyString: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getDeploymentId: function() {
        return getDeploymentId;
    },
    getDeploymentIdQueryOrEmptyString: function() {
        return getDeploymentIdQueryOrEmptyString;
    }
});
function getDeploymentId() {
    return "TURBOPACK compile-time value", false;
}
function getDeploymentIdQueryOrEmptyString() {
    let deploymentId = getDeploymentId();
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return '';
} //# sourceMappingURL=deployment-id.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/app-router-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * App Router types - Client-safe types for the Next.js App Router
 *
 * This file contains type definitions that can be safely imported
 * by both client-side and server-side code without circular dependencies.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HasLoadingBoundary", {
    enumerable: true,
    get: function() {
        return HasLoadingBoundary;
    }
});
var HasLoadingBoundary = /*#__PURE__*/ function(HasLoadingBoundary) {
    // There is a loading boundary in this particular segment
    HasLoadingBoundary[HasLoadingBoundary["SegmentHasLoadingBoundary"] = 1] = "SegmentHasLoadingBoundary";
    // There is a loading boundary somewhere in the subtree (but not in
    // this segment)
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasLoadingBoundary"] = 2] = "SubtreeHasLoadingBoundary";
    // There is no loading boundary in this segment or any of its descendants
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasNoLoadingBoundary"] = 3] = "SubtreeHasNoLoadingBoundary";
    return HasLoadingBoundary;
}({}); //# sourceMappingURL=app-router-types.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Given a path this function will find the pathname, query and hash and return
 * them. This is useful to parse full paths on the client side.
 * @param path A path to parse e.g. /foo/bar?id=1#hash
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "parsePath", {
    enumerable: true,
    get: function() {
        return parsePath;
    }
});
function parsePath(path) {
    const hashIndex = path.indexOf('#');
    const queryIndex = path.indexOf('?');
    const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
    if (hasQuery || hashIndex > -1) {
        return {
            pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
            query: hasQuery ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : undefined) : '',
            hash: hashIndex > -1 ? path.slice(hashIndex) : ''
        };
    }
    return {
        pathname: path,
        query: '',
        hash: ''
    };
} //# sourceMappingURL=parse-path.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/add-path-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "addPathPrefix", {
    enumerable: true,
    get: function() {
        return addPathPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function addPathPrefix(path, prefix) {
    if (!path.startsWith('/') || !prefix) {
        return path;
    }
    const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
    return `${prefix}${pathname}${query}${hash}`;
} //# sourceMappingURL=add-path-prefix.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/remove-trailing-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Removes the trailing slash for a given route or page path. Preserves the
 * root page. Examples:
 *   - `/foo/bar/` -> `/foo/bar`
 *   - `/foo/bar` -> `/foo/bar`
 *   - `/` -> `/`
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "removeTrailingSlash", {
    enumerable: true,
    get: function() {
        return removeTrailingSlash;
    }
});
function removeTrailingSlash(route) {
    return route.replace(/\/$/, '') || '/';
} //# sourceMappingURL=remove-trailing-slash.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/promise-with-resolvers.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createPromiseWithResolvers", {
    enumerable: true,
    get: function() {
        return createPromiseWithResolvers;
    }
});
function createPromiseWithResolvers() {
    // Shim of Stage 4 Promise.withResolvers proposal
    let resolve;
    let reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    return {
        resolve: resolve,
        reject: reject,
        promise
    };
} //# sourceMappingURL=promise-with-resolvers.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/path-has-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "pathHasPrefix", {
    enumerable: true,
    get: function() {
        return pathHasPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function pathHasPrefix(path, prefix) {
    if (typeof path !== 'string') {
        return false;
    }
    const { pathname } = (0, _parsepath.parsePath)(path);
    return pathname === prefix || pathname.startsWith(prefix + '/');
} //# sourceMappingURL=path-has-prefix.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/server-reference-info.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    extractInfoFromServerReferenceId: null,
    omitUnusedArgs: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    extractInfoFromServerReferenceId: function() {
        return extractInfoFromServerReferenceId;
    },
    omitUnusedArgs: function() {
        return omitUnusedArgs;
    }
});
function extractInfoFromServerReferenceId(id) {
    const infoByte = parseInt(id.slice(0, 2), 16);
    const typeBit = infoByte >> 7 & 0x1;
    const argMask = infoByte >> 1 & 0x3f;
    const restArgs = infoByte & 0x1;
    const usedArgs = Array(6);
    for(let index = 0; index < 6; index++){
        const bitPosition = 5 - index;
        const bit = argMask >> bitPosition & 0x1;
        usedArgs[index] = bit === 1;
    }
    return {
        type: typeBit === 1 ? 'use-cache' : 'server-action',
        usedArgs: usedArgs,
        hasRestArgs: restArgs === 1
    };
}
function omitUnusedArgs(args, info) {
    const filteredArgs = new Array(args.length);
    for(let index = 0; index < args.length; index++){
        if (index < 6 && info.usedArgs[index] || // This assumes that the server reference info byte has the restArgs bit
        // set to 1 if there are more than 6 args.
        index >= 6 && info.hasRestArgs) {
            filteredArgs[index] = args[index];
        }
    }
    return filteredArgs;
} //# sourceMappingURL=server-reference-info.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/action-revalidation-kind.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ActionDidNotRevalidate: null,
    ActionDidRevalidateDynamicOnly: null,
    ActionDidRevalidateStaticAndDynamic: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ActionDidNotRevalidate: function() {
        return ActionDidNotRevalidate;
    },
    ActionDidRevalidateDynamicOnly: function() {
        return ActionDidRevalidateDynamicOnly;
    },
    ActionDidRevalidateStaticAndDynamic: function() {
        return ActionDidRevalidateStaticAndDynamic;
    }
});
const ActionDidNotRevalidate = 0;
const ActionDidRevalidateStaticAndDynamic = 1;
const ActionDidRevalidateDynamicOnly = 2; //# sourceMappingURL=action-revalidation-kind.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    AppRouterContext: null,
    GlobalLayoutRouterContext: null,
    LayoutRouterContext: null,
    MissingSlotContext: null,
    TemplateContext: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    AppRouterContext: function() {
        return AppRouterContext;
    },
    GlobalLayoutRouterContext: function() {
        return GlobalLayoutRouterContext;
    },
    LayoutRouterContext: function() {
        return LayoutRouterContext;
    },
    MissingSlotContext: function() {
        return MissingSlotContext;
    },
    TemplateContext: function() {
        return TemplateContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const AppRouterContext = _react.default.createContext(null);
const LayoutRouterContext = _react.default.createContext(null);
const GlobalLayoutRouterContext = _react.default.createContext(null);
const TemplateContext = _react.default.createContext(null);
if ("TURBOPACK compile-time truthy", 1) {
    AppRouterContext.displayName = 'AppRouterContext';
    LayoutRouterContext.displayName = 'LayoutRouterContext';
    GlobalLayoutRouterContext.displayName = 'GlobalLayoutRouterContext';
    TemplateContext.displayName = 'TemplateContext';
}
const MissingSlotContext = _react.default.createContext(new Set()); //# sourceMappingURL=app-router-context.shared-runtime.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/server-inserted-html.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ServerInsertedHTMLContext: null,
    useServerInsertedHTML: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ServerInsertedHTMLContext: function() {
        return ServerInsertedHTMLContext;
    },
    useServerInsertedHTML: function() {
        return useServerInsertedHTML;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const ServerInsertedHTMLContext = /*#__PURE__*/ _react.default.createContext(null);
function useServerInsertedHTML(callback) {
    const addInsertedServerHTMLCallback = (0, _react.useContext)(ServerInsertedHTMLContext);
    // Should have no effects on client where there's no flush effects provider
    if (addInsertedServerHTMLCallback) {
        addInsertedServerHTMLCallback(callback);
    }
} //# sourceMappingURL=server-inserted-html.shared-runtime.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "warnOnce", {
    enumerable: true,
    get: function() {
        return warnOnce;
    }
});
let warnOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const warnings = new Set();
    warnOnce = (msg)=>{
        if (!warnings.has(msg)) {
            console.warn(msg);
        }
        warnings.add(msg);
    };
} //# sourceMappingURL=warn-once.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/format-webpack-messages.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
MIT License

Copyright (c) 2015-present, Facebook, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return formatWebpackMessages;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _stripansi = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/strip-ansi/index.js [app-client] (ecmascript)"));
// This file is based on https://github.com/facebook/create-react-app/blob/7b1a32be6ec9f99a6c9a3c66813f3ac09c4736b9/packages/react-dev-utils/formatWebpackMessages.js
// It's been edited to remove chalk and CRA-specific logic
const friendlySyntaxErrorLabel = 'Syntax error:';
const WEBPACK_BREAKING_CHANGE_POLYFILLS = '\n\nBREAKING CHANGE: webpack < 5 used to include polyfills for node.js core modules by default.';
function isLikelyASyntaxError(message) {
    return (0, _stripansi.default)(message).includes(friendlySyntaxErrorLabel);
}
let hadMissingSassError = false;
// Cleans up webpack error messages.
function formatMessage(message, verbose, importTraceNote) {
    // TODO: Replace this once webpack 5 is stable
    if (typeof message === 'object' && message.message) {
        const filteredModuleTrace = message.moduleTrace && message.moduleTrace.filter((trace)=>!/next-(middleware|client-pages|route|edge-function)-loader\.js/.test(trace.originName));
        let body = message.message;
        const breakingChangeIndex = body.indexOf(WEBPACK_BREAKING_CHANGE_POLYFILLS);
        if (breakingChangeIndex >= 0) {
            body = body.slice(0, breakingChangeIndex);
        }
        // TODO: Rspack currently doesn't populate moduleName correctly in some cases,
        // fall back to moduleIdentifier as a workaround
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_RSPACK && !message.moduleName && !message.file && message.moduleIdentifier) {
            const parts = message.moduleIdentifier.split('!');
            message.moduleName = parts[parts.length - 1];
        }
        message = (message.moduleName ? (0, _stripansi.default)(message.moduleName) + '\n' : '') + (message.file ? (0, _stripansi.default)(message.file) + '\n' : '') + body + (message.details && verbose ? '\n' + message.details : '') + (filteredModuleTrace && filteredModuleTrace.length ? (importTraceNote || '\n\nImport trace for requested module:') + filteredModuleTrace.map((trace)=>`\n${trace.moduleName}`).join('') : '') + (message.stack && verbose ? '\n' + message.stack : '');
    }
    let lines = message.split('\n');
    // Strip Webpack-added headers off errors/warnings
    // https://github.com/webpack/webpack/blob/master/lib/ModuleError.js
    lines = lines.filter((line)=>!/Module [A-z ]+\(from/.test(line));
    // Transform parsing error into syntax error
    // TODO: move this to our ESLint formatter?
    lines = lines.map((line)=>{
        const parsingError = /Line (\d+):(?:(\d+):)?\s*Parsing error: (.+)$/.exec(line);
        if (!parsingError) {
            return line;
        }
        const [, errorLine, errorColumn, errorMessage] = parsingError;
        return `${friendlySyntaxErrorLabel} ${errorMessage} (${errorLine}:${errorColumn})`;
    });
    message = lines.join('\n');
    // Smoosh syntax errors (commonly found in CSS)
    message = message.replace(/SyntaxError\s+\((\d+):(\d+)\)\s*(.+?)\n/g, `${friendlySyntaxErrorLabel} $3 ($1:$2)\n`);
    // Clean up export errors
    message = message.replace(/^.*export '(.+?)' was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$2'.`);
    message = message.replace(/^.*export 'default' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$2' does not contain a default export (imported as '$1').`);
    message = message.replace(/^.*export '(.+?)' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$3' (imported as '$2').`);
    lines = message.split('\n');
    // Remove leading newline
    if (lines.length > 2 && lines[1].trim() === '') {
        lines.splice(1, 1);
    }
    // Cleans up verbose "module not found" messages for files and packages.
    if (lines[1] && lines[1].startsWith('Module not found: ')) {
        lines = [
            lines[0],
            lines[1].replace('Error: ', '').replace('Module not found: Cannot find file:', 'Cannot find file:'),
            ...lines.slice(2)
        ];
    }
    // Add helpful message for users trying to use Sass for the first time
    if (lines[1] && lines[1].match(/Cannot find module.+sass/)) {
        // ./file.module.scss (<<loader info>>) => ./file.module.scss
        const firstLine = lines[0].split('!');
        lines[0] = firstLine[firstLine.length - 1];
        lines[1] = "To use Next.js' built-in Sass support, you first need to install `sass`.\n";
        lines[1] += 'Run `npm i sass` or `yarn add sass` inside your workspace.\n';
        lines[1] += '\nLearn more: https://nextjs.org/docs/messages/install-sass';
        // dispose of unhelpful stack trace
        lines = lines.slice(0, 2);
        hadMissingSassError = true;
    } else if (hadMissingSassError && message.match(/(sass-loader|resolve-url-loader: CSS error)/)) {
        // dispose of unhelpful stack trace following missing sass module
        lines = [];
    }
    if (!verbose) {
        message = lines.join('\n');
        // Internal stacks are generally useless so we strip them... with the
        // exception of stacks containing `webpack:` because they're normally
        // from user code generated by Webpack. For more information see
        // https://github.com/facebook/create-react-app/pull/1050
        message = message.replace(/^\s*at\s((?!webpack:).)*:\d+:\d+[\s)]*(\n|$)/gm, '') // at ... ...:x:y
        ;
        message = message.replace(/^\s*at\s<anonymous>(\n|$)/gm, '') // at <anonymous>
        ;
        message = message.replace(/File was processed with these loaders:\n(.+[\\/](next[\\/]dist[\\/].+|@next[\\/]react-refresh-utils[\\/]loader)\.js\n)*You may need an additional loader to handle the result of these loaders.\n/g, '');
        lines = message.split('\n');
    }
    // Remove duplicated newlines
    lines = lines.filter((line, index, arr)=>index === 0 || line.trim() !== '' || line.trim() !== arr[index - 1].trim());
    // Reassemble the message
    message = lines.join('\n');
    return message.trim();
}
function formatWebpackMessages(json, verbose) {
    const formattedErrors = json.errors.map((message)=>{
        const isUnknownNextFontError = message.message.includes('An error occurred in `next/font`.');
        return formatMessage(message, isUnknownNextFontError || verbose);
    });
    const formattedWarnings = json.warnings.map((message)=>{
        return formatMessage(message, verbose);
    });
    // Reorder errors to put the most relevant ones first.
    let reactServerComponentsError = -1;
    for(let i = 0; i < formattedErrors.length; i++){
        const error = formattedErrors[i];
        if (error.includes('ReactServerComponentsError')) {
            reactServerComponentsError = i;
            break;
        }
    }
    // Move the reactServerComponentsError to the top if it exists
    if (reactServerComponentsError !== -1) {
        const error = formattedErrors.splice(reactServerComponentsError, 1);
        formattedErrors.unshift(error[0]);
    }
    const result = {
        ...json,
        errors: formattedErrors,
        warnings: formattedWarnings
    };
    if (!verbose && result.errors.some(isLikelyASyntaxError)) {
        // If there are any syntax errors, show just them.
        result.errors = result.errors.filter(isLikelyASyntaxError);
        result.warnings = [];
    }
    return result;
} //# sourceMappingURL=format-webpack-messages.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "MISSING_ROOT_TAGS_ERROR", {
    enumerable: true,
    get: function() {
        return MISSING_ROOT_TAGS_ERROR;
    }
});
const MISSING_ROOT_TAGS_ERROR = 'NEXT_MISSING_ROOT_TAGS';
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=constants.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/normalized-asset-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "normalizedAssetPrefix", {
    enumerable: true,
    get: function() {
        return normalizedAssetPrefix;
    }
});
function normalizedAssetPrefix(assetPrefix) {
    // remove all leading slashes and trailing slashes
    const escapedAssetPrefix = assetPrefix?.replace(/^\/+|\/+$/g, '') || false;
    // if an assetPrefix was '/', we return empty string
    // because it could be an unnecessary trailing slash
    if (!escapedAssetPrefix) {
        return '';
    }
    if (URL.canParse(escapedAssetPrefix)) {
        const url = new URL(escapedAssetPrefix).toString();
        return url.endsWith('/') ? url.slice(0, -1) : url;
    }
    // assuming assetPrefix here is a pathname-style,
    // restore the leading slash
    return `/${escapedAssetPrefix}`;
} //# sourceMappingURL=normalized-asset-prefix.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    getProperError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * Checks whether the given value is a NextError.
 * This can be used to print a more detailed error message with properties like `code` & `digest`.
 */ default: function() {
        return isError;
    },
    getProperError: function() {
        return getProperError;
    }
});
const _isplainobject = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)");
/**
 * This is a safe stringify function that handles circular references.
 * We're using a simpler version here to avoid introducing
 * the dependency `safe-stable-stringify` into production bundle.
 *
 * This helper is used both in development and production.
 */ function safeStringifyLite(obj) {
    const seen = new WeakSet();
    return JSON.stringify(obj, (_key, value)=>{
        // If value is an object and already seen, replace with "[Circular]"
        if (typeof value === 'object' && value !== null) {
            if (seen.has(value)) {
                return '[Circular]';
            }
            seen.add(value);
        }
        return value;
    });
}
function isError(err) {
    return typeof err === 'object' && err !== null && 'name' in err && 'message' in err;
}
function getProperError(err) {
    if (isError(err)) {
        return err;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // provide better error for case where `throw undefined`
        // is called in development
        if (typeof err === 'undefined') {
            return Object.defineProperty(new Error('An undefined error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E98",
                enumerable: false,
                configurable: true
            });
        }
        if (err === null) {
            return Object.defineProperty(new Error('A null error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E336",
                enumerable: false,
                configurable: true
            });
        }
    }
    return Object.defineProperty(new Error((0, _isplainobject.isPlainObject)(err) ? safeStringifyLite(err) : err + ''), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
} //# sourceMappingURL=is-error.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/require-instrumentation-client.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * This module imports the client instrumentation hook from the project root.
 *
 * The `private-next-instrumentation-client` module is automatically aliased to
 * the `instrumentation-client.ts` file in the project root by webpack or turbopack.
 */ "use strict";
if ("TURBOPACK compile-time truthy", 1) {
    const measureName = 'Client Instrumentation Hook';
    const startTime = performance.now();
    // eslint-disable-next-line @next/internal/typechecked-require -- Not a module.
    module.exports = {};
    const endTime = performance.now();
    const duration = endTime - startTime;
    // Using 16ms threshold as it represents one frame (1000ms/60fps)
    // This helps identify if the instrumentation hook initialization
    // could potentially cause frame drops during development.
    const THRESHOLD = 16;
    if (duration > THRESHOLD) {
        console.log(`[${measureName}] Slow execution detected: ${duration.toFixed(0)}ms (Note: Code download overhead is not included in this measurement)`);
    }
} else //TURBOPACK unreachable
;
 //# sourceMappingURL=require-instrumentation-client.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    METADATA_BOUNDARY_NAME: null,
    OUTLET_BOUNDARY_NAME: null,
    ROOT_LAYOUT_BOUNDARY_NAME: null,
    VIEWPORT_BOUNDARY_NAME: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    METADATA_BOUNDARY_NAME: function() {
        return METADATA_BOUNDARY_NAME;
    },
    OUTLET_BOUNDARY_NAME: function() {
        return OUTLET_BOUNDARY_NAME;
    },
    ROOT_LAYOUT_BOUNDARY_NAME: function() {
        return ROOT_LAYOUT_BOUNDARY_NAME;
    },
    VIEWPORT_BOUNDARY_NAME: function() {
        return VIEWPORT_BOUNDARY_NAME;
    }
});
const METADATA_BOUNDARY_NAME = '__next_metadata_boundary__';
const VIEWPORT_BOUNDARY_NAME = '__next_viewport_boundary__';
const OUTLET_BOUNDARY_NAME = '__next_outlet_boundary__';
const ROOT_LAYOUT_BOUNDARY_NAME = '__next_root_layout_boundary__'; //# sourceMappingURL=boundary-constants.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    atLeastOneTask: null,
    scheduleImmediate: null,
    scheduleOnNextTick: null,
    waitAtLeastOneReactRenderTask: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    atLeastOneTask: function() {
        return atLeastOneTask;
    },
    scheduleImmediate: function() {
        return scheduleImmediate;
    },
    scheduleOnNextTick: function() {
        return scheduleOnNextTick;
    },
    waitAtLeastOneReactRenderTask: function() {
        return waitAtLeastOneReactRenderTask;
    }
});
const scheduleOnNextTick = (cb)=>{
    // We use Promise.resolve().then() here so that the operation is scheduled at
    // the end of the promise job queue, we then add it to the next process tick
    // to ensure it's evaluated afterwards.
    //
    // This was inspired by the implementation of the DataLoader interface: https://github.com/graphql/dataloader/blob/d336bd15282664e0be4b4a657cb796f09bafbc6b/src/index.js#L213-L255
    //
    Promise.resolve().then(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].nextTick(cb);
        }
    });
};
const scheduleImmediate = (cb)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        setImmediate(cb);
    }
};
function atLeastOneTask() {
    return new Promise((resolve)=>scheduleImmediate(resolve));
}
function waitAtLeastOneReactRenderTask() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return new Promise((r)=>setImmediate(r));
    }
} //# sourceMappingURL=scheduler.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/framework/boundary-components.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    MetadataBoundary: null,
    OutletBoundary: null,
    RootLayoutBoundary: null,
    ViewportBoundary: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    MetadataBoundary: function() {
        return MetadataBoundary;
    },
    OutletBoundary: function() {
        return OutletBoundary;
    },
    RootLayoutBoundary: function() {
        return RootLayoutBoundary;
    },
    ViewportBoundary: function() {
        return ViewportBoundary;
    }
});
const _boundaryconstants = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
// We use a namespace object to allow us to recover the name of the function
// at runtime even when production bundling/minification is used.
const NameSpace = {
    [_boundaryconstants.METADATA_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.VIEWPORT_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.OUTLET_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME]: function({ children }) {
        return children;
    }
};
const MetadataBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.METADATA_BOUNDARY_NAME.slice(0)];
const ViewportBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.VIEWPORT_BOUNDARY_NAME.slice(0)];
const OutletBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.OUTLET_BOUNDARY_NAME.slice(0)];
const RootLayoutBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]; //# sourceMappingURL=boundary-components.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ACTION_SUFFIX: null,
    APP_DIR_ALIAS: null,
    CACHE_ONE_YEAR: null,
    DOT_NEXT_ALIAS: null,
    ESLINT_DEFAULT_DIRS: null,
    GSP_NO_RETURNED_VALUE: null,
    GSSP_COMPONENT_MEMBER_ERROR: null,
    GSSP_NO_RETURNED_VALUE: null,
    HTML_CONTENT_TYPE_HEADER: null,
    INFINITE_CACHE: null,
    INSTRUMENTATION_HOOK_FILENAME: null,
    JSON_CONTENT_TYPE_HEADER: null,
    MATCHED_PATH_HEADER: null,
    MIDDLEWARE_FILENAME: null,
    MIDDLEWARE_LOCATION_REGEXP: null,
    NEXT_BODY_SUFFIX: null,
    NEXT_CACHE_IMPLICIT_TAG_ID: null,
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: null,
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: null,
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: null,
    NEXT_CACHE_TAGS_HEADER: null,
    NEXT_CACHE_TAG_MAX_ITEMS: null,
    NEXT_CACHE_TAG_MAX_LENGTH: null,
    NEXT_DATA_SUFFIX: null,
    NEXT_INTERCEPTION_MARKER_PREFIX: null,
    NEXT_META_SUFFIX: null,
    NEXT_QUERY_PARAM_PREFIX: null,
    NEXT_RESUME_HEADER: null,
    NON_STANDARD_NODE_ENV: null,
    PAGES_DIR_ALIAS: null,
    PRERENDER_REVALIDATE_HEADER: null,
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: null,
    PROXY_FILENAME: null,
    PROXY_LOCATION_REGEXP: null,
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: null,
    ROOT_DIR_ALIAS: null,
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: null,
    RSC_ACTION_ENCRYPTION_ALIAS: null,
    RSC_ACTION_PROXY_ALIAS: null,
    RSC_ACTION_VALIDATE_ALIAS: null,
    RSC_CACHE_WRAPPER_ALIAS: null,
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: null,
    RSC_MOD_REF_PROXY_ALIAS: null,
    RSC_SEGMENTS_DIR_SUFFIX: null,
    RSC_SEGMENT_SUFFIX: null,
    RSC_SUFFIX: null,
    SERVER_PROPS_EXPORT_ERROR: null,
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: null,
    SERVER_PROPS_SSG_CONFLICT: null,
    SERVER_RUNTIME: null,
    SSG_FALLBACK_EXPORT_ERROR: null,
    SSG_GET_INITIAL_PROPS_CONFLICT: null,
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: null,
    TEXT_PLAIN_CONTENT_TYPE_HEADER: null,
    UNSTABLE_REVALIDATE_RENAME_ERROR: null,
    WEBPACK_LAYERS: null,
    WEBPACK_RESOURCE_QUERIES: null,
    WEB_SOCKET_MAX_RECONNECTIONS: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ACTION_SUFFIX: function() {
        return ACTION_SUFFIX;
    },
    APP_DIR_ALIAS: function() {
        return APP_DIR_ALIAS;
    },
    CACHE_ONE_YEAR: function() {
        return CACHE_ONE_YEAR;
    },
    DOT_NEXT_ALIAS: function() {
        return DOT_NEXT_ALIAS;
    },
    ESLINT_DEFAULT_DIRS: function() {
        return ESLINT_DEFAULT_DIRS;
    },
    GSP_NO_RETURNED_VALUE: function() {
        return GSP_NO_RETURNED_VALUE;
    },
    GSSP_COMPONENT_MEMBER_ERROR: function() {
        return GSSP_COMPONENT_MEMBER_ERROR;
    },
    GSSP_NO_RETURNED_VALUE: function() {
        return GSSP_NO_RETURNED_VALUE;
    },
    HTML_CONTENT_TYPE_HEADER: function() {
        return HTML_CONTENT_TYPE_HEADER;
    },
    INFINITE_CACHE: function() {
        return INFINITE_CACHE;
    },
    INSTRUMENTATION_HOOK_FILENAME: function() {
        return INSTRUMENTATION_HOOK_FILENAME;
    },
    JSON_CONTENT_TYPE_HEADER: function() {
        return JSON_CONTENT_TYPE_HEADER;
    },
    MATCHED_PATH_HEADER: function() {
        return MATCHED_PATH_HEADER;
    },
    MIDDLEWARE_FILENAME: function() {
        return MIDDLEWARE_FILENAME;
    },
    MIDDLEWARE_LOCATION_REGEXP: function() {
        return MIDDLEWARE_LOCATION_REGEXP;
    },
    NEXT_BODY_SUFFIX: function() {
        return NEXT_BODY_SUFFIX;
    },
    NEXT_CACHE_IMPLICIT_TAG_ID: function() {
        return NEXT_CACHE_IMPLICIT_TAG_ID;
    },
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: function() {
        return NEXT_CACHE_REVALIDATED_TAGS_HEADER;
    },
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: function() {
        return NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER;
    },
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_SOFT_TAG_MAX_LENGTH;
    },
    NEXT_CACHE_TAGS_HEADER: function() {
        return NEXT_CACHE_TAGS_HEADER;
    },
    NEXT_CACHE_TAG_MAX_ITEMS: function() {
        return NEXT_CACHE_TAG_MAX_ITEMS;
    },
    NEXT_CACHE_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_TAG_MAX_LENGTH;
    },
    NEXT_DATA_SUFFIX: function() {
        return NEXT_DATA_SUFFIX;
    },
    NEXT_INTERCEPTION_MARKER_PREFIX: function() {
        return NEXT_INTERCEPTION_MARKER_PREFIX;
    },
    NEXT_META_SUFFIX: function() {
        return NEXT_META_SUFFIX;
    },
    NEXT_QUERY_PARAM_PREFIX: function() {
        return NEXT_QUERY_PARAM_PREFIX;
    },
    NEXT_RESUME_HEADER: function() {
        return NEXT_RESUME_HEADER;
    },
    NON_STANDARD_NODE_ENV: function() {
        return NON_STANDARD_NODE_ENV;
    },
    PAGES_DIR_ALIAS: function() {
        return PAGES_DIR_ALIAS;
    },
    PRERENDER_REVALIDATE_HEADER: function() {
        return PRERENDER_REVALIDATE_HEADER;
    },
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: function() {
        return PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER;
    },
    PROXY_FILENAME: function() {
        return PROXY_FILENAME;
    },
    PROXY_LOCATION_REGEXP: function() {
        return PROXY_LOCATION_REGEXP;
    },
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: function() {
        return PUBLIC_DIR_MIDDLEWARE_CONFLICT;
    },
    ROOT_DIR_ALIAS: function() {
        return ROOT_DIR_ALIAS;
    },
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: function() {
        return RSC_ACTION_CLIENT_WRAPPER_ALIAS;
    },
    RSC_ACTION_ENCRYPTION_ALIAS: function() {
        return RSC_ACTION_ENCRYPTION_ALIAS;
    },
    RSC_ACTION_PROXY_ALIAS: function() {
        return RSC_ACTION_PROXY_ALIAS;
    },
    RSC_ACTION_VALIDATE_ALIAS: function() {
        return RSC_ACTION_VALIDATE_ALIAS;
    },
    RSC_CACHE_WRAPPER_ALIAS: function() {
        return RSC_CACHE_WRAPPER_ALIAS;
    },
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: function() {
        return RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS;
    },
    RSC_MOD_REF_PROXY_ALIAS: function() {
        return RSC_MOD_REF_PROXY_ALIAS;
    },
    RSC_SEGMENTS_DIR_SUFFIX: function() {
        return RSC_SEGMENTS_DIR_SUFFIX;
    },
    RSC_SEGMENT_SUFFIX: function() {
        return RSC_SEGMENT_SUFFIX;
    },
    RSC_SUFFIX: function() {
        return RSC_SUFFIX;
    },
    SERVER_PROPS_EXPORT_ERROR: function() {
        return SERVER_PROPS_EXPORT_ERROR;
    },
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: function() {
        return SERVER_PROPS_GET_INIT_PROPS_CONFLICT;
    },
    SERVER_PROPS_SSG_CONFLICT: function() {
        return SERVER_PROPS_SSG_CONFLICT;
    },
    SERVER_RUNTIME: function() {
        return SERVER_RUNTIME;
    },
    SSG_FALLBACK_EXPORT_ERROR: function() {
        return SSG_FALLBACK_EXPORT_ERROR;
    },
    SSG_GET_INITIAL_PROPS_CONFLICT: function() {
        return SSG_GET_INITIAL_PROPS_CONFLICT;
    },
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: function() {
        return STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR;
    },
    TEXT_PLAIN_CONTENT_TYPE_HEADER: function() {
        return TEXT_PLAIN_CONTENT_TYPE_HEADER;
    },
    UNSTABLE_REVALIDATE_RENAME_ERROR: function() {
        return UNSTABLE_REVALIDATE_RENAME_ERROR;
    },
    WEBPACK_LAYERS: function() {
        return WEBPACK_LAYERS;
    },
    WEBPACK_RESOURCE_QUERIES: function() {
        return WEBPACK_RESOURCE_QUERIES;
    },
    WEB_SOCKET_MAX_RECONNECTIONS: function() {
        return WEB_SOCKET_MAX_RECONNECTIONS;
    }
});
const TEXT_PLAIN_CONTENT_TYPE_HEADER = 'text/plain';
const HTML_CONTENT_TYPE_HEADER = 'text/html; charset=utf-8';
const JSON_CONTENT_TYPE_HEADER = 'application/json; charset=utf-8';
const NEXT_QUERY_PARAM_PREFIX = 'nxtP';
const NEXT_INTERCEPTION_MARKER_PREFIX = 'nxtI';
const MATCHED_PATH_HEADER = 'x-matched-path';
const PRERENDER_REVALIDATE_HEADER = 'x-prerender-revalidate';
const PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER = 'x-prerender-revalidate-if-generated';
const RSC_SEGMENTS_DIR_SUFFIX = '.segments';
const RSC_SEGMENT_SUFFIX = '.segment.rsc';
const RSC_SUFFIX = '.rsc';
const ACTION_SUFFIX = '.action';
const NEXT_DATA_SUFFIX = '.json';
const NEXT_META_SUFFIX = '.meta';
const NEXT_BODY_SUFFIX = '.body';
const NEXT_CACHE_TAGS_HEADER = 'x-next-cache-tags';
const NEXT_CACHE_REVALIDATED_TAGS_HEADER = 'x-next-revalidated-tags';
const NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER = 'x-next-revalidate-tag-token';
const NEXT_RESUME_HEADER = 'next-resume';
const NEXT_CACHE_TAG_MAX_ITEMS = 128;
const NEXT_CACHE_TAG_MAX_LENGTH = 256;
const NEXT_CACHE_SOFT_TAG_MAX_LENGTH = 1024;
const NEXT_CACHE_IMPLICIT_TAG_ID = '_N_T_';
const CACHE_ONE_YEAR = 31536000;
const INFINITE_CACHE = 0xfffffffe;
const MIDDLEWARE_FILENAME = 'middleware';
const MIDDLEWARE_LOCATION_REGEXP = `(?:src/)?${MIDDLEWARE_FILENAME}`;
const PROXY_FILENAME = 'proxy';
const PROXY_LOCATION_REGEXP = `(?:src/)?${PROXY_FILENAME}`;
const INSTRUMENTATION_HOOK_FILENAME = 'instrumentation';
const PAGES_DIR_ALIAS = 'private-next-pages';
const DOT_NEXT_ALIAS = 'private-dot-next';
const ROOT_DIR_ALIAS = 'private-next-root-dir';
const APP_DIR_ALIAS = 'private-next-app-dir';
const RSC_MOD_REF_PROXY_ALIAS = 'private-next-rsc-mod-ref-proxy';
const RSC_ACTION_VALIDATE_ALIAS = 'private-next-rsc-action-validate';
const RSC_ACTION_PROXY_ALIAS = 'private-next-rsc-server-reference';
const RSC_CACHE_WRAPPER_ALIAS = 'private-next-rsc-cache-wrapper';
const RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS = 'private-next-rsc-track-dynamic-import';
const RSC_ACTION_ENCRYPTION_ALIAS = 'private-next-rsc-action-encryption';
const RSC_ACTION_CLIENT_WRAPPER_ALIAS = 'private-next-rsc-action-client-wrapper';
const PUBLIC_DIR_MIDDLEWARE_CONFLICT = `You can not have a '_next' folder inside of your public folder. This conflicts with the internal '/_next' route. https://nextjs.org/docs/messages/public-next-folder-conflict`;
const SSG_GET_INITIAL_PROPS_CONFLICT = `You can not use getInitialProps with getStaticProps. To use SSG, please remove your getInitialProps`;
const SERVER_PROPS_GET_INIT_PROPS_CONFLICT = `You can not use getInitialProps with getServerSideProps. Please remove getInitialProps.`;
const SERVER_PROPS_SSG_CONFLICT = `You can not use getStaticProps or getStaticPaths with getServerSideProps. To use SSG, please remove getServerSideProps`;
const STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR = `can not have getInitialProps/getServerSideProps, https://nextjs.org/docs/messages/404-get-initial-props`;
const SERVER_PROPS_EXPORT_ERROR = `pages with \`getServerSideProps\` can not be exported. See more info here: https://nextjs.org/docs/messages/gssp-export`;
const GSP_NO_RETURNED_VALUE = 'Your `getStaticProps` function did not return an object. Did you forget to add a `return`?';
const GSSP_NO_RETURNED_VALUE = 'Your `getServerSideProps` function did not return an object. Did you forget to add a `return`?';
const UNSTABLE_REVALIDATE_RENAME_ERROR = 'The `unstable_revalidate` property is available for general use.\n' + 'Please use `revalidate` instead.';
const GSSP_COMPONENT_MEMBER_ERROR = `can not be attached to a page's component and must be exported from the page. See more info here: https://nextjs.org/docs/messages/gssp-component-member`;
const NON_STANDARD_NODE_ENV = `You are using a non-standard "NODE_ENV" value in your environment. This creates inconsistencies in the project and is strongly advised against. Read more: https://nextjs.org/docs/messages/non-standard-node-env`;
const SSG_FALLBACK_EXPORT_ERROR = `Pages with \`fallback\` enabled in \`getStaticPaths\` can not be exported. See more info here: https://nextjs.org/docs/messages/ssg-fallback-true-export`;
const ESLINT_DEFAULT_DIRS = [
    'app',
    'pages',
    'components',
    'lib',
    'src'
];
const SERVER_RUNTIME = {
    edge: 'edge',
    experimentalEdge: 'experimental-edge',
    nodejs: 'nodejs'
};
const WEB_SOCKET_MAX_RECONNECTIONS = 12;
/**
 * The names of the webpack layers. These layers are the primitives for the
 * webpack chunks.
 */ const WEBPACK_LAYERS_NAMES = {
    /**
   * The layer for the shared code between the client and server bundles.
   */ shared: 'shared',
    /**
   * The layer for server-only runtime and picking up `react-server` export conditions.
   * Including app router RSC pages and app router custom routes and metadata routes.
   */ reactServerComponents: 'rsc',
    /**
   * Server Side Rendering layer for app (ssr).
   */ serverSideRendering: 'ssr',
    /**
   * The browser client bundle layer for actions.
   */ actionBrowser: 'action-browser',
    /**
   * The Node.js bundle layer for the API routes.
   */ apiNode: 'api-node',
    /**
   * The Edge Lite bundle layer for the API routes.
   */ apiEdge: 'api-edge',
    /**
   * The layer for the middleware code.
   */ middleware: 'middleware',
    /**
   * The layer for the instrumentation hooks.
   */ instrument: 'instrument',
    /**
   * The layer for assets on the edge.
   */ edgeAsset: 'edge-asset',
    /**
   * The browser client bundle layer for App directory.
   */ appPagesBrowser: 'app-pages-browser',
    /**
   * The browser client bundle layer for Pages directory.
   */ pagesDirBrowser: 'pages-dir-browser',
    /**
   * The Edge Lite bundle layer for Pages directory.
   */ pagesDirEdge: 'pages-dir-edge',
    /**
   * The Node.js bundle layer for Pages directory.
   */ pagesDirNode: 'pages-dir-node'
};
const WEBPACK_LAYERS = {
    ...WEBPACK_LAYERS_NAMES,
    GROUP: {
        builtinReact: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ],
        serverOnly: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        neutralTarget: [
            // pages api
            WEBPACK_LAYERS_NAMES.apiNode,
            WEBPACK_LAYERS_NAMES.apiEdge
        ],
        clientOnly: [
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser
        ],
        bundled: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.shared,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        appPages: [
            // app router pages and layouts
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ]
    }
};
const WEBPACK_RESOURCE_QUERIES = {
    edgeSSREntry: '__next_edge_ssr_entry__',
    metadata: '__next_metadata__',
    metadataRoute: '__next_metadata_route__',
    metadataImageMeta: '__next_metadata_image_meta__'
}; //# sourceMappingURL=constants.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    coerceError: null,
    decorateDevError: null,
    getOwnerStack: null,
    setOwnerStack: null,
    setOwnerStackIfAvailable: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    coerceError: function() {
        return coerceError;
    },
    decorateDevError: function() {
        return decorateDevError;
    },
    getOwnerStack: function() {
        return getOwnerStack;
    },
    setOwnerStack: function() {
        return setOwnerStack;
    },
    setOwnerStackIfAvailable: function() {
        return setOwnerStackIfAvailable;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const ownerStacks = new WeakMap();
function getOwnerStack(error) {
    return ownerStacks.get(error);
}
function setOwnerStack(error, stack) {
    ownerStacks.set(error, stack);
}
function coerceError(value) {
    return (0, _iserror.default)(value) ? value : Object.defineProperty(new Error('' + value), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
function setOwnerStackIfAvailable(error) {
    // React 18 and prod does not have `captureOwnerStack`
    if ('captureOwnerStack' in _react.default) {
        setOwnerStack(error, _react.default.captureOwnerStack());
    }
}
function decorateDevError(thrownValue) {
    const error = coerceError(thrownValue);
    setOwnerStackIfAvailable(error);
    return error;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=stitched-error.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// To distinguish from React error.digest, we use a different symbol here to determine if the error is from console.error or unhandled promise rejection.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    createConsoleError: null,
    isConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    createConsoleError: function() {
        return createConsoleError;
    },
    isConsoleError: function() {
        return isConsoleError;
    }
});
const digestSym = Symbol.for('next.console.error.digest');
function createConsoleError(message, environmentName) {
    const error = typeof message === 'string' ? Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    }) : message;
    error[digestSym] = 'NEXT_CONSOLE_ERROR';
    if (environmentName && !error.environmentName) {
        error.environmentName = environmentName;
    }
    return error;
}
const isConsoleError = (error)=>{
    return error && error[digestSym] === 'NEXT_CONSOLE_ERROR';
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=console-error.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getIsTerminalLoggingEnabled: null,
    getTerminalLoggingConfig: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getIsTerminalLoggingEnabled: function() {
        return getIsTerminalLoggingEnabled;
    },
    getTerminalLoggingConfig: function() {
        return getTerminalLoggingConfig;
    }
});
function getTerminalLoggingConfig() {
    try {
        return JSON.parse(("TURBOPACK compile-time value", "false") || 'false');
    } catch  {
        return false;
    }
}
function getIsTerminalLoggingEnabled() {
    const config = getTerminalLoggingConfig();
    return Boolean(config);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=terminal-logging-config.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    UNDEFINED_MARKER: null,
    patchConsoleMethod: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    UNDEFINED_MARKER: function() {
        return UNDEFINED_MARKER;
    },
    patchConsoleMethod: function() {
        return patchConsoleMethod;
    }
});
const UNDEFINED_MARKER = '__next_tagged_undefined';
function patchConsoleMethod(methodName, wrapper) {
    const descriptor = Object.getOwnPropertyDescriptor(console, methodName);
    if (descriptor && (descriptor.configurable || descriptor.writable) && typeof descriptor.value === 'function') {
        const originalMethod = descriptor.value;
        const originalName = Object.getOwnPropertyDescriptor(originalMethod, 'name');
        const wrapperMethod = function(...args) {
            wrapper(methodName, ...args);
            originalMethod.apply(this, args);
        };
        if (originalName) {
            Object.defineProperty(wrapperMethod, 'name', originalName);
        }
        Object.defineProperty(console, methodName, {
            value: wrapperMethod
        });
        return ()=>{
            Object.defineProperty(console, methodName, {
                value: originalMethod,
                writable: descriptor.writable,
                configurable: descriptor.configurable
            });
        };
    }
    return ()=>{};
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-shared.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    logStringify: null,
    preLogSerializationClone: null,
    safeStringifyWithDepth: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    logStringify: function() {
        return logStringify;
    },
    preLogSerializationClone: function() {
        return preLogSerializationClone;
    },
    safeStringifyWithDepth: function() {
        return safeStringifyWithDepth;
    }
});
const _safestablestringify = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/safe-stable-stringify/index.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const terminalLoggingConfig = (0, _terminalloggingconfig.getTerminalLoggingConfig)();
const PROMISE_MARKER = 'Promise {}';
const UNAVAILABLE_MARKER = '[Unable to view]';
const maximumDepth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.depthLimit ? terminalLoggingConfig.depthLimit : 5;
const maximumBreadth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.edgeLimit ? terminalLoggingConfig.edgeLimit : 100;
const safeStringifyWithDepth = (0, _safestablestringify.configure)({
    maximumDepth,
    maximumBreadth
});
function preLogSerializationClone(value, seen = new WeakMap()) {
    if (value === undefined) return _forwardlogsshared.UNDEFINED_MARKER;
    if (value === null || typeof value !== 'object') return value;
    if (seen.has(value)) return seen.get(value);
    try {
        Object.keys(value);
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    try {
        if (typeof value.then === 'function') return PROMISE_MARKER;
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    if (Array.isArray(value)) {
        const out = [];
        seen.set(value, out);
        for (const item of value){
            try {
                out.push(preLogSerializationClone(item, seen));
            } catch  {
                out.push(UNAVAILABLE_MARKER);
            }
        }
        return out;
    }
    const proto = Object.getPrototypeOf(value);
    if (proto === Object.prototype || proto === null) {
        const out = {};
        seen.set(value, out);
        for (const key of Object.keys(value)){
            try {
                out[key] = preLogSerializationClone(value[key], seen);
            } catch  {
                out[key] = UNAVAILABLE_MARKER;
            }
        }
        return out;
    }
    return Object.prototype.toString.call(value);
}
const logStringify = (data)=>{
    try {
        const result = safeStringifyWithDepth(data);
        return result ?? `"${UNAVAILABLE_MARKER}"`;
    } catch  {
        return `"${UNAVAILABLE_MARKER}"`;
    }
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-utils.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    forwardErrorLog: null,
    forwardUnhandledError: null,
    initializeDebugLogForwarding: null,
    logQueue: null,
    logUnhandledRejection: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    forwardErrorLog: function() {
        return forwardErrorLog;
    },
    forwardUnhandledError: function() {
        return forwardUnhandledError;
    },
    initializeDebugLogForwarding: function() {
        return initializeDebugLogForwarding;
    },
    logQueue: function() {
        return logQueue;
    },
    logUnhandledRejection: function() {
        return logUnhandledRejection;
    }
});
const _stitchederror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _errorsource = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const _forwardlogsutils = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)");
// Client-side file logger for browser logs
class ClientFileLogger {
    formatTimestamp() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const milliseconds = now.getMilliseconds().toString().padStart(3, '0');
        return `${hours}:${minutes}:${seconds}.${milliseconds}`;
    }
    log(level, args) {
        if (isReactServerReplayedLog(args)) {
            return;
        }
        // Format the args into a message string
        const message = args.map((arg)=>{
            if (typeof arg === 'string') return arg;
            if (typeof arg === 'number' || typeof arg === 'boolean') return String(arg);
            if (arg === null) return 'null';
            if (arg === undefined) return 'undefined';
            // Handle DOM nodes - only log the tag name to avoid React proxied elements
            if (arg instanceof Element) {
                return `<${arg.tagName.toLowerCase()}>`;
            }
            return (0, _forwardlogsutils.safeStringifyWithDepth)(arg);
        }).join(' ');
        const logEntry = {
            timestamp: this.formatTimestamp(),
            level: level.toUpperCase(),
            message
        };
        this.logEntries.push(logEntry);
        // Schedule flush when new log is added
        scheduleLogFlush();
    }
    getLogs() {
        return [
            ...this.logEntries
        ];
    }
    clear() {
        this.logEntries = [];
    }
    constructor(){
        this.logEntries = [];
    }
}
const clientFileLogger = new ClientFileLogger();
// Set up flush-based sending of client file logs
let logFlushTimeout = null;
let heartbeatInterval = null;
const scheduleLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
    }
    logFlushTimeout = setTimeout(()=>{
        sendClientFileLogs();
        logFlushTimeout = null;
    }, 100) // Send after 100ms (much faster with debouncing)
    ;
};
const cancelLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
        logFlushTimeout = null;
    }
};
const startHeartbeat = ()=>{
    if (heartbeatInterval) return;
    heartbeatInterval = setInterval(()=>{
        if (logQueue.socket && logQueue.socket.readyState === WebSocket.OPEN) {
            try {
                // Send a ping to keep the connection alive
                logQueue.socket.send(JSON.stringify({
                    event: 'ping'
                }));
            } catch (error) {
                // Connection might be closed, stop heartbeat
                stopHeartbeat();
            }
        } else {
            stopHeartbeat();
        }
    }, 5000) // Send ping every 5 seconds
    ;
};
const stopHeartbeat = ()=>{
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
};
const isTerminalLoggingEnabled = (0, _terminalloggingconfig.getIsTerminalLoggingEnabled)();
const methods = [
    'log',
    'info',
    'warn',
    'debug',
    'table',
    'assert',
    'dir',
    'dirxml',
    'group',
    'groupCollapsed',
    'groupEnd',
    'trace'
];
const afterThisFrame = (cb)=>{
    let timeout;
    const rafId = requestAnimationFrame(()=>{
        timeout = setTimeout(()=>{
            cb();
        });
    });
    return ()=>{
        cancelAnimationFrame(rafId);
        clearTimeout(timeout);
    };
};
let isPatched = false;
const serializeEntries = (entries)=>entries.map((clientEntry)=>{
        switch(clientEntry.kind){
            case 'any-logged-error':
            case 'console':
                {
                    return {
                        ...clientEntry,
                        args: clientEntry.args.map(stringifyUserArg)
                    };
                }
            case 'formatted-error':
                {
                    return clientEntry;
                }
            default:
                {
                    return null;
                }
        }
    });
// Function to send client file logs to server
const sendClientFileLogs = ()=>{
    if (!logQueue.socket || logQueue.socket.readyState !== WebSocket.OPEN) {
        return;
    }
    const logs = clientFileLogger.getLogs();
    if (logs.length === 0) {
        return;
    }
    try {
        const payload = JSON.stringify({
            event: 'client-file-logs',
            logs: logs
        });
        logQueue.socket.send(payload);
    } catch (error) {
        console.error(error);
    } finally{
        // Clear logs regardless of send success to prevent memory leaks
        clientFileLogger.clear();
    }
};
const logQueue = {
    entries: [],
    flushScheduled: false,
    cancelFlush: null,
    socket: null,
    sourceType: undefined,
    router: null,
    scheduleLogSend: (entry)=>{
        logQueue.entries.push(entry);
        if (logQueue.flushScheduled) {
            return;
        }
        // safe to deref and use in setTimeout closure since we cancel on new socket
        const socket = logQueue.socket;
        if (!socket) {
            return;
        }
        // we probably dont need this
        logQueue.flushScheduled = true;
        // non blocking log flush, runs at most once per frame
        logQueue.cancelFlush = afterThisFrame(()=>{
            logQueue.flushScheduled = false;
            // just incase
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    // needed for source mapping, we just assign the sourceType from the last error for the whole batch
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
                // Also send client file logs
                sendClientFileLogs();
            } catch  {
            // error (make sure u don't infinite loop)
            /* noop */ }
        });
    },
    onSocketReady: (socket)=>{
        // When MCP or terminal logging is enabled, we enable the socket connection,
        // otherwise it will not proceed.
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (socket.readyState !== WebSocket.OPEN) {
            // invariant
            return;
        }
        // incase an existing timeout was going to run with a stale socket
        logQueue.cancelFlush?.();
        logQueue.socket = socket;
        // Add socket event listeners to track connection state
        socket.addEventListener('close', ()=>{
            cancelLogFlush();
            stopHeartbeat();
        });
        // Only send terminal logs if enabled
        if (isTerminalLoggingEnabled) {
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
            } catch  {
            /** noop just incase */ }
        }
        // Always send client file logs when socket is ready
        sendClientFileLogs();
        // Start heartbeat to keep connection alive
        startHeartbeat();
    }
};
const stringifyUserArg = (arg)=>{
    if (arg.kind !== 'arg') {
        return arg;
    }
    return {
        ...arg,
        data: (0, _forwardlogsutils.logStringify)(arg.data)
    };
};
const createErrorArg = (error)=>{
    const stack = stackWithOwners(error);
    return {
        kind: 'formatted-error-arg',
        prefix: error.message ? `${error.name}: ${error.message}` : `${error.name}`,
        stack
    };
};
const createLogEntry = (level, args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log(level, args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    // do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
    // error capture stack trace maybe
    const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n') // this is probably ignored anyways
    ;
    const entry = {
        kind: 'console',
        consoleMethodStack: cleanStack ?? null,
        method: level,
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const forwardErrorLog = (args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log('error', args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    const errorObjects = args.filter((arg)=>arg instanceof Error);
    const first = errorObjects.at(0);
    if (first) {
        const source = (0, _errorsource.getErrorSource)(first);
        if (source) {
            logQueue.sourceType = source;
        }
    }
    /**
   * browser shows stack regardless of type of data passed to console.error, so we should do the same
   *
   * do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
   */ const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n');
    const entry = {
        kind: 'any-logged-error',
        method: 'error',
        consoleErrorStack: cleanStack ?? '',
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const createUncaughtErrorEntry = (errorName, errorMessage, fullStack)=>{
    const entry = {
        kind: 'formatted-error',
        prefix: `Uncaught ${errorName}: ${errorMessage}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const stackWithOwners = (error)=>{
    let ownerStack = '';
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    ownerStack = (0, _stitchederror.getOwnerStack)(error) || '';
    const stack = (error.stack || '') + ownerStack;
    return stack;
};
function logUnhandledRejection(reason) {
    // Always log to client file logger
    const message = reason instanceof Error ? `${reason.name}: ${reason.message}` : JSON.stringify(reason);
    clientFileLogger.log('error', [
        `unhandledRejection: ${message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    if (reason instanceof Error) {
        createUnhandledRejectionErrorEntry(reason, stackWithOwners(reason));
        return;
    }
    createUnhandledRejectionNonErrorEntry(reason);
}
const createUnhandledRejectionErrorEntry = (error, fullStack)=>{
    const source = (0, _errorsource.getErrorSource)(error);
    if (source) {
        logQueue.sourceType = source;
    }
    const entry = {
        kind: 'formatted-error',
        prefix: `⨯ unhandledRejection: ${error.name}: ${error.message}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const createUnhandledRejectionNonErrorEntry = (reason)=>{
    const entry = {
        kind: 'any-logged-error',
        // we can't access the stack since the event is dispatched async and creating an inline error would be meaningless
        consoleErrorStack: '',
        method: 'error',
        args: [
            {
                kind: 'arg',
                data: `⨯ unhandledRejection:`,
                isRejectionMessage: true
            },
            {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(reason)
            }
        ]
    };
    logQueue.scheduleLogSend(entry);
};
const isHMR = (args)=>{
    const firstArg = args[0];
    if (typeof firstArg !== 'string') {
        return false;
    }
    if (firstArg.startsWith('[Fast Refresh]')) {
        return true;
    }
    if (firstArg.startsWith('[HMR]')) {
        return true;
    }
    return false;
};
/**
 * Matches the format of logs arguments React replayed from the RSC.
 */ const isReactServerReplayedLog = (args)=>{
    if (args.length < 3) {
        return false;
    }
    const [format, styles, label] = args;
    if (typeof format !== 'string' || typeof styles !== 'string' || typeof label !== 'string') {
        return false;
    }
    return format.startsWith('%c%s%c') && styles.includes('background:');
};
function forwardUnhandledError(error) {
    // Always log to client file logger
    clientFileLogger.log('error', [
        `uncaughtError: ${error.name}: ${error.message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    createUncaughtErrorEntry(error.name, error.message, stackWithOwners(error));
}
const initializeDebugLogForwarding = (router)=>{
    // probably don't need this
    if (isPatched) {
        return;
    }
    // TODO(rob): why does this break rendering on server, important to know incase the same bug appears in browser
    if (typeof window === 'undefined') {
        return;
    }
    // better to be safe than sorry
    try {
        methods.forEach((method)=>(0, _forwardlogsshared.patchConsoleMethod)(method, (_, ...args)=>{
                if (isHMR(args)) {
                    return;
                }
                if (isReactServerReplayedLog(args)) {
                    return;
                }
                createLogEntry(method, args);
            }));
    } catch  {}
    logQueue.router = router;
    isPatched = true;
    // Cleanup on page unload
    window.addEventListener('beforeunload', ()=>{
        cancelLogFlush();
        stopHeartbeat();
        // Send any remaining logs before page unloads
        sendClientFileLogs();
    });
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    handleClientError: null,
    handleConsoleError: null,
    handleGlobalErrors: null,
    useErrorHandler: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    handleClientError: function() {
        return handleClientError;
    },
    handleConsoleError: function() {
        return handleConsoleError;
    },
    handleGlobalErrors: function() {
        return handleGlobalErrors;
    },
    useErrorHandler: function() {
        return useErrorHandler;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _consoleerror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const queueMicroTask = globalThis.queueMicrotask || ((cb)=>Promise.resolve().then(cb));
const errorQueue = [];
const errorHandlers = [];
const rejectionQueue = [];
const rejectionHandlers = [];
function handleConsoleError(originError, consoleErrorArgs) {
    let error;
    const { environmentName } = (0, _console.parseConsoleArgs)(consoleErrorArgs);
    if ((0, _iserror.default)(originError)) {
        error = (0, _consoleerror.createConsoleError)(originError, environmentName);
    } else {
        error = (0, _consoleerror.createConsoleError)((0, _console.formatConsoleArgs)(consoleErrorArgs), environmentName);
    }
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function handleClientError(error) {
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function useErrorHandler(handleOnUnhandledError, handleOnUnhandledRejection) {
    (0, _react.useEffect)(()=>{
        // Handle queued errors.
        errorQueue.forEach(handleOnUnhandledError);
        rejectionQueue.forEach(handleOnUnhandledRejection);
        // Listen to new errors.
        errorHandlers.push(handleOnUnhandledError);
        rejectionHandlers.push(handleOnUnhandledRejection);
        return ()=>{
            // Remove listeners.
            errorHandlers.splice(errorHandlers.indexOf(handleOnUnhandledError), 1);
            rejectionHandlers.splice(rejectionHandlers.indexOf(handleOnUnhandledRejection), 1);
            // Reset error queues.
            errorQueue.splice(0, errorQueue.length);
            rejectionQueue.splice(0, rejectionQueue.length);
        };
    }, [
        handleOnUnhandledError,
        handleOnUnhandledRejection
    ]);
}
function onUnhandledError(event) {
    const thrownValue = event.error;
    if ((0, _isnextroutererror.isNextRouterError)(thrownValue)) {
        event.preventDefault();
        return false;
    }
    // When there's an error property present, we log the error to error overlay.
    // Otherwise we don't do anything as it's not logging in the console either.
    if (thrownValue) {
        const error = (0, _stitchederror.coerceError)(thrownValue);
        (0, _stitchederror.setOwnerStackIfAvailable)(error);
        handleClientError(error);
        (0, _forwardlogs.forwardUnhandledError)(error);
    }
}
function onUnhandledRejection(ev) {
    const reason = ev?.reason;
    if ((0, _isnextroutererror.isNextRouterError)(reason)) {
        ev.preventDefault();
        return;
    }
    const error = (0, _stitchederror.coerceError)(reason);
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    rejectionQueue.push(error);
    for (const handler of rejectionHandlers){
        handler(error);
    }
    (0, _forwardlogs.logUnhandledRejection)(reason);
}
function handleGlobalErrors() {
    if (typeof window !== 'undefined') {
        try {
            // Increase the number of stack frames on the client
            Error.stackTraceLimit = 50;
        } catch  {}
        window.addEventListener('error', onUnhandledError);
        window.addEventListener('unhandledrejection', onUnhandledRejection);
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-error-handler.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    originConsoleError: null,
    patchConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    originConsoleError: function() {
        return originConsoleError;
    },
    patchConsoleError: function() {
        return patchConsoleError;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _isnextroutererror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const originConsoleError = globalThis.console.error;
function patchConsoleError() {
    // Ensure it's only patched once
    if (typeof window === 'undefined') {
        return;
    }
    window.console.error = function error(...args) {
        let maybeError;
        if ("TURBOPACK compile-time truthy", 1) {
            const { error: replayedError } = (0, _console.parseConsoleArgs)(args);
            if (replayedError) {
                maybeError = replayedError;
            } else if ((0, _iserror.default)(args[0])) {
                maybeError = args[0];
            } else {
                // See https://github.com/facebook/react/blob/d50323eb845c5fde0d720cae888bf35dedd05506/packages/react-reconciler/src/ReactFiberErrorLogger.js#L78
                maybeError = args[1];
            }
        } else //TURBOPACK unreachable
        ;
        if (!(0, _isnextroutererror.isNextRouterError)(maybeError)) {
            if ("TURBOPACK compile-time truthy", 1) {
                (0, _useerrorhandler.handleConsoleError)(// but if we pass the error directly, `handleClientError` will ignore it
                maybeError, args);
            }
            (0, _forwardlogs.forwardErrorLog)(args);
            originConsoleError.apply(window.console, args);
        }
    };
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=intercept-console-error.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-setup.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
(0, _useerrorhandler.handleGlobalErrors)();
(0, _interceptconsoleerror.patchConsoleError)();
(0, _forwardlogs.initializeDebugLogForwarding)('app');
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-setup.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateDevError: null,
    handleClientError: null,
    originConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateDevError: function() {
        return _stitchederror.decorateDevError;
    },
    handleClientError: function() {
        return _useerrorhandler.handleClientError;
    },
    originConsoleError: function() {
        return _interceptconsoleerror.originConsoleError;
    }
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: null,
    SegmentBoundaryTriggerNode: null,
    SegmentStateProvider: null,
    SegmentViewNode: null,
    SegmentViewStateNode: null,
    useSegmentState: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: function() {
        return SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE;
    },
    SegmentBoundaryTriggerNode: function() {
        return SegmentBoundaryTriggerNode;
    },
    SegmentStateProvider: function() {
        return SegmentStateProvider;
    },
    SegmentViewNode: function() {
        return SegmentViewNode;
    },
    SegmentViewStateNode: function() {
        return SegmentViewStateNode;
    },
    useSegmentState: function() {
        return useSegmentState;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _notfound = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/not-found.js [app-client] (ecmascript)");
const SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE = 'NEXT_DEVTOOLS_SIMULATED_ERROR';
function SegmentTrieNode({ type, pagePath }) {
    const { boundaryType, setBoundaryType } = useSegmentState();
    const nodeState = (0, _react.useMemo)(()=>{
        return {
            type,
            pagePath,
            boundaryType,
            setBoundaryType
        };
    }, [
        type,
        pagePath,
        boundaryType,
        setBoundaryType
    ]);
    // Use `useLayoutEffect` to ensure the state is updated during suspense.
    // `useEffect` won't work as the state is preserved during suspense.
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerNodeAdd(nodeState);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerNodeRemove(nodeState);
        };
    }, [
        nodeState
    ]);
    return null;
}
function NotFoundSegmentNode() {
    (0, _notfound.notFound)();
}
function ErrorSegmentNode() {
    throw Object.defineProperty(new Error(SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
const forever = new Promise(()=>{});
function LoadingSegmentNode() {
    (0, _react.use)(forever);
    return null;
}
function SegmentViewStateNode({ page }) {
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerUpdateRouteState(page);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerUpdateRouteState('');
        };
    }, [
        page
    ]);
    return null;
}
function SegmentBoundaryTriggerNode() {
    const { boundaryType } = useSegmentState();
    let segmentNode = null;
    if (boundaryType === 'loading') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(LoadingSegmentNode, {});
    } else if (boundaryType === 'not-found') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(NotFoundSegmentNode, {});
    } else if (boundaryType === 'error') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErrorSegmentNode, {});
    }
    return segmentNode;
}
function SegmentViewNode({ type, pagePath, children }) {
    const segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentTrieNode, {
        type: type,
        pagePath: pagePath
    }, type);
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
        children: [
            segmentNode,
            children
        ]
    });
}
const SegmentStateContext = /*#__PURE__*/ (0, _react.createContext)({
    boundaryType: null,
    setBoundaryType: ()=>{}
});
function SegmentStateProvider({ children }) {
    const [boundaryType, setBoundaryType] = (0, _react.useState)(null);
    const [errorBoundaryKey, setErrorBoundaryKey] = (0, _react.useState)(0);
    const reloadBoundary = (0, _react.useCallback)(()=>setErrorBoundaryKey((prev)=>prev + 1), []);
    const setBoundaryTypeAndReload = (0, _react.useCallback)((type)=>{
        if (type === null) {
            reloadBoundary();
        }
        setBoundaryType(type);
    }, [
        reloadBoundary
    ]);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentStateContext.Provider, {
        value: {
            boundaryType,
            setBoundaryType: setBoundaryTypeAndReload
        },
        children: children
    }, errorBoundaryKey);
}
function useSegmentState() {
    return (0, _react.useContext)(SegmentStateContext);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=segment-explorer-node.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AppDevOverlayErrorBoundary", {
    enumerable: true,
    get: function() {
        return AppDevOverlayErrorBoundary;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _runtimeerrorhandler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/dev/runtime-error-handler.js [app-client] (ecmascript)");
const _errorboundary = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/error-boundary.js [app-client] (ecmascript)");
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _segmentexplorernode = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)");
function ErroredHtml({ globalError: [GlobalError, globalErrorStyles], error }) {
    if (!error) {
        return /*#__PURE__*/ (0, _jsxruntime.jsxs)("html", {
            children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)("head", {}),
                /*#__PURE__*/ (0, _jsxruntime.jsx)("body", {})
            ]
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_errorboundary.ErrorBoundary, {
        errorComponent: _globalerror.default,
        children: [
            globalErrorStyles,
            /*#__PURE__*/ (0, _jsxruntime.jsx)(GlobalError, {
                error: error
            })
        ]
    });
}
class AppDevOverlayErrorBoundary extends _react.PureComponent {
    static getDerivedStateFromError(error) {
        _runtimeerrorhandler.RuntimeErrorHandler.hadRuntimeError = true;
        return {
            reactError: error
        };
    }
    componentDidCatch(err) {
        if (("TURBOPACK compile-time value", "development") === 'development' && err.message === _segmentexplorernode.SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE) {
            return;
        }
        _nextdevtools.dispatcher.openErrorOverlay();
    }
    render() {
        const { children, globalError } = this.props;
        const { reactError } = this.state;
        const fallback = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErroredHtml, {
            globalError: globalError,
            error: reactError
        });
        return reactError !== null ? fallback : children;
    }
    constructor(...args){
        super(...args), this.state = {
            reactError: null
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-error-boundary.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/use-app-dev-rendering-indicator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useAppDevRenderingIndicator", {
    enumerable: true,
    get: function() {
        return useAppDevRenderingIndicator;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const useAppDevRenderingIndicator = ()=>{
    const [isPending, startTransition] = (0, _react.useTransition)();
    (0, _react.useEffect)(()=>{
        if (isPending) {
            _nextdevtools.dispatcher.renderingIndicatorShow();
        } else {
            _nextdevtools.dispatcher.renderingIndicatorHide();
        }
    }, [
        isPending
    ]);
    return startTransition;
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-app-dev-rendering-indicator.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/replay-ssr-only-errors.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ReplaySsrOnlyErrors", {
    enumerable: true,
    get: function() {
        return ReplaySsrOnlyErrors;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _constants = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)");
function readSsrError() {
    if (typeof document === 'undefined') {
        return null;
    }
    const ssrErrorTemplateTag = document.querySelector('template[data-next-error-message]');
    if (ssrErrorTemplateTag) {
        const message = ssrErrorTemplateTag.getAttribute('data-next-error-message');
        const stack = ssrErrorTemplateTag.getAttribute('data-next-error-stack');
        const digest = ssrErrorTemplateTag.getAttribute('data-next-error-digest');
        const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
        if (digest) {
            ;
            error.digest = digest;
        }
        // Skip Next.js SSR'd internal errors that which will be handled by the error boundaries.
        if ((0, _isnextroutererror.isNextRouterError)(error)) {
            return null;
        }
        error.stack = stack || '';
        return error;
    }
    return null;
}
function ReplaySsrOnlyErrors({ onBlockingError }) {
    if ("TURBOPACK compile-time truthy", 1) {
        // Need to read during render. The attributes will be gone after commit.
        const ssrError = readSsrError();
        // eslint-disable-next-line react-hooks/rules-of-hooks
        (0, _react.useEffect)(()=>{
            if (ssrError !== null) {
                // TODO(veil): Include original Owner Stack (NDX-905)
                // TODO(veil): Mark as recoverable error
                // TODO(veil): console.error
                (0, _useerrorhandler.handleClientError)(ssrError);
                // If it's missing root tags, we can't recover, make it blocking.
                if (ssrError.digest === _constants.MISSING_ROOT_TAGS_ERROR) {
                    onBlockingError();
                }
            }
        }, [
            ssrError,
            onBlockingError
        ]);
    }
    return null;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=replay-ssr-only-errors.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/client-entry.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "RootLevelDevOverlayElement", {
    enumerable: true,
    get: function() {
        return RootLevelDevOverlayElement;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _appdevoverlayerrorboundary = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)");
function RootLevelDevOverlayElement({ children }) {
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_appdevoverlayerrorboundary.AppDevOverlayErrorBoundary, {
        globalError: [
            _globalerror.default,
            null
        ],
        children: children
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=client-entry.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    bindSnapshot: null,
    createAsyncLocalStorage: null,
    createSnapshot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    bindSnapshot: function() {
        return bindSnapshot;
    },
    createAsyncLocalStorage: function() {
        return createAsyncLocalStorage;
    },
    createSnapshot: function() {
        return createSnapshot;
    }
});
const sharedAsyncLocalStorageNotAvailableError = Object.defineProperty(new Error('Invariant: AsyncLocalStorage accessed in runtime where it is not available'), "__NEXT_ERROR_CODE", {
    value: "E504",
    enumerable: false,
    configurable: true
});
class FakeAsyncLocalStorage {
    disable() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    getStore() {
        // This fake implementation of AsyncLocalStorage always returns `undefined`.
        return undefined;
    }
    run() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    exit() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    enterWith() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    static bind(fn) {
        return fn;
    }
}
const maybeGlobalAsyncLocalStorage = typeof globalThis !== 'undefined' && globalThis.AsyncLocalStorage;
function createAsyncLocalStorage() {
    if (maybeGlobalAsyncLocalStorage) {
        return new maybeGlobalAsyncLocalStorage();
    }
    return new FakeAsyncLocalStorage();
}
function bindSnapshot(fn) {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.bind(fn);
    }
    return FakeAsyncLocalStorage.bind(fn);
}
function createSnapshot() {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.snapshot();
    }
    return function(fn, ...args) {
        return fn(...args);
    };
} //# sourceMappingURL=async-local-storage.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workUnitAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workUnitAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workUnitAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-unit-async-storage-instance.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getCacheSignal: null,
    getDraftModeProviderForCacheScope: null,
    getHmrRefreshHash: null,
    getPrerenderResumeDataCache: null,
    getRenderResumeDataCache: null,
    getRuntimeStagePromise: null,
    getServerComponentsHmrCache: null,
    isHmrRefresh: null,
    throwForMissingRequestStore: null,
    throwInvariantForMissingStore: null,
    workUnitAsyncStorage: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getCacheSignal: function() {
        return getCacheSignal;
    },
    getDraftModeProviderForCacheScope: function() {
        return getDraftModeProviderForCacheScope;
    },
    getHmrRefreshHash: function() {
        return getHmrRefreshHash;
    },
    getPrerenderResumeDataCache: function() {
        return getPrerenderResumeDataCache;
    },
    getRenderResumeDataCache: function() {
        return getRenderResumeDataCache;
    },
    getRuntimeStagePromise: function() {
        return getRuntimeStagePromise;
    },
    getServerComponentsHmrCache: function() {
        return getServerComponentsHmrCache;
    },
    isHmrRefresh: function() {
        return isHmrRefresh;
    },
    throwForMissingRequestStore: function() {
        return throwForMissingRequestStore;
    },
    throwInvariantForMissingStore: function() {
        return throwInvariantForMissingStore;
    },
    workUnitAsyncStorage: function() {
        return _workunitasyncstorageinstance.workUnitAsyncStorageInstance;
    }
});
const _workunitasyncstorageinstance = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)");
const _approuterheaders = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/app-router-headers.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
function throwForMissingRequestStore(callingExpression) {
    throw Object.defineProperty(new Error(`\`${callingExpression}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
        value: "E251",
        enumerable: false,
        configurable: true
    });
}
function throwInvariantForMissingStore() {
    throw Object.defineProperty(new _invarianterror.InvariantError('Expected workUnitAsyncStorage to have a store.'), "__NEXT_ERROR_CODE", {
        value: "E696",
        enumerable: false,
        configurable: true
    });
}
function getPrerenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-ppr':
            return workUnitStore.prerenderResumeDataCache;
        case 'prerender-client':
            // TODO eliminate fetch caching in client scope and stop exposing this data
            // cache during SSR.
            return workUnitStore.prerenderResumeDataCache;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.prerenderResumeDataCache) {
                    return workUnitStore.prerenderResumeDataCache;
                }
            // fallthrough
            }
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'request':
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-client':
            if (workUnitStore.renderResumeDataCache) {
                // If we are in a prerender, we might have a render resume data cache
                // that is used to read from prefilled caches.
                return workUnitStore.renderResumeDataCache;
            }
        // fallthrough
        case 'prerender-ppr':
            // Otherwise we return the mutable resume data cache here as an immutable
            // version of the cache as it can also be used for reading.
            return workUnitStore.prerenderResumeDataCache ?? null;
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
        case 'prerender-legacy':
            return null;
        default:
            return workUnitStore;
    }
}
function getHmrRefreshHash(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'prerender':
            case 'prerender-runtime':
                return workUnitStore.hmrRefreshHash;
            case 'request':
                var _workUnitStore_cookies_get;
                return (_workUnitStore_cookies_get = workUnitStore.cookies.get(_approuterheaders.NEXT_HMR_REFRESH_HASH_COOKIE)) == null ? void 0 : _workUnitStore_cookies_get.value;
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function isHmrRefresh(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.isHmrRefresh ?? false;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return false;
}
function getServerComponentsHmrCache(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.serverComponentsHmrCache;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getDraftModeProviderForCacheScope(workStore, workUnitStore) {
    if (workStore.isDraftMode) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'unstable-cache':
            case 'prerender-runtime':
            case 'request':
                return workUnitStore.draftMode;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getCacheSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-client':
        case 'prerender-runtime':
            return workUnitStore.cacheSignal;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.cacheSignal) {
                    return workUnitStore.cacheSignal;
                }
            // fallthrough
            }
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRuntimeStagePromise(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender-runtime':
        case 'private-cache':
            return workUnitStore.runtimeStagePromise;
        case 'prerender':
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
} //# sourceMappingURL=work-unit-async-storage.external.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-async-storage-instance.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorage", {
    enumerable: true,
    get: function() {
        return _workasyncstorageinstance.workAsyncStorageInstance;
    }
});
const _workasyncstorageinstance = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=work-async-storage.external.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return actionAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const actionAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=action-async-storage-instance.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/action-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorage", {
    enumerable: true,
    get: function() {
        return _actionasyncstorageinstance.actionAsyncStorageInstance;
    }
});
const _actionasyncstorageinstance = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=action-async-storage.external.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    isHangingPromiseRejectionError: null,
    makeDevtoolsIOAwarePromise: null,
    makeHangingPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    isHangingPromiseRejectionError: function() {
        return isHangingPromiseRejectionError;
    },
    makeDevtoolsIOAwarePromise: function() {
        return makeDevtoolsIOAwarePromise;
    },
    makeHangingPromise: function() {
        return makeHangingPromise;
    }
});
function isHangingPromiseRejectionError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === HANGING_PROMISE_REJECTION;
}
const HANGING_PROMISE_REJECTION = 'HANGING_PROMISE_REJECTION';
class HangingPromiseRejectionError extends Error {
    constructor(route, expression){
        super(`During prerendering, ${expression} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${expression} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${route}".`), this.route = route, this.expression = expression, this.digest = HANGING_PROMISE_REJECTION;
    }
}
const abortListenersBySignal = new WeakMap();
function makeHangingPromise(signal, route, expression) {
    if (signal.aborted) {
        return Promise.reject(new HangingPromiseRejectionError(route, expression));
    } else {
        const hangingPromise = new Promise((_, reject)=>{
            const boundRejection = reject.bind(null, new HangingPromiseRejectionError(route, expression));
            let currentListeners = abortListenersBySignal.get(signal);
            if (currentListeners) {
                currentListeners.push(boundRejection);
            } else {
                const listeners = [
                    boundRejection
                ];
                abortListenersBySignal.set(signal, listeners);
                signal.addEventListener('abort', ()=>{
                    for(let i = 0; i < listeners.length; i++){
                        listeners[i]();
                    }
                }, {
                    once: true
                });
            }
        });
        // We are fine if no one actually awaits this promise. We shouldn't consider this an unhandled rejection so
        // we attach a noop catch handler here to suppress this warning. If you actually await somewhere or construct
        // your own promise out of it you'll need to ensure you handle the error when it rejects.
        hangingPromise.catch(ignoreReject);
        return hangingPromise;
    }
}
function ignoreReject() {}
function makeDevtoolsIOAwarePromise(underlying, requestStore, stage) {
    if (requestStore.stagedRendering) {
        // We resolve each stage in a timeout, so React DevTools will pick this up as IO.
        return requestStore.stagedRendering.delayUntilStage(stage, undefined, underlying);
    }
    // in React DevTools if we resolve in a setTimeout we will observe
    // the promise resolution as something that can suspend a boundary or root.
    return new Promise((resolve)=>{
        // Must use setTimeout to be considered IO React DevTools. setImmediate will not work.
        setTimeout(()=>{
            resolve(underlying);
        }, 0);
    });
} //# sourceMappingURL=dynamic-rendering-utils.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/lib/router-utils/is-postpone.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isPostpone", {
    enumerable: true,
    get: function() {
        return isPostpone;
    }
});
const REACT_POSTPONE_TYPE = Symbol.for('react.postpone');
function isPostpone(error) {
    return typeof error === 'object' && error !== null && error.$$typeof === REACT_POSTPONE_TYPE;
} //# sourceMappingURL=is-postpone.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/dynamic-rendering.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$58$2e$2_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * The functions provided by this module are used to communicate certain properties
 * about the currently running code so that Next.js can make decisions on how to handle
 * the current execution in different rendering modes such as pre-rendering, resuming, and SSR.
 *
 * Today Next.js treats all code as potentially static. Certain APIs may only make sense when dynamically rendering.
 * Traditionally this meant deopting the entire render to dynamic however with PPR we can now deopt parts
 * of a React tree as dynamic while still keeping other parts static. There are really two different kinds of
 * Dynamic indications.
 *
 * The first is simply an intention to be dynamic. unstable_noStore is an example of this where
 * the currently executing code simply declares that the current scope is dynamic but if you use it
 * inside unstable_cache it can still be cached. This type of indication can be removed if we ever
 * make the default dynamic to begin with because the only way you would ever be static is inside
 * a cache scope which this indication does not affect.
 *
 * The second is an indication that a dynamic data source was read. This is a stronger form of dynamic
 * because it means that it is inappropriate to cache this at all. using a dynamic data source inside
 * unstable_cache should error. If you want to use some dynamic data inside unstable_cache you should
 * read that data outside the cache and pass it in as an argument to the cached function.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    Postpone: null,
    PreludeState: null,
    abortAndThrowOnSynchronousRequestDataAccess: null,
    abortOnSynchronousPlatformIOAccess: null,
    accessedDynamicData: null,
    annotateDynamicAccess: null,
    consumeDynamicAccess: null,
    createDynamicTrackingState: null,
    createDynamicValidationState: null,
    createHangingInputAbortSignal: null,
    createRenderInBrowserAbortSignal: null,
    delayUntilRuntimeStage: null,
    formatDynamicAPIAccesses: null,
    getFirstDynamicReason: null,
    getStaticShellDisallowedDynamicReasons: null,
    isDynamicPostpone: null,
    isPrerenderInterruptedError: null,
    logDisallowedDynamicError: null,
    markCurrentScopeAsDynamic: null,
    postponeWithTracking: null,
    throwIfDisallowedDynamic: null,
    throwToInterruptStaticGeneration: null,
    trackAllowedDynamicAccess: null,
    trackDynamicDataInDynamicRender: null,
    trackDynamicHoleInRuntimeShell: null,
    trackDynamicHoleInStaticShell: null,
    useDynamicRouteParams: null,
    useDynamicSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    Postpone: function() {
        return Postpone;
    },
    PreludeState: function() {
        return PreludeState;
    },
    abortAndThrowOnSynchronousRequestDataAccess: function() {
        return abortAndThrowOnSynchronousRequestDataAccess;
    },
    abortOnSynchronousPlatformIOAccess: function() {
        return abortOnSynchronousPlatformIOAccess;
    },
    accessedDynamicData: function() {
        return accessedDynamicData;
    },
    annotateDynamicAccess: function() {
        return annotateDynamicAccess;
    },
    consumeDynamicAccess: function() {
        return consumeDynamicAccess;
    },
    createDynamicTrackingState: function() {
        return createDynamicTrackingState;
    },
    createDynamicValidationState: function() {
        return createDynamicValidationState;
    },
    createHangingInputAbortSignal: function() {
        return createHangingInputAbortSignal;
    },
    createRenderInBrowserAbortSignal: function() {
        return createRenderInBrowserAbortSignal;
    },
    delayUntilRuntimeStage: function() {
        return delayUntilRuntimeStage;
    },
    formatDynamicAPIAccesses: function() {
        return formatDynamicAPIAccesses;
    },
    getFirstDynamicReason: function() {
        return getFirstDynamicReason;
    },
    getStaticShellDisallowedDynamicReasons: function() {
        return getStaticShellDisallowedDynamicReasons;
    },
    isDynamicPostpone: function() {
        return isDynamicPostpone;
    },
    isPrerenderInterruptedError: function() {
        return isPrerenderInterruptedError;
    },
    logDisallowedDynamicError: function() {
        return logDisallowedDynamicError;
    },
    markCurrentScopeAsDynamic: function() {
        return markCurrentScopeAsDynamic;
    },
    postponeWithTracking: function() {
        return postponeWithTracking;
    },
    throwIfDisallowedDynamic: function() {
        return throwIfDisallowedDynamic;
    },
    throwToInterruptStaticGeneration: function() {
        return throwToInterruptStaticGeneration;
    },
    trackAllowedDynamicAccess: function() {
        return trackAllowedDynamicAccess;
    },
    trackDynamicDataInDynamicRender: function() {
        return trackDynamicDataInDynamicRender;
    },
    trackDynamicHoleInRuntimeShell: function() {
        return trackDynamicHoleInRuntimeShell;
    },
    trackDynamicHoleInStaticShell: function() {
        return trackDynamicHoleInStaticShell;
    },
    useDynamicRouteParams: function() {
        return useDynamicRouteParams;
    },
    useDynamicSearchParams: function() {
        return useDynamicSearchParams;
    }
});
const _react = /*#__PURE__*/ _interop_require_default(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _hooksservercontext = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/hooks-server-context.js [app-client] (ecmascript)");
const _staticgenerationbailout = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/client/components/static-generation-bailout.js [app-client] (ecmascript)");
const _workunitasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _dynamicrenderingutils = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)");
const _boundaryconstants = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
const _scheduler = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)");
const _bailouttocsr = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const hasPostpone = typeof _react.default.unstable_postpone === 'function';
function createDynamicTrackingState(isDebugDynamicAccesses) {
    return {
        isDebugDynamicAccesses,
        dynamicAccesses: [],
        syncDynamicErrorWithStack: null
    };
}
function createDynamicValidationState() {
    return {
        hasSuspenseAboveBody: false,
        hasDynamicMetadata: false,
        dynamicMetadata: null,
        hasDynamicViewport: false,
        hasAllowedDynamic: false,
        dynamicErrors: []
    };
}
function getFirstDynamicReason(trackingState) {
    var _trackingState_dynamicAccesses_;
    return (_trackingState_dynamicAccesses_ = trackingState.dynamicAccesses[0]) == null ? void 0 : _trackingState_dynamicAccesses_.expression;
}
function markCurrentScopeAsDynamic(store, workUnitStore, expression) {
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'cache':
            case 'unstable-cache':
                // Inside cache scopes, marking a scope as dynamic has no effect,
                // because the outer cache scope creates a cache boundary. This is
                // subtly different from reading a dynamic data source, which is
                // forbidden inside a cache scope.
                return;
            case 'private-cache':
                // A private cache scope is already dynamic by definition.
                return;
            case 'prerender-legacy':
            case 'prerender-ppr':
            case 'request':
                break;
            default:
                workUnitStore;
        }
    }
    // If we're forcing dynamic rendering or we're forcing static rendering, we
    // don't need to do anything here because the entire page is already dynamic
    // or it's static and it should not throw or postpone here.
    if (store.forceDynamic || store.forceStatic) return;
    if (store.dynamicShouldError) {
        throw Object.defineProperty(new _staticgenerationbailout.StaticGenBailoutError(`Route ${store.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
            value: "E553",
            enumerable: false,
            configurable: true
        });
    }
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-ppr':
                return postponeWithTracking(store.route, expression, workUnitStore.dynamicTracking);
            case 'prerender-legacy':
                workUnitStore.revalidate = 0;
                // We aren't prerendering, but we are generating a static page. We need
                // to bail out of static generation.
                const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used ${expression}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                    value: "E550",
                    enumerable: false,
                    configurable: true
                });
                store.dynamicUsageDescription = expression;
                store.dynamicUsageStack = err.stack;
                throw err;
            case 'request':
                if ("TURBOPACK compile-time truthy", 1) {
                    workUnitStore.usedDynamic = true;
                }
                break;
            default:
                workUnitStore;
        }
    }
}
function throwToInterruptStaticGeneration(expression, store, prerenderStore) {
    // We aren't prerendering but we are generating a static page. We need to bail out of static generation
    const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
        value: "E558",
        enumerable: false,
        configurable: true
    });
    prerenderStore.revalidate = 0;
    store.dynamicUsageDescription = expression;
    store.dynamicUsageStack = err.stack;
    throw err;
}
function trackDynamicDataInDynamicRender(workUnitStore) {
    switch(workUnitStore.type){
        case 'cache':
        case 'unstable-cache':
            // Inside cache scopes, marking a scope as dynamic has no effect,
            // because the outer cache scope creates a cache boundary. This is
            // subtly different from reading a dynamic data source, which is
            // forbidden inside a cache scope.
            return;
        case 'private-cache':
            // A private cache scope is already dynamic by definition.
            return;
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-legacy':
        case 'prerender-ppr':
        case 'prerender-client':
            break;
        case 'request':
            if ("TURBOPACK compile-time truthy", 1) {
                workUnitStore.usedDynamic = true;
            }
            break;
        default:
            workUnitStore;
    }
}
function abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore) {
    const reason = `Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`;
    const error = createPrerenderInterruptedError(reason);
    prerenderStore.controller.abort(error);
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function abortOnSynchronousPlatformIOAccess(route, expression, errorWithStack, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
    // It is important that we set this tracking value after aborting. Aborts are executed
    // synchronously except for the case where you abort during render itself. By setting this
    // value late we can use it to determine if any of the aborted tasks are the task that
    // called the sync IO expression in the first place.
    if (dynamicTracking) {
        if (dynamicTracking.syncDynamicErrorWithStack === null) {
            dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
        }
    }
}
function abortAndThrowOnSynchronousRequestDataAccess(route, expression, errorWithStack, prerenderStore) {
    const prerenderSignal = prerenderStore.controller.signal;
    if (prerenderSignal.aborted === false) {
        // TODO it would be better to move this aborted check into the callsite so we can avoid making
        // the error object when it isn't relevant to the aborting of the prerender however
        // since we need the throw semantics regardless of whether we abort it is easier to land
        // this way. See how this was handled with `abortOnSynchronousPlatformIOAccess` for a closer
        // to ideal implementation
        abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
        // It is important that we set this tracking value after aborting. Aborts are executed
        // synchronously except for the case where you abort during render itself. By setting this
        // value late we can use it to determine if any of the aborted tasks are the task that
        // called the sync IO expression in the first place.
        const dynamicTracking = prerenderStore.dynamicTracking;
        if (dynamicTracking) {
            if (dynamicTracking.syncDynamicErrorWithStack === null) {
                dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
            }
        }
    }
    throw createPrerenderInterruptedError(`Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`);
}
function Postpone({ reason, route }) {
    const prerenderStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    const dynamicTracking = prerenderStore && prerenderStore.type === 'prerender-ppr' ? prerenderStore.dynamicTracking : null;
    postponeWithTracking(route, reason, dynamicTracking);
}
function postponeWithTracking(route, expression, dynamicTracking) {
    assertPostpone();
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
    _react.default.unstable_postpone(createPostponeReason(route, expression));
}
function createPostponeReason(route, expression) {
    return `Route ${route} needs to bail out of prerendering at this point because it used ${expression}. ` + `React throws this special object to indicate where. It should not be caught by ` + `your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`;
}
function isDynamicPostpone(err) {
    if (typeof err === 'object' && err !== null && typeof err.message === 'string') {
        return isDynamicPostponeReason(err.message);
    }
    return false;
}
function isDynamicPostponeReason(reason) {
    return reason.includes('needs to bail out of prerendering at this point because it used') && reason.includes('Learn more: https://nextjs.org/docs/messages/ppr-caught-error');
}
if (isDynamicPostponeReason(createPostponeReason('%%%', '^^^')) === false) {
    throw Object.defineProperty(new Error('Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js'), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: false,
        configurable: true
    });
}
const NEXT_PRERENDER_INTERRUPTED = 'NEXT_PRERENDER_INTERRUPTED';
function createPrerenderInterruptedError(message) {
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    error.digest = NEXT_PRERENDER_INTERRUPTED;
    return error;
}
function isPrerenderInterruptedError(error) {
    return typeof error === 'object' && error !== null && error.digest === NEXT_PRERENDER_INTERRUPTED && 'name' in error && 'message' in error && error instanceof Error;
}
function accessedDynamicData(dynamicAccesses) {
    return dynamicAccesses.length > 0;
}
function consumeDynamicAccess(serverDynamic, clientDynamic) {
    // We mutate because we only call this once we are no longer writing
    // to the dynamicTrackingState and it's more efficient than creating a new
    // array.
    serverDynamic.dynamicAccesses.push(...clientDynamic.dynamicAccesses);
    return serverDynamic.dynamicAccesses;
}
function formatDynamicAPIAccesses(dynamicAccesses) {
    return dynamicAccesses.filter((access)=>typeof access.stack === 'string' && access.stack.length > 0).map(({ expression, stack })=>{
        stack = stack.split('\n') // Remove the "Error: " prefix from the first line of the stack trace as
        // well as the first 4 lines of the stack trace which is the distance
        // from the user code and the `new Error().stack` call.
        .slice(4).filter((line)=>{
            // Exclude Next.js internals from the stack trace.
            if (line.includes('node_modules/next/')) {
                return false;
            }
            // Exclude anonymous functions from the stack trace.
            if (line.includes(' (<anonymous>)')) {
                return false;
            }
            // Exclude Node.js internals from the stack trace.
            if (line.includes(' (node:')) {
                return false;
            }
            return true;
        }).join('\n');
        return `Dynamic API Usage Debug - ${expression}:\n${stack}`;
    });
}
function assertPostpone() {
    if (!hasPostpone) {
        throw Object.defineProperty(new Error(`Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js`), "__NEXT_ERROR_CODE", {
            value: "E224",
            enumerable: false,
            configurable: true
        });
    }
}
function createRenderInBrowserAbortSignal() {
    const controller = new AbortController();
    controller.abort(Object.defineProperty(new _bailouttocsr.BailoutToCSRError('Render in Browser'), "__NEXT_ERROR_CODE", {
        value: "E721",
        enumerable: false,
        configurable: true
    }));
    return controller.signal;
}
function createHangingInputAbortSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
            const controller = new AbortController();
            if (workUnitStore.cacheSignal) {
                // If we have a cacheSignal it means we're in a prospective render. If
                // the input we're waiting on is coming from another cache, we do want
                // to wait for it so that we can resolve this cache entry too.
                workUnitStore.cacheSignal.inputReady().then(()=>{
                    controller.abort();
                });
            } else {
                // Otherwise we're in the final render and we should already have all
                // our caches filled.
                // If the prerender uses stages, we have wait until the runtime stage,
                // at which point all runtime inputs will be resolved.
                // (otherwise, a runtime prerender might consider `cookies()` hanging
                //  even though they'd resolve in the next task.)
                //
                // We might still be waiting on some microtasks so we
                // wait one tick before giving up. When we give up, we still want to
                // render the content of this cache as deeply as we can so that we can
                // suspend as deeply as possible in the tree or not at all if we don't
                // end up waiting for the input.
                const runtimeStagePromise = (0, _workunitasyncstorageexternal.getRuntimeStagePromise)(workUnitStore);
                if (runtimeStagePromise) {
                    runtimeStagePromise.then(()=>(0, _scheduler.scheduleOnNextTick)(()=>controller.abort()));
                } else {
                    (0, _scheduler.scheduleOnNextTick)(()=>controller.abort());
                }
            }
            return controller.signal;
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return undefined;
        default:
            workUnitStore;
    }
}
function annotateDynamicAccess(expression, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function useDynamicRouteParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (workStore && workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-client':
            case 'prerender':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        // We are in a prerender with cacheComponents semantics. We are going to
                        // hang here and never resolve. This will cause the currently
                        // rendering component to effectively be a dynamic hole.
                        _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                    }
                    break;
                }
            case 'prerender-ppr':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        return postponeWithTracking(workStore.route, expression, workUnitStore.dynamicTracking);
                    }
                    break;
                }
            case 'prerender-runtime':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called during a runtime prerender. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: false,
                    configurable: true
                });
            case 'cache':
            case 'private-cache':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: false,
                    configurable: true
                });
            case 'prerender-legacy':
            case 'request':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
}
function useDynamicSearchParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (!workStore) {
        // We assume pages router context and just return
        return;
    }
    if (!workUnitStore) {
        (0, _workunitasyncstorageexternal.throwForMissingRequestStore)(expression);
    }
    switch(workUnitStore.type){
        case 'prerender-client':
            {
                _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                break;
            }
        case 'prerender-legacy':
        case 'prerender-ppr':
            {
                if (workStore.forceStatic) {
                    return;
                }
                throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(expression), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: false,
                    configurable: true
                });
            }
        case 'prerender':
        case 'prerender-runtime':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called from a Server Component. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E795",
                enumerable: false,
                configurable: true
            });
        case 'cache':
        case 'unstable-cache':
        case 'private-cache':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E745",
                enumerable: false,
                configurable: true
            });
        case 'request':
            return;
        default:
            workUnitStore;
    }
}
const hasSuspenseRegex = /\n\s+at Suspense \(<anonymous>\)/;
// Common implicit body tags that React will treat as body when placed directly in html
const bodyAndImplicitTags = 'body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6';
// Detects when RootLayoutBoundary (our framework marker component) appears
// after Suspense in the component stack, indicating the root layout is wrapped
// within a Suspense boundary. Ensures no body/html/implicit-body components are in between.
//
// Example matches:
//   at Suspense (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
//
// Or with other components in between (but not body/html/implicit-body):
//   at Suspense (<anonymous>)
//   at SomeComponent (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
const hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex = new RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:${bodyAndImplicitTags}) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`);
const hasMetadataRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.METADATA_BOUNDARY_NAME}[\\n\\s]`);
const hasViewportRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`);
const hasOutletRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.OUTLET_BOUNDARY_NAME}[\\n\\s]`);
function trackAllowedDynamicAccess(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        dynamicValidation.hasDynamicMetadata = true;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        dynamicValidation.hasDynamicViewport = true;
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Uncached data was accessed outside of ` + '<Suspense>. This delays the entire page from rendering, resulting in a ' + 'slow user experience. Learn more: ' + 'https://nextjs.org/docs/messages/blocking-route';
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
function trackDynamicHoleInRuntimeShell(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed inside \`generateMetadata\`. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicMetadata = error;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
function trackDynamicHoleInStaticShell(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateMetadata\` or you have file-based metadata such as icons that depend on dynamic params segments. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicMetadata = error;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
/**
 * In dev mode, we prefer using the owner stack, otherwise the provided
 * component stack is used.
 */ function createErrorWithComponentOrOwnerStack(message, componentStack) {
    const ownerStack = ("TURBOPACK compile-time value", "development") !== 'production' && _react.default.captureOwnerStack ? _react.default.captureOwnerStack() : null;
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    // TODO go back to owner stack here if available. This is temporarily using componentStack to get the right
    //
    error.stack = error.name + ': ' + message + (ownerStack || componentStack);
    return error;
}
var PreludeState = /*#__PURE__*/ function(PreludeState) {
    PreludeState[PreludeState["Full"] = 0] = "Full";
    PreludeState[PreludeState["Empty"] = 1] = "Empty";
    PreludeState[PreludeState["Errored"] = 2] = "Errored";
    return PreludeState;
}({});
function logDisallowedDynamicError(workStore, error) {
    console.error(error);
    if (!workStore.dev) {
        if (workStore.hasReadableErrorStacks) {
            console.error(`To get a more detailed stack trace and pinpoint the issue, start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.`);
        } else {
            console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`);
        }
    }
}
function throwIfDisallowedDynamic(workStore, prelude, dynamicValidation, serverDynamic) {
    if (serverDynamic.syncDynamicErrorWithStack) {
        logDisallowedDynamicError(workStore, serverDynamic.syncDynamicErrorWithStack);
        throw new _staticgenerationbailout.StaticGenBailoutError();
    }
    if (prelude !== 0) {
        if (dynamicValidation.hasSuspenseAboveBody) {
            // This route has opted into allowing fully dynamic rendering
            // by including a Suspense boundary above the body. In this case
            // a lack of a shell is not considered disallowed so we simply return
            return;
        }
        // We didn't have any sync bailouts but there may be user code which
        // blocked the root. We would have captured these during the prerender
        // and can log them here and then terminate the build/validating render
        const dynamicErrors = dynamicValidation.dynamicErrors;
        if (dynamicErrors.length > 0) {
            for(let i = 0; i < dynamicErrors.length; i++){
                logDisallowedDynamicError(workStore, dynamicErrors[i]);
            }
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        // If we got this far then the only other thing that could be blocking
        // the root is dynamic Viewport. If this is dynamic then
        // you need to opt into that by adding a Suspense boundary above the body
        // to indicate your are ok with fully dynamic rendering.
        if (dynamicValidation.hasDynamicViewport) {
            console.error(`Route "${workStore.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        if (prelude === 1) {
            // If we ever get this far then we messed up the tracking of invalid dynamic.
            // We still adhere to the constraint that you must produce a shell but invite the
            // user to report this as a bug in Next.js.
            console.error(`Route "${workStore.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    } else {
        if (dynamicValidation.hasAllowedDynamic === false && dynamicValidation.hasDynamicMetadata) {
            console.error(`Route "${workStore.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    }
}
function getStaticShellDisallowedDynamicReasons(workStore, prelude, dynamicValidation) {
    if (dynamicValidation.hasSuspenseAboveBody) {
        // This route has opted into allowing fully dynamic rendering
        // by including a Suspense boundary above the body. In this case
        // a lack of a shell is not considered disallowed so we simply return
        return [];
    }
    if (prelude !== 0) {
        // We didn't have any sync bailouts but there may be user code which
        // blocked the root. We would have captured these during the prerender
        // and can log them here and then terminate the build/validating render
        const dynamicErrors = dynamicValidation.dynamicErrors;
        if (dynamicErrors.length > 0) {
            return dynamicErrors;
        }
        if (prelude === 1) {
            // If we ever get this far then we messed up the tracking of invalid dynamic.
            // We still adhere to the constraint that you must produce a shell but invite the
            // user to report this as a bug in Next.js.
            return [
                Object.defineProperty(new _invarianterror.InvariantError(`Route "${workStore.route}" did not produce a static shell and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                    value: "E936",
                    enumerable: false,
                    configurable: true
                })
            ];
        }
    } else {
        // We have a prelude but we might still have dynamic metadata without any other dynamic access
        if (dynamicValidation.hasAllowedDynamic === false && dynamicValidation.dynamicErrors.length === 0 && dynamicValidation.dynamicMetadata) {
            return [
                dynamicValidation.dynamicMetadata
            ];
        }
    }
    // We had a non-empty prelude and there are no dynamic holes
    return [];
}
function delayUntilRuntimeStage(prerenderStore, result) {
    if (prerenderStore.runtimeStagePromise) {
        return prerenderStore.runtimeStagePromise.then(()=>result);
    }
    return result;
} //# sourceMappingURL=dynamic-rendering.js.map
}),
"[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.58.2_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next/dist/server/dev/hot-reloader-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HMR_MESSAGE_SENT_TO_BROWSER: null,
    HMR_MESSAGE_SENT_TO_SERVER: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HMR_MESSAGE_SENT_TO_BROWSER: function() {
        return HMR_MESSAGE_SENT_TO_BROWSER;
    },
    HMR_MESSAGE_SENT_TO_SERVER: function() {
        return HMR_MESSAGE_SENT_TO_SERVER;
    }
});
var HMR_MESSAGE_SENT_TO_BROWSER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_BROWSER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_BROWSER["ADDED_PAGE"] = "addedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["REMOVED_PAGE"] = "removedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["RELOAD_PAGE"] = "reloadPage";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_COMPONENT_CHANGES"] = "serverComponentChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["MIDDLEWARE_CHANGES"] = "middlewareChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["CLIENT_CHANGES"] = "clientChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ONLY_CHANGES"] = "serverOnlyChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SYNC"] = "sync";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILT"] = "built";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILDING"] = "building";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_PAGES_MANIFEST_UPDATE"] = "devPagesManifestUpdate";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_MESSAGE"] = "turbopack-message";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ERROR"] = "serverError";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_CONNECTED"] = "turbopack-connected";
    HMR_MESSAGE_SENT_TO_BROWSER["ISR_MANIFEST"] = "isrManifest";
    HMR_MESSAGE_SENT_TO_BROWSER["CACHE_INDICATOR"] = "cacheIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_INDICATOR"] = "devIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEVTOOLS_CONFIG"] = "devtoolsConfig";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_CURRENT_ERROR_STATE"] = "requestCurrentErrorState";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_PAGE_METADATA"] = "requestPageMetadata";
    // Binary messages:
    HMR_MESSAGE_SENT_TO_BROWSER[HMR_MESSAGE_SENT_TO_BROWSER["REACT_DEBUG_CHUNK"] = 0] = "REACT_DEBUG_CHUNK";
    HMR_MESSAGE_SENT_TO_BROWSER[HMR_MESSAGE_SENT_TO_BROWSER["ERRORS_TO_SHOW_IN_BROWSER"] = 1] = "ERRORS_TO_SHOW_IN_BROWSER";
    return HMR_MESSAGE_SENT_TO_BROWSER;
}({});
var HMR_MESSAGE_SENT_TO_SERVER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_SERVER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_SERVER["MCP_ERROR_STATE_RESPONSE"] = "mcp-error-state-response";
    HMR_MESSAGE_SENT_TO_SERVER["MCP_PAGE_METADATA_RESPONSE"] = "mcp-page-metadata-response";
    HMR_MESSAGE_SENT_TO_SERVER["PING"] = "ping";
    return HMR_MESSAGE_SENT_TO_SERVER;
}({}); //# sourceMappingURL=hot-reloader-types.js.map
}),
]);

//# sourceMappingURL=62645_next_dist_7b9f75cc._.js.map