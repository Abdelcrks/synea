(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7e1ae34b._.js",
  "static/chunks/62645_next_dist_compiled_react-dom_4134d860._.js",
  "static/chunks/62645_next_dist_compiled_react-server-dom-turbopack_9c59a04f._.js",
  "static/chunks/62645_next_dist_compiled_next-devtools_index_f2f6a292.js",
  "static/chunks/62645_next_dist_compiled_0f2efbde._.js",
  "static/chunks/62645_next_dist_client_ed1db9a9._.js",
  "static/chunks/62645_next_dist_7b9f75cc._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
